package com.alibaba.jvm.sandbox.repeater.module;

/**
 * <p>
 *
 * @author zhaoyb1990
 */
class Constants {

    static final String MODULE_ID = "repeater";

    static final String VERSION = "1.0.0";
}
