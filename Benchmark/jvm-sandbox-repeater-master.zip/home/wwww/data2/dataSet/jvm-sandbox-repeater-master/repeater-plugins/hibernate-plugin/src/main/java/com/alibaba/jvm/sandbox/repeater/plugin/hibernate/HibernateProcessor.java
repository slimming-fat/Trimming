package com.alibaba.jvm.sandbox.repeater.plugin.hibernate;

import com.alibaba.jvm.sandbox.repeater.plugin.core.impl.api.DefaultInvocationProcessor;
import com.alibaba.jvm.sandbox.repeater.plugin.domain.InvokeType;

/**
 * {@link HibernateProcessor}
 * <p>
 *
 * @author zhaoyb1990
 */
class HibernateProcessor extends DefaultInvocationProcessor {

    HibernateProcessor(InvokeType type) {
        super(type);
    }
}
