package com.alibaba.jvm.sandbox.repeater.plugin.jpa;

import com.alibaba.jvm.sandbox.repeater.plugin.core.impl.api.DefaultInvocationProcessor;
import com.alibaba.jvm.sandbox.repeater.plugin.domain.InvokeType;

/**
 * {@link SpringDataJpaProcessor}
 * <p>
 *
 * @author zhaoyb1990
 */
class SpringDataJpaProcessor extends DefaultInvocationProcessor {

    SpringDataJpaProcessor(InvokeType type) {
        super(type);
    }
}
