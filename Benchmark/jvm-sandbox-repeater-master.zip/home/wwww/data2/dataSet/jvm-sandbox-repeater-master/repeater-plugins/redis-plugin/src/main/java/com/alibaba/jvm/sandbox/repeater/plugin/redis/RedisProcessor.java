package com.alibaba.jvm.sandbox.repeater.plugin.redis;

import com.alibaba.jvm.sandbox.repeater.plugin.core.impl.api.DefaultInvocationProcessor;
import com.alibaba.jvm.sandbox.repeater.plugin.domain.InvokeType;

/**
 * {@link RedisProcessor}
 * <p>
 *
 * @author zhaoyb1990
 */
class RedisProcessor extends DefaultInvocationProcessor {

    RedisProcessor(InvokeType type) {
        super(type);
    }

}
