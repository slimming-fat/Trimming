package com.alibaba.jvm.sandbox.repeater.plugin.socketio;

import com.alibaba.jvm.sandbox.repeater.plugin.core.impl.api.DefaultInvocationProcessor;
import com.alibaba.jvm.sandbox.repeater.plugin.domain.InvokeType;

/**
 * {@link SocketIOProcessor}
 * <p>
 *
 * @author xuminwlt
 */
class SocketIOProcessor extends DefaultInvocationProcessor {

    SocketIOProcessor(InvokeType type) {
        super(type);
    }

}