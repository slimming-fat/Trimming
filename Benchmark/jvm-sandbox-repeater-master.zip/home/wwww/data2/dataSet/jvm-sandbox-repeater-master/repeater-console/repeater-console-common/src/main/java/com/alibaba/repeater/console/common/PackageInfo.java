package com.alibaba.repeater.console.common;

/**
 * {@link PackageInfo}
 * <p>
 *
 * @author zhaoyb1990
 */
public class PackageInfo {
}
