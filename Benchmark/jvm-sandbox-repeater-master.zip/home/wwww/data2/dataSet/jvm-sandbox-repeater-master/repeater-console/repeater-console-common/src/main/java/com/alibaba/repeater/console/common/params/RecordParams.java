package com.alibaba.repeater.console.common.params;

import lombok.*;

/**
 * {@link RecordParams}
 * <p>
 *
 * @author zhaoyb1990
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
public class RecordParams extends BaseParams {
}
