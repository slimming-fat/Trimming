To execute the benchmark, run the script `./benchmark/run.sh`.
