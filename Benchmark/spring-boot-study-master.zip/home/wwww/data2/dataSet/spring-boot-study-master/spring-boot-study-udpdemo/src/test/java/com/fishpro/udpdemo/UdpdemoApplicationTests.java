package com.fishpro.udpdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UdpdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
