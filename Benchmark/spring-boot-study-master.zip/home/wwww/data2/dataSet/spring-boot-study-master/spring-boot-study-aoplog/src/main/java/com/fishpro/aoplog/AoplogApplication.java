package com.fishpro.aoplog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AoplogApplication {

    public static void main(String[] args) {
        SpringApplication.run(AoplogApplication.class, args);
    }

}
