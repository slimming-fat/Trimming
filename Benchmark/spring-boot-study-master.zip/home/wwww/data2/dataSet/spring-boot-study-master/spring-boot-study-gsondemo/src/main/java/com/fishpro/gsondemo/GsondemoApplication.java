package com.fishpro.gsondemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GsondemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(GsondemoApplication.class, args);
    }

}
