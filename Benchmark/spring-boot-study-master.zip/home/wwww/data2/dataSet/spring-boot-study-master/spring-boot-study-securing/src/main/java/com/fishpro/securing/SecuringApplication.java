package com.fishpro.securing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecuringApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecuringApplication.class, args);
    }

}
