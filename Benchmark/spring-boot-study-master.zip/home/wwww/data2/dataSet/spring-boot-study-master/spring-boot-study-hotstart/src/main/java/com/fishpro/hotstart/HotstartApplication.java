package com.fishpro.hotstart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotstartApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotstartApplication.class, args);
	}

}
