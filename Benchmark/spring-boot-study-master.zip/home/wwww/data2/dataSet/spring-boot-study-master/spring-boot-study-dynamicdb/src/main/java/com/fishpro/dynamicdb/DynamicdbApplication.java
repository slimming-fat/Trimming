package com.fishpro.dynamicdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DynamicdbApplication {

    public static void main(String[] args) {
        SpringApplication.run(DynamicdbApplication.class, args);
    }

}
