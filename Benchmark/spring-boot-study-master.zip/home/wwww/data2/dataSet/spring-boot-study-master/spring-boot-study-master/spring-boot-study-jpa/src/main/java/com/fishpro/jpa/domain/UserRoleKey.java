package com.fishpro.jpa.domain;

import java.io.Serializable;

public class UserRoleKey implements Serializable {
    private Integer userId;
    private Integer roleId;
}
