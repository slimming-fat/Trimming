package com.fishpro.mqtt.controller;

public class IndexController {
}
