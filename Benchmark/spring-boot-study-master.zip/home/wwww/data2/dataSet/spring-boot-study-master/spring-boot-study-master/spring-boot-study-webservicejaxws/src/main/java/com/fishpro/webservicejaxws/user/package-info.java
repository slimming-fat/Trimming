@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.youdomain.com/webservice")
package com.fishpro.webservicejaxws.user;
