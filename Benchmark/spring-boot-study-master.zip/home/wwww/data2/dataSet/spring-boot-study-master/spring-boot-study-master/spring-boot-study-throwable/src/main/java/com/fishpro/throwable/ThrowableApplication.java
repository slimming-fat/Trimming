package com.fishpro.throwable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThrowableApplication {

    public static void main(String[] args) {
        SpringApplication.run(ThrowableApplication.class, args);
    }

}
