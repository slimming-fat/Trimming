package demo;

/**
 * @author: guangxush
 * @create: 2020/06/14
 */
public class Dog {
    public String hello() {
        //return "wow wow~";
        return "miao miao~";
    }
}
