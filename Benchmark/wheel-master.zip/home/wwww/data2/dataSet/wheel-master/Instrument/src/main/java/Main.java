/**
 * @author: guangxush
 * @create: 2020/06/14
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("123");
    }
}
