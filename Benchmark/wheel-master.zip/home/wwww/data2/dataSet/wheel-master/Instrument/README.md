## 基于Java Instrument的Agent实现

https://www.jianshu.com/p/b72f66da679f?spm=ata.13261165.0.0.48984ae8DLkIN5

https://www.cnblogs.com/jhxxb/p/11570503.html?spm=ata.13261165.0.0.48984ae8DLkIN5

https://www.ibm.com/developerworks/cn/java/j-dyn0414/index.html?spm=ata.13261165.0.0.48984ae8DLkIN5

https://blog.csdn.net/u014026363/article/details/50605098?spm=ata.13261165.0.0.48984ae8DLkIN5

https://www.cnkirito.moe/instrument/?spm=ata.13261165.0.0.48984ae8DLkIN5

https://www.lizenghai.com/archives/42951.html?spm=ata.13261165.0.0.48984ae8DLkIN5