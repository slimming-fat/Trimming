package one;

/**
 * 父类
 *
 * @author: guangxush
 * @create: 2020/05/31
 */
public class Parents {
    public void function() {
        System.out.println("I'm parents!");
    }
}
