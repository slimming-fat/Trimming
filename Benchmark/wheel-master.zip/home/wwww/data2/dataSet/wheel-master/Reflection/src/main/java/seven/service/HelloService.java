package seven.service;

/**
 * @author: guangxush
 * @create: 2020/06/07
 */
public interface HelloService {
    /**
     * hello
     * @param name
     * @return
     */
    String hello(String name);
}
