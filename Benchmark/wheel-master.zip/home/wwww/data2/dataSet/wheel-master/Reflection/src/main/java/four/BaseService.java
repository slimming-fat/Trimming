package four;

/**
 * 父类实现日志打印
 * @author: guangxush
 * @create: 2020/06/06
 */
public class BaseService {

    /**
     *
     * @param something
     * @return
     */
    String run(String something){
        return null;
    }

    void printLog(){
        System.out.println("统一打印日志");
    }
}
