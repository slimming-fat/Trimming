package seven;

/**
 * @author: guangxush
 * @create: 2020/06/07
 */
public class LogConstant {
    /** 自定义分隔符，便于以后修改 */

    public static final String C_PREFIX = "[";

    public static final String C_SUFFIX = "]";

    public static final String S_PREFIX = "(";

    public static final String S_SUFFIX = ")";

    public static final String COMMA = ",";

    public static final String DOT = ".";
}
