package two;

/**
 * @author: guangxush
 * @create: 2020/06/07
 */
public class Children implements Parents{

    @Override
    public void function() {
        System.out.println("I'm children!");
    }
}
