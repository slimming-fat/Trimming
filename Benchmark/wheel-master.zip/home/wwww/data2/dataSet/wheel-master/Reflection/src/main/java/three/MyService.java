package three;


/**
 * @author: guangxush
 * @create: 2020/06/06
 */
public class MyService {
    public String run(String something){
        // int i = 1/0;
        return "服务正在运行...." + something;
    }
}
