package five;

/**
 * @author: guangxush
 * @create: 2020/06/07
 */
public interface Parents {
    String hello(String name);
}
