package six;

/**
 * @author: guangxush
 * @create: 2020/06/07
 */
public interface Parents {
    void function();
}
