package one;

/**
 * 子类
 *
 * @author: guangxush
 * @create: 2020/05/31
 */
public class Student extends Parents {
    @Override
    public void function() {
        System.out.println("I'm children!");
    }
}