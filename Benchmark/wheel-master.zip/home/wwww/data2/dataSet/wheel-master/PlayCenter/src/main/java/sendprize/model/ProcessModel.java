package sendprize.model;

/**
 * @author: guangxush
 * @create: 2021/03/07
 */
public interface ProcessModel {
}
