package check.model;

/**
 * 事件触发
 *
 * @author: guangxush
 * @create: 2021/03/20
 */
public class BizEvent {

}
