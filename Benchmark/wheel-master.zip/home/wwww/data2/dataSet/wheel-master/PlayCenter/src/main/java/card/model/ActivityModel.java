package card.model;

/**
 * 活动模型
 *
 * @author: guangxush
 * @create: 2021/03/07
 */
public class ActivityModel {
}
