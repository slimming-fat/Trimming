/**
 * @author: guangxush
 * @create: 2019/08/24
 */
public class RunnableDenyException extends RuntimeException{

    public RunnableDenyException(String message){
        super(message);
    }
}
