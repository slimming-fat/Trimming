import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author: guangxush
 * @create: 2021/10/30
 */
public class TestApplicationContext {
    public static void main(String[] args) {
    }
}
