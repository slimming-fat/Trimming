package demo;

/**
 * @author: guangxush
 * @create: 2019/05/18
 */
public interface ServiceProducer {
    String sendData(String data);
}
