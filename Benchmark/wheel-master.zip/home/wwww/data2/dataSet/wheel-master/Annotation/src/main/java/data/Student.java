package data;

/**
 * @author: guangxush
 * @create: 2020/08/09
 */
@DataAnnotation(value = true)
public class Student {
    private String name = "zhangsan";
    private Integer age = 12;
}
