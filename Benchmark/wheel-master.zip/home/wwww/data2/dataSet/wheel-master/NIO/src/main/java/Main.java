/**
 * @author: guangxush
 * @create: 2020/02/11
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("Learn NIO");
    }
}
