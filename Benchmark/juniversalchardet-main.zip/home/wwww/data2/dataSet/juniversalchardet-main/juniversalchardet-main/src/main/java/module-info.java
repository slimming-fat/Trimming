module com.github.albfernandez.juniversalchardet {
    exports org.mozilla.universalchardet;
    exports org.mozilla.universalchardet.prober;
    exports org.mozilla.universalchardet.prober.contextanalysis;
    exports org.mozilla.universalchardet.prober.distributionanalysis;
    exports org.mozilla.universalchardet.prober.sequence;
    exports org.mozilla.universalchardet.prober.statemachine;
}