package info.blockchain.api;

public class Util {
    public static final int SATOSHI_IN_BTC = 100000000;
}
