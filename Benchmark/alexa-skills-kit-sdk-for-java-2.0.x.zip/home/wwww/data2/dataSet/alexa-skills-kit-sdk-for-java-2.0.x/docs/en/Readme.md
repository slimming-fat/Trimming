Alexa Skills Kit SDK for Java
=============================

The **ASK SDK for Java** makes it easier for you to build highly engaging skills,
by allowing you to spend more time on implementing features and less on writing boiler-plate code.

You can find the latest documentation about the SDK [here](https://developer.amazon.com/docs/alexa-skills-kit-sdk-for-java/overview.html).