package com.baidu.unbiz.fluentvalidator;

/**
 * 一些静态常量
 *
 * @author zhangxu
 */
public class Const {

    /**
     * 默认初始容器大小
     */
    public static final int INITIAL_CAPACITY = 4;

}
