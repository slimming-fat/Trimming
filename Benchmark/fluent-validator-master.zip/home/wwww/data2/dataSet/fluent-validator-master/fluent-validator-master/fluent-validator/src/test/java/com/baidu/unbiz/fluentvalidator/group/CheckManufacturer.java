package com.baidu.unbiz.fluentvalidator.group;

/**
 * @author zhangxu
 */
public class CheckManufacturer {
}
