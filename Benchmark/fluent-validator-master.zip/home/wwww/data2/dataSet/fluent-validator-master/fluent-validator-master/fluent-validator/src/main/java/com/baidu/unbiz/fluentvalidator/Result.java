package com.baidu.unbiz.fluentvalidator;

/**
 * 最简单的验证结果
 * <p/>
 * 作为{@link ResultCollectors#toSimple()}的结果泛型&lt;T&gt;
 *
 * @author zhangxu
 */
public class Result extends GenericResult<String> {

}
