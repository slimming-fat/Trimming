package com.baidu.unbiz.fluentvalidator.groups;

/**
 * @author zhangxu
 */
public interface Add {
}
