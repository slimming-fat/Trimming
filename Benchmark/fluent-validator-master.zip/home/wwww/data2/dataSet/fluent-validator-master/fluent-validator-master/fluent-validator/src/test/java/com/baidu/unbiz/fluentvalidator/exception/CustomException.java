package com.baidu.unbiz.fluentvalidator.exception;

/**
 * @author zhangxu
 */
public class CustomException extends RuntimeException {

    public CustomException() {
    }

    public CustomException(String message) {
        super(message);
    }

}
