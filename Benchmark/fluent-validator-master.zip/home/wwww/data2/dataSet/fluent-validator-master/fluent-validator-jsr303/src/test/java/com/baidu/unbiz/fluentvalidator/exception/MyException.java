package com.baidu.unbiz.fluentvalidator.exception;

/**
 * @author zhangxu
 */
public class MyException extends RuntimeException {

    public MyException() {
    }

    public MyException(String message) {
        super(message);
    }

}
