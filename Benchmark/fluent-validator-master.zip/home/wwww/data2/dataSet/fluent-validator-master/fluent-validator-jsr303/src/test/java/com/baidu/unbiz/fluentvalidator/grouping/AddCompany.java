package com.baidu.unbiz.fluentvalidator.grouping;

/**
 * @author zhangxu
 */
public interface AddCompany {
}
