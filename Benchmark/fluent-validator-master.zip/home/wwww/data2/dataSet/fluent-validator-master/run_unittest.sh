#!/bin/bash
mvn clean package test