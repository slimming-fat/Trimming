package com.jeesuite.common.constants;

/**
 *  数据范围类型
 * 
 * <br>
 * Class Name   : InfoType
 *
 * @author jiangwei
 * @version 1.0.0
 * @date Dec 3, 2020
 */
public enum DataScopeType {

	basic,details,extr
}
