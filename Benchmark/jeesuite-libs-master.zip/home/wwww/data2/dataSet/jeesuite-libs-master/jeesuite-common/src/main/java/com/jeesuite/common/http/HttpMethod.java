package com.jeesuite.common.http;

public enum HttpMethod {
    DELETE,
    GET,
    HEAD,
    POST,
    PUT,
    OPTIONS
}
