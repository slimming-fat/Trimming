package com.jeesuite.common.async;

/**
 * 
 * <br>
 * Class Name   : ExecuteCallback
 *
 * @author jiangwei
 * @version 1.0.0
 * @date 2020年2月21日
 */
public interface ExecuteCallback {

	void onSuccess();
	void onFail();
}
