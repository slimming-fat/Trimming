package com.jeesuite.common.constants;

public enum MatchPolicy {
	exact,fuzzy
}
