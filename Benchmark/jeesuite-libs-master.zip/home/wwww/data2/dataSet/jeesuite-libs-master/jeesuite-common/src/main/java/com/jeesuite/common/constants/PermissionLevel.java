package com.jeesuite.common.constants;

/**
 * 
 * <br>
 * Class Name   : PermissionLevel
 *
 * @author jiangwei
 * @version 1.0.0
 * @date 2016年8月17日
 */
public enum PermissionLevel {
	Anonymous,LoginRequired,PermissionRequired
}
