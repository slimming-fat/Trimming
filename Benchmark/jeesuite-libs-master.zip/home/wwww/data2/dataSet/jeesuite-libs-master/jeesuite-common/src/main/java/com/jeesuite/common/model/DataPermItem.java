package com.jeesuite.common.model;

public class DataPermItem extends KeyValues {
	
}
