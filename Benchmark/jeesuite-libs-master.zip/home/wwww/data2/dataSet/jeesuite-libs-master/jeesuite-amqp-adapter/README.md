# -jeesuite-amqp-adapter
消息队列适配器
