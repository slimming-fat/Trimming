package com.jeesuite.amqp;

/**
 * 
 * 
 * <br>
 * Class Name   : MessageHeaderNames
 *
 * @author jiangwei
 * @version 1.0.0
 * @date 2019年5月19日
 */
public enum MessageHeaderNames {

	requestId,produceAppId,produceBy,tenantId,transactionId,checkUrl
}
