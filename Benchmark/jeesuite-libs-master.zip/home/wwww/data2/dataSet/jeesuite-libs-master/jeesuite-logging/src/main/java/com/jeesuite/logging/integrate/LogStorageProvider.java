package com.jeesuite.logging.integrate;

public interface LogStorageProvider {

	public void storage(ActionLog actionLog);
}
