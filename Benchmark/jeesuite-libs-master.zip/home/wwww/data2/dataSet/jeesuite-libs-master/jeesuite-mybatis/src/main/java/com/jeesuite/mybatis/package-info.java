/**
 * 
 */
/**
 * @description <br>
 * @author <a href="mailto:vakinge@gmail.com">vakin</a>
 * @date 2016年7月4日
 */
package com.jeesuite.mybatis;