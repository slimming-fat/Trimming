package com.jeesuite.mybatis.datasource;

public enum DataSourceType {

	druid,hikariCP
}
