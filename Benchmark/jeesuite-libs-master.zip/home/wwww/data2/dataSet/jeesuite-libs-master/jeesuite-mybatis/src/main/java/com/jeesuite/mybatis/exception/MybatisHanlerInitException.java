package com.jeesuite.mybatis.exception;

public class MybatisHanlerInitException extends RuntimeException {

	private static final long serialVersionUID = 7823413453457349529L;

	public MybatisHanlerInitException(String message) {
		super(message);
	}

	
}
