package com.jeesuite.mybatis.datasource;

/**
 * 
 * <br>
 * Class Name   : DataSourceContextVals
 *
 * @author jiangwei
 * @version 1.0.0
 * @date 2020年4月20日
 */
public class DataSourceContextVals {
	public String tenantId;
	public Boolean master; //
}
