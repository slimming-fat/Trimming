package com.jeesuite.springweb.model;

/**
 * 
 * <br>
 * Class Name   : BaseQueryParam
 *
 * @author jiangwei
 * @version 1.0.0
 * @date 2019年7月9日
 */
public class BaseQueryParam {
	
}
