/**
 *
 */
package net.magja.magento;

import net.magja.soap.SoapClient;
import net.magja.soap.SoapClient;

/**
 * @author andre
 *
 */
public class ConnectionMock extends Connection {

	public ConnectionMock() {
		super();
	}

	public SoapClient getClient() {
		return client;
	}

}
