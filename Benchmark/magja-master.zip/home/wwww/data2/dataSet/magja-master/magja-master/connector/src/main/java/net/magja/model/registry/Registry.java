package net.magja.model.registry;

import net.magja.model.BaseMagentoModel;

/**
 * Created by IntelliJ IDEA.
 * User: kdavey
 * Date: 10/5/11
 * Time: 6:04 PM
 * To change this template use File | Settings | File Templates.
 */
public class Registry extends BaseMagentoModel {
    @Override
    public Object serializeToApi() {
        return "";
    }
}
