package com.varma.kafka;

import org.junit.Test;

import static org.junit.Assert.*;

public class ProducerTest {

    @Test
    public void testKafkaProducer(){
        
    }

}