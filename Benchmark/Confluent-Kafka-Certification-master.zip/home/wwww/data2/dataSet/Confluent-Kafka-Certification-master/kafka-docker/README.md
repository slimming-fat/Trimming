# Kafka Docker

## Source ##
https://docs.confluent.io/current/quickstart/ce-docker-quickstart.html
https://github.com/confluentinc/cp-docker-images/tree/5.2.1-post/examples