package com.vonzhou.example;

/**
 * Created by vonzhou on 16/4/1.
 */
public class MyTestBean {
    private String testStr = "testStr";

    public String getTestStr() {
        return testStr;
    }

    public void setTestStr(String testStr) {
        this.testStr = testStr;
    }
}
