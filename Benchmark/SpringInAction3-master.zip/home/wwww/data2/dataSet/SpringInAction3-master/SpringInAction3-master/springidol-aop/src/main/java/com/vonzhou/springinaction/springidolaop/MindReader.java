package com.vonzhou.springinaction.springidolaop;

public interface MindReader {
  void interceptThoughts(String thoughts);

  String getThoughts();
}