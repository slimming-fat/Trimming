package com.vonzhou.springinaction.springidolaop;

public interface Poem {
  void recite();
}
