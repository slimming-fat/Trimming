package com.vonzhou.springinaction.springidolaop;


/**
 * 乐器接口
 */
public interface Instrument {
    public void play();
}
