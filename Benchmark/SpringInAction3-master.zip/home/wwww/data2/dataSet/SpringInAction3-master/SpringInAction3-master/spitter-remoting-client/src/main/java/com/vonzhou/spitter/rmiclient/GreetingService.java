package com.vonzhou.spitter.rmiclient;

/**
 * Created by vonzhou on 16/4/23.
 */
public interface GreetingService {

    String getGreeting(String name);
}
