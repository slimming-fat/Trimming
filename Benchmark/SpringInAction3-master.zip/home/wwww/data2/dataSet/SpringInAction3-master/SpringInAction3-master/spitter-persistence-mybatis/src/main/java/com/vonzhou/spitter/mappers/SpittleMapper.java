package com.vonzhou.spitter.mappers;

/**
 * Created by vonzhou on 16/7/12.
 */
public interface SpittleMapper {
}
