package com.vonzhou.springinaction.knights;

public class MakeRoundTableRounderQuest implements Quest {

  public void embark() throws QuestException {
    System.out.println("Making round table rounder");
  }

}
