package com.vonzhou.learning.interceptor;

/**
 * Created by vonzhou on 16/7/23.
 */
public class Foo {
    public static void main(String[] args) {
        long a = 12345L;
        System.out.println("hello " + a);
    }
}
