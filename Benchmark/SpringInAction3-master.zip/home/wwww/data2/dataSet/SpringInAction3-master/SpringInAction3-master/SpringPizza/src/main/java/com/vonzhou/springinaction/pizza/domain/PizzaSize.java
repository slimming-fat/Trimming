package com.vonzhou.springinaction.pizza.domain;

import java.io.Serializable;

public enum PizzaSize implements Serializable {
  SMALL, MEDIUM, LARGE, GINORMOUS;
}
