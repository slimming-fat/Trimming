package com.vonzhou.springinaction.springidolaop;

public interface Performer {
  void perform() throws PerformanceException;
}
