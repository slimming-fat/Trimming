package com.vonzhou.springinaction.springidol;

public interface Contestant {
  void receiveAward();
}
