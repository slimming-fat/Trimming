package com.vonzhou.springinaction.springidolaop;

public interface Instrument {
  public void play();
}
