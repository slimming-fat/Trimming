package com.vonzhou.springinaction.springidolaop;

/**
 * 表演大厅
 * Created by vonzhou on 16/3/31.
 */
public class Auditorium {
    public void turnOnLights(){
        System.out.println("Turn on lights in auditorium..");
    }

    public void turnOffLights(){
        System.out.println("Turn off lights in auditorium..");
    }
}
