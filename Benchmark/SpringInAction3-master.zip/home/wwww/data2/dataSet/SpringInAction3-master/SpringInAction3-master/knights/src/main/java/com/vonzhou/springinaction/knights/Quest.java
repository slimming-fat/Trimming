package com.vonzhou.springinaction.knights;

public interface Quest {
  void embark() throws QuestException;
}
