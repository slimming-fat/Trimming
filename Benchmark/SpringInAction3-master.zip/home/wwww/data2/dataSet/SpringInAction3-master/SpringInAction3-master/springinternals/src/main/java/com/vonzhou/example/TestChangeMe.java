package com.vonzhou.example;

/**
 * Created by vonzhou on 16/4/1.
 */
public class TestChangeMe {
    public void changeMe(){
        System.out.println("changeMe..");
    }
}
