package com.vonzhou.springinaction.springidolaop;

/**
 * gracious 高尚的
 */
public class GraciousContestant implements Contestant {

    public void receiveAward() {
        System.out.println("Why, thank you all very much!");
    }
}
