package com.vonzhou.springinaction.pizza.service;

@SuppressWarnings("serial")
public class PaymentException extends Exception {
  public PaymentException() {}
}
