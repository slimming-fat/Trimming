package com.vonzhou.springinaction.springidolaop;

public interface Thinker {
    void thinkOfSomething(String thoughts);
}