package com.vonzhou.example;

/**
 * Created by vonzhou on 16/4/1.
 */
public class HelloBean {
    private  String name;
    private String addr;
    public HelloBean(String name, String addr){
        this.name = name;
        this.addr = addr;
    }
}
