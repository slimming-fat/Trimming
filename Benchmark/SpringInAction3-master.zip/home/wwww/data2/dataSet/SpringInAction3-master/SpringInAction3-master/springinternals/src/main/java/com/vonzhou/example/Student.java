package com.vonzhou.example;

/**
 * Created by vonzhou on 16/4/1.
 */
public class Student extends User{
    @Override
    public void showMe() {
        System.out.println("i am student");
    }
}
