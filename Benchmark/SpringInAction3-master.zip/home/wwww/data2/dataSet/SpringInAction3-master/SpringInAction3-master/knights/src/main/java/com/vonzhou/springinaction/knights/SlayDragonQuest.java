package com.vonzhou.springinaction.knights;

/**
 * slay : 杀害
 */
public class SlayDragonQuest implements Quest {

  public void embark() throws QuestException {
    System.out.println("Slaying Dragon!");
  }

}
