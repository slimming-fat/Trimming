package com.vonzhou.example;

/**
 * Created by vonzhou on 16/4/1.
 */
public class User {
    public void showMe(){
        System.out.println("i am user");
    }
}
