package com.vonzhou.springinaction.springidol;

public interface Performer {
  void perform() throws PerformanceException;
}
