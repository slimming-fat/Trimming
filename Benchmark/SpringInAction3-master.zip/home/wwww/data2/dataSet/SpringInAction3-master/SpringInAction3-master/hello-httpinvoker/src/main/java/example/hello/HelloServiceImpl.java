package example.hello;

/**
 * Created by vonzhou on 16/4/24.
 */
public class HelloServiceImpl implements HelloService{
    public String sayHi(String name) {
        return "Fuck " + name;
    }
}
