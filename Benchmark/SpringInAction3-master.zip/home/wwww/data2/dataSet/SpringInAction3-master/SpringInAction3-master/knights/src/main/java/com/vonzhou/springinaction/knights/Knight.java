package com.vonzhou.springinaction.knights;

public interface Knight {
  void embarkOnQuest() throws QuestException;
}
