package com.vonzhou.springinaction.springidol;

public interface Poem {
  void recite();
}
