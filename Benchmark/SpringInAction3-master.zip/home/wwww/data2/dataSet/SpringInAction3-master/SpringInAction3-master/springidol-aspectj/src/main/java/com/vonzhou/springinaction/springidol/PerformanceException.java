package com.vonzhou.springinaction.springidol;

public class PerformanceException extends Exception {
  private static final long serialVersionUID = 1L;

}
