package com.vonzhou.springinaction.springidolaop;

/**
 * Created by vonzhou on 16/3/31.
 * P 53  演示SpEL的用法
 */
public class SongSelector {
    public String selectSong(){
        return  "Summertrain";
    }
}
