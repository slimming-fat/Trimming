package example.hello;

/**
 * Created by vonzhou on 16/4/24.
 */
public interface HelloService {
    public String sayHi(String name);
}
