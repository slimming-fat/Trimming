package com.vonzhou.springinaction.springidolaop;

/**
 * 萨克斯
 */
public class Saxophone implements Instrument {
    public Saxophone() {
    }

    public void play() {
        System.out.println("TOOT TOOT TOOT");
    }
}
