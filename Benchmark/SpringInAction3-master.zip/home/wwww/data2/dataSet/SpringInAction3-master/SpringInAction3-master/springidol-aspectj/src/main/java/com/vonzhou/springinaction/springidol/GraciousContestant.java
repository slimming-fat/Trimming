package com.vonzhou.springinaction.springidol;


public class GraciousContestant implements Contestant {

  public void receiveAward() {
    System.out.println("Why, thank you all very much!");
  }
}
