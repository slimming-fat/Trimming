package com.vonzhou.hello;

/**
 * Created by vonzhou on 16/4/24.
 */
public interface HelloService {
    public String sayHi(String name);
    public Dog getDog();
}
