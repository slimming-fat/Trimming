
## Override

配合
https://github.com/ddssingsong/webrtc_android
使用的一套服务器java版本

实现基本的信令收发，配合Android端实现基本的呼叫、响铃、挂断、语音通话、视频通话的功能


Android访问地址为ws://ip:port/websocket

## 分支介绍

*master*

配合Android端Java版本业务逻辑，实现基本的呼叫、响铃、语音通话、视频通话的功能

*nodejs_copy*

将nodejs版本https://github.com/ddssingsong/webrtc_server_node 使用java写了一遍



  
    
601332720（1群） 619413989 （2群） 707717173 （3群）





























