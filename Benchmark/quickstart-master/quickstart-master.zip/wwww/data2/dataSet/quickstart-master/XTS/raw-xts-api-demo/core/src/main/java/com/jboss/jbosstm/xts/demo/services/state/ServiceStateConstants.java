/*
 * JBoss, Home of Professional Open Source
 * Copyright 2016, Red Hat, Inc., and others contributors as indicated
 * by the @authors tag. All rights reserved.
 * See the copyright.txt in the distribution for a
 * full listing of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU Lesser General Public License, v. 2.1.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License,
 * v.2.1 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 */
package com.jboss.jbosstm.xts.demo.services.state;

/**
 * constant values used by ServiceStateManager and its subclasses
 */
public class ServiceStateConstants {
    /**
     * bit mask identifying no tx
     */
    public static final int TX_TYPE_NONE = 0;
    /**
     * bit mask identifying a WS-AT tx
     */
    public static final int TX_TYPE_AT = 1;
    /**
     * bit mask identifying a WS-BA tx
     */
    public static final int TX_TYPE_BA = 2;
    /**
     * bit mask identifying the union of both TX types
     */
    public static final int TX_TYPE_BOTH = TX_TYPE_AT | TX_TYPE_BA;
}
