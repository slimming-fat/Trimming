package com.xiaofu.confirm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootRabbitmqConfirmApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootRabbitmqConfirmApplication.class, args);
	}

}
