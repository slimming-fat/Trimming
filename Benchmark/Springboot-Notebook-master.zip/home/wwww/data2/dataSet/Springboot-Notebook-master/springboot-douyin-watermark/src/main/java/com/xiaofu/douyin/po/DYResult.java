package com.xiaofu.douyin.po;

import java.util.List;

public class DYResult {


    /**
     * status_code : 0
     * item_list : [{"share_info":{"share_title":"总是接到推销电话？你们整个小区的业主信息也就三四百块！内容详细到让你冒汗！#西安 #推销","share_weibo_desc":"#在抖音，记录美好生活#总是接到推销电话？你们整个小区的业主信息也就三四百块！内容详细到让你冒汗！#西安 #推销","share_desc":"在抖音，记录美好生活"},"duration":50851,"risk_infos":{"type":0,"content":"","warn":false},"author_user_id":95298633783,"geofencing":null,"desc":"总是接到推销电话？你们整个小区的业主信息也就三四百块！内容详细到让你冒汗！#西安 #推销","music":{"cover_medium":{"url_list":["https://p29-dy.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p9-dy.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p1-dy-ipv6.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038"],"uri":"315ca0000934aa3af8f4d"},"cover_thumb":{"url_list":["https://p3-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p9-dy.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038"],"uri":"315ca0000934aa3af8f4d"},"play_url":{"uri":"http://p1-dy.byteimg.com/obj/ies-music/6872206500673424136.mp3","url_list":["http://p1-dy.byteimg.com/obj/ies-music/6872206500673424136.mp3","http://p9-dy.byteimg.com/obj/ies-music/6872206500673424136.mp3"]},"position":null,"id":6872206531149008000,"mid":"6872206531149007630","author":"陕西都市快报","cover_hd":{"uri":"315ca0000934aa3af8f4d","url_list":["https://p3-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p29-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038"]},"title":"@陕西都市快报创作的原声","cover_large":{"uri":"315ca0000934aa3af8f4d","url_list":["https://p3-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p29-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038"]},"duration":50,"status":1},"text_extra":[{"start":37,"end":40,"type":1,"hashtag_name":"西安","hashtag_id":1570737659003905},{"hashtag_id":1575803422599182,"start":41,"end":44,"type":1,"hashtag_name":"推销"}],"comment_list":null,"long_video":null,"is_preview":0,"cha_list":[{"cid":"1570737659003905","desc":"","cover_item":{"uri":"douyin-admin-obj/157073765900390580207","url_list":["https://p3-dy.bytecdn.cn/live/100x100/douyin-admin-obj/157073765900390580207.jpg","https://p9-dy.bytecdn.cn/live/100x100/douyin-admin-obj/157073765900390580207.jpg","https://p9-dy.bytecdn.cn/live/100x100/douyin-admin-obj/157073765900390580207.jpg"]},"is_commerce":false,"hash_tag_profile":"douyin-admin-obj/157073765900390580207","cha_name":"西安","user_count":0,"connect_music":null,"type":0,"view_count":0}],"statistics":{"aweme_id":"6872206494385982733","comment_count":28075,"digg_count":169395,"play_count":0},"aweme_type":4,"video_text":null,"is_live_replay":false,"video_labels":null,"image_infos":null,"group_id":6872206494385982000,"aweme_id":"6872206494385982733","forward_id":"0","promotions":null,"author":{"geofencing":null,"policy_version":null,"type_label":null,"signature":"陕西电视台都市青春频道官方抖音","unique_id":"dushikuaibao2","followers_detail":null,"avatar_larger":{"uri":"315ca0000934aa3af8f4d","url_list":["https://p26-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p3-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p29-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038"]},"avatar_thumb":{"uri":"315ca0000934aa3af8f4d","url_list":["https://p29-dy.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p3-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038"]},"avatar_medium":{"uri":"315ca0000934aa3af8f4d","url_list":["https://p26-dy.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p3-dy-ipv6.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038"]},"platform_sync_info":null,"uid":"95298633783","short_id":"703640235","nickname":"陕西都市快报"},"video":{"height":1280,"origin_cover":{"url_list":["https://p29-dy.byteimg.com/tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267~tplv-dy-360p.jpeg?from=2563711402","https://p6-dy-ipv6.byteimg.com/tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267~tplv-dy-360p.jpeg?from=2563711402","https://p26-dy.byteimg.com/tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267~tplv-dy-360p.jpeg?from=2563711402"],"uri":"tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267"},"ratio":"540p","duration":50851,"bit_rate":null,"vid":"v0200f120000btffmhubfd8of56ksdpg","play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/playwm/?video_id=v0200f120000btffmhubfd8of56ksdpg&ratio=720p&line=0"],"uri":"v0200f120000btffmhubfd8of56ksdpg"},"cover":{"uri":"tos-cn-p-0015/2147d688f140434e94c7b76c430a6054","url_list":["https://p9-dy.byteimg.com/img/tos-cn-p-0015/2147d688f140434e94c7b76c430a6054~c5_300x400.jpeg?from=2563711402_large","https://p3-dy-ipv6.byteimg.com/img/tos-cn-p-0015/2147d688f140434e94c7b76c430a6054~c5_300x400.jpeg?from=2563711402_large","https://p29-dy.byteimg.com/img/tos-cn-p-0015/2147d688f140434e94c7b76c430a6054~c5_300x400.jpeg?from=2563711402_large"]},"width":720,"dynamic_cover":{"uri":"tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268","url_list":["https://p3-dy-ipv6.byteimg.com/obj/tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268?from=2563711402_large","https://p1-dy-ipv6.byteimg.com/obj/tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268?from=2563711402_large","https://p29-dy.byteimg.com/obj/tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268?from=2563711402_large"]},"has_watermark":true},"label_top_text":null,"create_time":1600060266,"share_url":"https://www.iesdouyin.com/share/video/6872206494385982733/?region=&mid=6872206531149007630&u_code=48&titleType=title"}]
     * ab_type : 1
     * extra : {"now":1600078029000,"logid":"202009141807090101980582241402CA80"}
     */

    private int status_code;
    private int ab_type;
    private ExtraBean extra;
    private List<ItemListBean> item_list;

    public int getStatus_code() {
        return status_code;
    }

    public void setStatus_code(int status_code) {
        this.status_code = status_code;
    }

    public int getAb_type() {
        return ab_type;
    }

    public void setAb_type(int ab_type) {
        this.ab_type = ab_type;
    }

    public ExtraBean getExtra() {
        return extra;
    }

    public void setExtra(ExtraBean extra) {
        this.extra = extra;
    }

    public List<ItemListBean> getItem_list() {
        return item_list;
    }

    public void setItem_list(List<ItemListBean> item_list) {
        this.item_list = item_list;
    }

    public static class ExtraBean {
        /**
         * now : 1600078029000
         * logid : 202009141807090101980582241402CA80
         */

        private long now;
        private String logid;

        public long getNow() {
            return now;
        }

        public void setNow(long now) {
            this.now = now;
        }

        public String getLogid() {
            return logid;
        }

        public void setLogid(String logid) {
            this.logid = logid;
        }
    }

    public static class ItemListBean {
        /**
         * share_info : {"share_title":"总是接到推销电话？你们整个小区的业主信息也就三四百块！内容详细到让你冒汗！#西安 #推销","share_weibo_desc":"#在抖音，记录美好生活#总是接到推销电话？你们整个小区的业主信息也就三四百块！内容详细到让你冒汗！#西安 #推销","share_desc":"在抖音，记录美好生活"}
         * duration : 50851
         * risk_infos : {"type":0,"content":"","warn":false}
         * author_user_id : 95298633783
         * geofencing : null
         * desc : 总是接到推销电话？你们整个小区的业主信息也就三四百块！内容详细到让你冒汗！#西安 #推销
         * music : {"cover_medium":{"url_list":["https://p29-dy.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p9-dy.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p1-dy-ipv6.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038"],"uri":"315ca0000934aa3af8f4d"},"cover_thumb":{"url_list":["https://p3-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p9-dy.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038"],"uri":"315ca0000934aa3af8f4d"},"play_url":{"uri":"http://p1-dy.byteimg.com/obj/ies-music/6872206500673424136.mp3","url_list":["http://p1-dy.byteimg.com/obj/ies-music/6872206500673424136.mp3","http://p9-dy.byteimg.com/obj/ies-music/6872206500673424136.mp3"]},"position":null,"id":6872206531149008000,"mid":"6872206531149007630","author":"陕西都市快报","cover_hd":{"uri":"315ca0000934aa3af8f4d","url_list":["https://p3-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p29-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038"]},"title":"@陕西都市快报创作的原声","cover_large":{"uri":"315ca0000934aa3af8f4d","url_list":["https://p3-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p29-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038"]},"duration":50,"status":1}
         * text_extra : [{"start":37,"end":40,"type":1,"hashtag_name":"西安","hashtag_id":1570737659003905},{"hashtag_id":1575803422599182,"start":41,"end":44,"type":1,"hashtag_name":"推销"}]
         * comment_list : null
         * long_video : null
         * is_preview : 0
         * cha_list : [{"cid":"1570737659003905","desc":"","cover_item":{"uri":"douyin-admin-obj/157073765900390580207","url_list":["https://p3-dy.bytecdn.cn/live/100x100/douyin-admin-obj/157073765900390580207.jpg","https://p9-dy.bytecdn.cn/live/100x100/douyin-admin-obj/157073765900390580207.jpg","https://p9-dy.bytecdn.cn/live/100x100/douyin-admin-obj/157073765900390580207.jpg"]},"is_commerce":false,"hash_tag_profile":"douyin-admin-obj/157073765900390580207","cha_name":"西安","user_count":0,"connect_music":null,"type":0,"view_count":0}]
         * statistics : {"aweme_id":"6872206494385982733","comment_count":28075,"digg_count":169395,"play_count":0}
         * aweme_type : 4
         * video_text : null
         * is_live_replay : false
         * video_labels : null
         * image_infos : null
         * group_id : 6872206494385982000
         * aweme_id : 6872206494385982733
         * forward_id : 0
         * promotions : null
         * author : {"geofencing":null,"policy_version":null,"type_label":null,"signature":"陕西电视台都市青春频道官方抖音","unique_id":"dushikuaibao2","followers_detail":null,"avatar_larger":{"uri":"315ca0000934aa3af8f4d","url_list":["https://p26-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p3-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p29-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038"]},"avatar_thumb":{"uri":"315ca0000934aa3af8f4d","url_list":["https://p29-dy.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p3-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038"]},"avatar_medium":{"uri":"315ca0000934aa3af8f4d","url_list":["https://p26-dy.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p3-dy-ipv6.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038"]},"platform_sync_info":null,"uid":"95298633783","short_id":"703640235","nickname":"陕西都市快报"}
         * video : {"height":1280,"origin_cover":{"url_list":["https://p29-dy.byteimg.com/tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267~tplv-dy-360p.jpeg?from=2563711402","https://p6-dy-ipv6.byteimg.com/tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267~tplv-dy-360p.jpeg?from=2563711402","https://p26-dy.byteimg.com/tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267~tplv-dy-360p.jpeg?from=2563711402"],"uri":"tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267"},"ratio":"540p","duration":50851,"bit_rate":null,"vid":"v0200f120000btffmhubfd8of56ksdpg","play_addr":{"url_list":["https://aweme.snssdk.com/aweme/v1/playwm/?video_id=v0200f120000btffmhubfd8of56ksdpg&ratio=720p&line=0"],"uri":"v0200f120000btffmhubfd8of56ksdpg"},"cover":{"uri":"tos-cn-p-0015/2147d688f140434e94c7b76c430a6054","url_list":["https://p9-dy.byteimg.com/img/tos-cn-p-0015/2147d688f140434e94c7b76c430a6054~c5_300x400.jpeg?from=2563711402_large","https://p3-dy-ipv6.byteimg.com/img/tos-cn-p-0015/2147d688f140434e94c7b76c430a6054~c5_300x400.jpeg?from=2563711402_large","https://p29-dy.byteimg.com/img/tos-cn-p-0015/2147d688f140434e94c7b76c430a6054~c5_300x400.jpeg?from=2563711402_large"]},"width":720,"dynamic_cover":{"uri":"tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268","url_list":["https://p3-dy-ipv6.byteimg.com/obj/tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268?from=2563711402_large","https://p1-dy-ipv6.byteimg.com/obj/tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268?from=2563711402_large","https://p29-dy.byteimg.com/obj/tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268?from=2563711402_large"]},"has_watermark":true}
         * label_top_text : null
         * create_time : 1600060266
         * share_url : https://www.iesdouyin.com/share/video/6872206494385982733/?region=&mid=6872206531149007630&u_code=48&titleType=title
         */

        private ShareInfoBean share_info;
        private int duration;
        private RiskInfosBean risk_infos;
        private long author_user_id;
        private Object geofencing;
        private String desc;
        private MusicBean music;
        private Object comment_list;
        private Object long_video;
        private int is_preview;
        private StatisticsBean statistics;
        private int aweme_type;
        private Object video_text;
        private boolean is_live_replay;
        private Object video_labels;
        private Object image_infos;
        private long group_id;
        private String aweme_id;
        private String forward_id;
        private Object promotions;
        private AuthorBean author;
        private VideoBean video;
        private Object label_top_text;
        private int create_time;
        private String share_url;
        private List<TextExtraBean> text_extra;
        private List<ChaListBean> cha_list;

        public ShareInfoBean getShare_info() {
            return share_info;
        }

        public void setShare_info(ShareInfoBean share_info) {
            this.share_info = share_info;
        }

        public int getDuration() {
            return duration;
        }

        public void setDuration(int duration) {
            this.duration = duration;
        }

        public RiskInfosBean getRisk_infos() {
            return risk_infos;
        }

        public void setRisk_infos(RiskInfosBean risk_infos) {
            this.risk_infos = risk_infos;
        }

        public long getAuthor_user_id() {
            return author_user_id;
        }

        public void setAuthor_user_id(long author_user_id) {
            this.author_user_id = author_user_id;
        }

        public Object getGeofencing() {
            return geofencing;
        }

        public void setGeofencing(Object geofencing) {
            this.geofencing = geofencing;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        public MusicBean getMusic() {
            return music;
        }

        public void setMusic(MusicBean music) {
            this.music = music;
        }

        public Object getComment_list() {
            return comment_list;
        }

        public void setComment_list(Object comment_list) {
            this.comment_list = comment_list;
        }

        public Object getLong_video() {
            return long_video;
        }

        public void setLong_video(Object long_video) {
            this.long_video = long_video;
        }

        public int getIs_preview() {
            return is_preview;
        }

        public void setIs_preview(int is_preview) {
            this.is_preview = is_preview;
        }

        public StatisticsBean getStatistics() {
            return statistics;
        }

        public void setStatistics(StatisticsBean statistics) {
            this.statistics = statistics;
        }

        public int getAweme_type() {
            return aweme_type;
        }

        public void setAweme_type(int aweme_type) {
            this.aweme_type = aweme_type;
        }

        public Object getVideo_text() {
            return video_text;
        }

        public void setVideo_text(Object video_text) {
            this.video_text = video_text;
        }

        public boolean isIs_live_replay() {
            return is_live_replay;
        }

        public void setIs_live_replay(boolean is_live_replay) {
            this.is_live_replay = is_live_replay;
        }

        public Object getVideo_labels() {
            return video_labels;
        }

        public void setVideo_labels(Object video_labels) {
            this.video_labels = video_labels;
        }

        public Object getImage_infos() {
            return image_infos;
        }

        public void setImage_infos(Object image_infos) {
            this.image_infos = image_infos;
        }

        public long getGroup_id() {
            return group_id;
        }

        public void setGroup_id(long group_id) {
            this.group_id = group_id;
        }

        public String getAweme_id() {
            return aweme_id;
        }

        public void setAweme_id(String aweme_id) {
            this.aweme_id = aweme_id;
        }

        public String getForward_id() {
            return forward_id;
        }

        public void setForward_id(String forward_id) {
            this.forward_id = forward_id;
        }

        public Object getPromotions() {
            return promotions;
        }

        public void setPromotions(Object promotions) {
            this.promotions = promotions;
        }

        public AuthorBean getAuthor() {
            return author;
        }

        public void setAuthor(AuthorBean author) {
            this.author = author;
        }

        public VideoBean getVideo() {
            return video;
        }

        public void setVideo(VideoBean video) {
            this.video = video;
        }

        public Object getLabel_top_text() {
            return label_top_text;
        }

        public void setLabel_top_text(Object label_top_text) {
            this.label_top_text = label_top_text;
        }

        public int getCreate_time() {
            return create_time;
        }

        public void setCreate_time(int create_time) {
            this.create_time = create_time;
        }

        public String getShare_url() {
            return share_url;
        }

        public void setShare_url(String share_url) {
            this.share_url = share_url;
        }

        public List<TextExtraBean> getText_extra() {
            return text_extra;
        }

        public void setText_extra(List<TextExtraBean> text_extra) {
            this.text_extra = text_extra;
        }

        public List<ChaListBean> getCha_list() {
            return cha_list;
        }

        public void setCha_list(List<ChaListBean> cha_list) {
            this.cha_list = cha_list;
        }

        public static class ShareInfoBean {
            /**
             * share_title : 总是接到推销电话？你们整个小区的业主信息也就三四百块！内容详细到让你冒汗！#西安 #推销
             * share_weibo_desc : #在抖音，记录美好生活#总是接到推销电话？你们整个小区的业主信息也就三四百块！内容详细到让你冒汗！#西安 #推销
             * share_desc : 在抖音，记录美好生活
             */

            private String share_title;
            private String share_weibo_desc;
            private String share_desc;

            public String getShare_title() {
                return share_title;
            }

            public void setShare_title(String share_title) {
                this.share_title = share_title;
            }

            public String getShare_weibo_desc() {
                return share_weibo_desc;
            }

            public void setShare_weibo_desc(String share_weibo_desc) {
                this.share_weibo_desc = share_weibo_desc;
            }

            public String getShare_desc() {
                return share_desc;
            }

            public void setShare_desc(String share_desc) {
                this.share_desc = share_desc;
            }
        }

        public static class RiskInfosBean {
            /**
             * type : 0
             * content :
             * warn : false
             */

            private int type;
            private String content;
            private boolean warn;

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public boolean isWarn() {
                return warn;
            }

            public void setWarn(boolean warn) {
                this.warn = warn;
            }
        }

        public static class MusicBean {
            /**
             * cover_medium : {"url_list":["https://p29-dy.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p9-dy.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p1-dy-ipv6.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038"],"uri":"315ca0000934aa3af8f4d"}
             * cover_thumb : {"url_list":["https://p3-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p9-dy.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038"],"uri":"315ca0000934aa3af8f4d"}
             * play_url : {"uri":"http://p1-dy.byteimg.com/obj/ies-music/6872206500673424136.mp3","url_list":["http://p1-dy.byteimg.com/obj/ies-music/6872206500673424136.mp3","http://p9-dy.byteimg.com/obj/ies-music/6872206500673424136.mp3"]}
             * position : null
             * id : 6872206531149008000
             * mid : 6872206531149007630
             * author : 陕西都市快报
             * cover_hd : {"uri":"315ca0000934aa3af8f4d","url_list":["https://p3-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p29-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038"]}
             * title : @陕西都市快报创作的原声
             * cover_large : {"uri":"315ca0000934aa3af8f4d","url_list":["https://p3-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p29-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038"]}
             * duration : 50
             * status : 1
             */

            private CoverMediumBean cover_medium;
            private CoverThumbBean cover_thumb;
            private PlayUrlBean play_url;
            private Object position;
            private long id;
            private String mid;
            private String author;
            private CoverHdBean cover_hd;
            private String title;
            private CoverLargeBean cover_large;
            private int duration;
            private int status;

            public CoverMediumBean getCover_medium() {
                return cover_medium;
            }

            public void setCover_medium(CoverMediumBean cover_medium) {
                this.cover_medium = cover_medium;
            }

            public CoverThumbBean getCover_thumb() {
                return cover_thumb;
            }

            public void setCover_thumb(CoverThumbBean cover_thumb) {
                this.cover_thumb = cover_thumb;
            }

            public PlayUrlBean getPlay_url() {
                return play_url;
            }

            public void setPlay_url(PlayUrlBean play_url) {
                this.play_url = play_url;
            }

            public Object getPosition() {
                return position;
            }

            public void setPosition(Object position) {
                this.position = position;
            }

            public long getId() {
                return id;
            }

            public void setId(long id) {
                this.id = id;
            }

            public String getMid() {
                return mid;
            }

            public void setMid(String mid) {
                this.mid = mid;
            }

            public String getAuthor() {
                return author;
            }

            public void setAuthor(String author) {
                this.author = author;
            }

            public CoverHdBean getCover_hd() {
                return cover_hd;
            }

            public void setCover_hd(CoverHdBean cover_hd) {
                this.cover_hd = cover_hd;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public CoverLargeBean getCover_large() {
                return cover_large;
            }

            public void setCover_large(CoverLargeBean cover_large) {
                this.cover_large = cover_large;
            }

            public int getDuration() {
                return duration;
            }

            public void setDuration(int duration) {
                this.duration = duration;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public static class CoverMediumBean {
                /**
                 * url_list : ["https://p29-dy.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p9-dy.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p1-dy-ipv6.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038"]
                 * uri : 315ca0000934aa3af8f4d
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }

            public static class CoverThumbBean {
                /**
                 * url_list : ["https://p3-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p9-dy.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038"]
                 * uri : 315ca0000934aa3af8f4d
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }

            public static class PlayUrlBean {
                /**
                 * uri : http://p1-dy.byteimg.com/obj/ies-music/6872206500673424136.mp3
                 * url_list : ["http://p1-dy.byteimg.com/obj/ies-music/6872206500673424136.mp3","http://p9-dy.byteimg.com/obj/ies-music/6872206500673424136.mp3"]
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }

            public static class CoverHdBean {
                /**
                 * uri : 315ca0000934aa3af8f4d
                 * url_list : ["https://p3-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p29-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038"]
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }

            public static class CoverLargeBean {
                /**
                 * uri : 315ca0000934aa3af8f4d
                 * url_list : ["https://p3-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p29-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038"]
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }
        }

        public static class StatisticsBean {
            /**
             * aweme_id : 6872206494385982733
             * comment_count : 28075
             * digg_count : 169395
             * play_count : 0
             */

            private String aweme_id;
            private int comment_count;
            private int digg_count;
            private int play_count;

            public String getAweme_id() {
                return aweme_id;
            }

            public void setAweme_id(String aweme_id) {
                this.aweme_id = aweme_id;
            }

            public int getComment_count() {
                return comment_count;
            }

            public void setComment_count(int comment_count) {
                this.comment_count = comment_count;
            }

            public int getDigg_count() {
                return digg_count;
            }

            public void setDigg_count(int digg_count) {
                this.digg_count = digg_count;
            }

            public int getPlay_count() {
                return play_count;
            }

            public void setPlay_count(int play_count) {
                this.play_count = play_count;
            }
        }

        public static class AuthorBean {
            /**
             * geofencing : null
             * policy_version : null
             * type_label : null
             * signature : 陕西电视台都市青春频道官方抖音
             * unique_id : dushikuaibao2
             * followers_detail : null
             * avatar_larger : {"uri":"315ca0000934aa3af8f4d","url_list":["https://p26-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p3-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p29-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038"]}
             * avatar_thumb : {"uri":"315ca0000934aa3af8f4d","url_list":["https://p29-dy.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p3-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038"]}
             * avatar_medium : {"uri":"315ca0000934aa3af8f4d","url_list":["https://p26-dy.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p3-dy-ipv6.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038"]}
             * platform_sync_info : null
             * uid : 95298633783
             * short_id : 703640235
             * nickname : 陕西都市快报
             */

            private Object geofencing;
            private Object policy_version;
            private Object type_label;
            private String signature;
            private String unique_id;
            private Object followers_detail;
            private AvatarLargerBean avatar_larger;
            private AvatarThumbBean avatar_thumb;
            private AvatarMediumBean avatar_medium;
            private Object platform_sync_info;
            private String uid;
            private String short_id;
            private String nickname;

            public Object getGeofencing() {
                return geofencing;
            }

            public void setGeofencing(Object geofencing) {
                this.geofencing = geofencing;
            }

            public Object getPolicy_version() {
                return policy_version;
            }

            public void setPolicy_version(Object policy_version) {
                this.policy_version = policy_version;
            }

            public Object getType_label() {
                return type_label;
            }

            public void setType_label(Object type_label) {
                this.type_label = type_label;
            }

            public String getSignature() {
                return signature;
            }

            public void setSignature(String signature) {
                this.signature = signature;
            }

            public String getUnique_id() {
                return unique_id;
            }

            public void setUnique_id(String unique_id) {
                this.unique_id = unique_id;
            }

            public Object getFollowers_detail() {
                return followers_detail;
            }

            public void setFollowers_detail(Object followers_detail) {
                this.followers_detail = followers_detail;
            }

            public AvatarLargerBean getAvatar_larger() {
                return avatar_larger;
            }

            public void setAvatar_larger(AvatarLargerBean avatar_larger) {
                this.avatar_larger = avatar_larger;
            }

            public AvatarThumbBean getAvatar_thumb() {
                return avatar_thumb;
            }

            public void setAvatar_thumb(AvatarThumbBean avatar_thumb) {
                this.avatar_thumb = avatar_thumb;
            }

            public AvatarMediumBean getAvatar_medium() {
                return avatar_medium;
            }

            public void setAvatar_medium(AvatarMediumBean avatar_medium) {
                this.avatar_medium = avatar_medium;
            }

            public Object getPlatform_sync_info() {
                return platform_sync_info;
            }

            public void setPlatform_sync_info(Object platform_sync_info) {
                this.platform_sync_info = platform_sync_info;
            }

            public String getUid() {
                return uid;
            }

            public void setUid(String uid) {
                this.uid = uid;
            }

            public String getShort_id() {
                return short_id;
            }

            public void setShort_id(String short_id) {
                this.short_id = short_id;
            }

            public String getNickname() {
                return nickname;
            }

            public void setNickname(String nickname) {
                this.nickname = nickname;
            }

            public static class AvatarLargerBean {
                /**
                 * uri : 315ca0000934aa3af8f4d
                 * url_list : ["https://p26-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p3-dy-ipv6.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p29-dy.byteimg.com/aweme/1080x1080/315ca0000934aa3af8f4d.jpeg?from=4010531038"]
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }

            public static class AvatarThumbBean {
                /**
                 * uri : 315ca0000934aa3af8f4d
                 * url_list : ["https://p29-dy.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p3-dy-ipv6.byteimg.com/aweme/100x100/315ca0000934aa3af8f4d.jpeg?from=4010531038"]
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }

            public static class AvatarMediumBean {
                /**
                 * uri : 315ca0000934aa3af8f4d
                 * url_list : ["https://p26-dy.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p6-dy-ipv6.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038","https://p3-dy-ipv6.byteimg.com/aweme/720x720/315ca0000934aa3af8f4d.jpeg?from=4010531038"]
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }
        }

        public static class VideoBean {
            /**
             * height : 1280
             * origin_cover : {"url_list":["https://p29-dy.byteimg.com/tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267~tplv-dy-360p.jpeg?from=2563711402","https://p6-dy-ipv6.byteimg.com/tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267~tplv-dy-360p.jpeg?from=2563711402","https://p26-dy.byteimg.com/tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267~tplv-dy-360p.jpeg?from=2563711402"],"uri":"tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267"}
             * ratio : 540p
             * duration : 50851
             * bit_rate : null
             * vid : v0200f120000btffmhubfd8of56ksdpg
             * play_addr : {"url_list":["https://aweme.snssdk.com/aweme/v1/playwm/?video_id=v0200f120000btffmhubfd8of56ksdpg&ratio=720p&line=0"],"uri":"v0200f120000btffmhubfd8of56ksdpg"}
             * cover : {"uri":"tos-cn-p-0015/2147d688f140434e94c7b76c430a6054","url_list":["https://p9-dy.byteimg.com/img/tos-cn-p-0015/2147d688f140434e94c7b76c430a6054~c5_300x400.jpeg?from=2563711402_large","https://p3-dy-ipv6.byteimg.com/img/tos-cn-p-0015/2147d688f140434e94c7b76c430a6054~c5_300x400.jpeg?from=2563711402_large","https://p29-dy.byteimg.com/img/tos-cn-p-0015/2147d688f140434e94c7b76c430a6054~c5_300x400.jpeg?from=2563711402_large"]}
             * width : 720
             * dynamic_cover : {"uri":"tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268","url_list":["https://p3-dy-ipv6.byteimg.com/obj/tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268?from=2563711402_large","https://p1-dy-ipv6.byteimg.com/obj/tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268?from=2563711402_large","https://p29-dy.byteimg.com/obj/tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268?from=2563711402_large"]}
             * has_watermark : true
             */

            private int height;
            private OriginCoverBean origin_cover;
            private String ratio;
            private int duration;
            private Object bit_rate;
            private String vid;
            private PlayAddrBean play_addr;
            private CoverBean cover;
            private int width;
            private DynamicCoverBean dynamic_cover;
            private boolean has_watermark;

            public int getHeight() {
                return height;
            }

            public void setHeight(int height) {
                this.height = height;
            }

            public OriginCoverBean getOrigin_cover() {
                return origin_cover;
            }

            public void setOrigin_cover(OriginCoverBean origin_cover) {
                this.origin_cover = origin_cover;
            }

            public String getRatio() {
                return ratio;
            }

            public void setRatio(String ratio) {
                this.ratio = ratio;
            }

            public int getDuration() {
                return duration;
            }

            public void setDuration(int duration) {
                this.duration = duration;
            }

            public Object getBit_rate() {
                return bit_rate;
            }

            public void setBit_rate(Object bit_rate) {
                this.bit_rate = bit_rate;
            }

            public String getVid() {
                return vid;
            }

            public void setVid(String vid) {
                this.vid = vid;
            }

            public PlayAddrBean getPlay_addr() {
                return play_addr;
            }

            public void setPlay_addr(PlayAddrBean play_addr) {
                this.play_addr = play_addr;
            }

            public CoverBean getCover() {
                return cover;
            }

            public void setCover(CoverBean cover) {
                this.cover = cover;
            }

            public int getWidth() {
                return width;
            }

            public void setWidth(int width) {
                this.width = width;
            }

            public DynamicCoverBean getDynamic_cover() {
                return dynamic_cover;
            }

            public void setDynamic_cover(DynamicCoverBean dynamic_cover) {
                this.dynamic_cover = dynamic_cover;
            }

            public boolean isHas_watermark() {
                return has_watermark;
            }

            public void setHas_watermark(boolean has_watermark) {
                this.has_watermark = has_watermark;
            }

            public static class OriginCoverBean {
                /**
                 * url_list : ["https://p29-dy.byteimg.com/tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267~tplv-dy-360p.jpeg?from=2563711402","https://p6-dy-ipv6.byteimg.com/tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267~tplv-dy-360p.jpeg?from=2563711402","https://p26-dy.byteimg.com/tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267~tplv-dy-360p.jpeg?from=2563711402"]
                 * uri : tos-cn-p-0015/369a965545694a818c62471982ca6ad0_1600060267
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }

            public static class PlayAddrBean {
                /**
                 * url_list : ["https://aweme.snssdk.com/aweme/v1/playwm/?video_id=v0200f120000btffmhubfd8of56ksdpg&ratio=720p&line=0"]
                 * uri : v0200f120000btffmhubfd8of56ksdpg
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }

            public static class CoverBean {
                /**
                 * uri : tos-cn-p-0015/2147d688f140434e94c7b76c430a6054
                 * url_list : ["https://p9-dy.byteimg.com/img/tos-cn-p-0015/2147d688f140434e94c7b76c430a6054~c5_300x400.jpeg?from=2563711402_large","https://p3-dy-ipv6.byteimg.com/img/tos-cn-p-0015/2147d688f140434e94c7b76c430a6054~c5_300x400.jpeg?from=2563711402_large","https://p29-dy.byteimg.com/img/tos-cn-p-0015/2147d688f140434e94c7b76c430a6054~c5_300x400.jpeg?from=2563711402_large"]
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }

            public static class DynamicCoverBean {
                /**
                 * uri : tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268
                 * url_list : ["https://p3-dy-ipv6.byteimg.com/obj/tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268?from=2563711402_large","https://p1-dy-ipv6.byteimg.com/obj/tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268?from=2563711402_large","https://p29-dy.byteimg.com/obj/tos-cn-p-0015/64d6a683bbbe49889793274e9cc3d816_1600060268?from=2563711402_large"]
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }
        }

        public static class TextExtraBean {
            /**
             * start : 37
             * end : 40
             * type : 1
             * hashtag_name : 西安
             * hashtag_id : 1570737659003905
             */

            private int start;
            private int end;
            private int type;
            private String hashtag_name;
            private long hashtag_id;

            public int getStart() {
                return start;
            }

            public void setStart(int start) {
                this.start = start;
            }

            public int getEnd() {
                return end;
            }

            public void setEnd(int end) {
                this.end = end;
            }

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public String getHashtag_name() {
                return hashtag_name;
            }

            public void setHashtag_name(String hashtag_name) {
                this.hashtag_name = hashtag_name;
            }

            public long getHashtag_id() {
                return hashtag_id;
            }

            public void setHashtag_id(long hashtag_id) {
                this.hashtag_id = hashtag_id;
            }
        }

        public static class ChaListBean {
            /**
             * cid : 1570737659003905
             * desc :
             * cover_item : {"uri":"douyin-admin-obj/157073765900390580207","url_list":["https://p3-dy.bytecdn.cn/live/100x100/douyin-admin-obj/157073765900390580207.jpg","https://p9-dy.bytecdn.cn/live/100x100/douyin-admin-obj/157073765900390580207.jpg","https://p9-dy.bytecdn.cn/live/100x100/douyin-admin-obj/157073765900390580207.jpg"]}
             * is_commerce : false
             * hash_tag_profile : douyin-admin-obj/157073765900390580207
             * cha_name : 西安
             * user_count : 0
             * connect_music : null
             * type : 0
             * view_count : 0
             */

            private String cid;
            private String desc;
            private CoverItemBean cover_item;
            private boolean is_commerce;
            private String hash_tag_profile;
            private String cha_name;
            private int user_count;
            private Object connect_music;
            private int type;
            private int view_count;

            public String getCid() {
                return cid;
            }

            public void setCid(String cid) {
                this.cid = cid;
            }

            public String getDesc() {
                return desc;
            }

            public void setDesc(String desc) {
                this.desc = desc;
            }

            public CoverItemBean getCover_item() {
                return cover_item;
            }

            public void setCover_item(CoverItemBean cover_item) {
                this.cover_item = cover_item;
            }

            public boolean isIs_commerce() {
                return is_commerce;
            }

            public void setIs_commerce(boolean is_commerce) {
                this.is_commerce = is_commerce;
            }

            public String getHash_tag_profile() {
                return hash_tag_profile;
            }

            public void setHash_tag_profile(String hash_tag_profile) {
                this.hash_tag_profile = hash_tag_profile;
            }

            public String getCha_name() {
                return cha_name;
            }

            public void setCha_name(String cha_name) {
                this.cha_name = cha_name;
            }

            public int getUser_count() {
                return user_count;
            }

            public void setUser_count(int user_count) {
                this.user_count = user_count;
            }

            public Object getConnect_music() {
                return connect_music;
            }

            public void setConnect_music(Object connect_music) {
                this.connect_music = connect_music;
            }

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public int getView_count() {
                return view_count;
            }

            public void setView_count(int view_count) {
                this.view_count = view_count;
            }

            public static class CoverItemBean {
                /**
                 * uri : douyin-admin-obj/157073765900390580207
                 * url_list : ["https://p3-dy.bytecdn.cn/live/100x100/douyin-admin-obj/157073765900390580207.jpg","https://p9-dy.bytecdn.cn/live/100x100/douyin-admin-obj/157073765900390580207.jpg","https://p9-dy.bytecdn.cn/live/100x100/douyin-admin-obj/157073765900390580207.jpg"]
                 */

                private String uri;
                private List<String> url_list;

                public String getUri() {
                    return uri;
                }

                public void setUri(String uri) {
                    this.uri = uri;
                }

                public List<String> getUrl_list() {
                    return url_list;
                }

                public void setUrl_list(List<String> url_list) {
                    this.url_list = url_list;
                }
            }
        }
    }
}
