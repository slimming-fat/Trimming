package com.xiaofu.douyin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDouyinWatermarkApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDouyinWatermarkApplication.class, args);
	}

}
