/*
About the web dev challenge:

http://danicfilip.com/7-day-web-dev-challenge-codepen/

*/