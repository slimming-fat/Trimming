﻿document.write ('<script data-ad-client="ca-pub-3171310320403916" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>');

document.writeln("<div style=\"width:970px;margin:10px auto;\">")
document.writeln('<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>');
document.writeln('<!-- html5tricks-demo-big -->');
document.writeln('<ins class="adsbygoogle"');
document.writeln('     style="display:inline-block;width:970px;height:250px"');
document.writeln('     data-ad-client="ca-pub-3171310320403916"');
document.writeln('     data-ad-slot="1077930102"></ins>');
document.writeln('<script>');
document.writeln('(adsbygoogle = window.adsbygoogle || []).push({});');
document.writeln('</script>');
document.writeln("</div>");

document.write ('<div style="display:none"><script language="javascript" type="text/javascript" src="//js.users.51.la/16741667.js"></script></div>');
document.write ('<div style="display:none"><script language="javascript" type="text/javascript" src="//js.users.51.la/17278758.js"></script></div>');

document.writeln('<style type="text/css">.source-url{font-size:15px;text-align:center}</style>');