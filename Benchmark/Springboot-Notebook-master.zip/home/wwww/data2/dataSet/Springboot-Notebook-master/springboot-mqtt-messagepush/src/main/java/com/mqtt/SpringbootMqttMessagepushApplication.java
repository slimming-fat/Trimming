package com.mqtt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootMqttMessagepushApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootMqttMessagepushApplication.class, args);
	}

}
