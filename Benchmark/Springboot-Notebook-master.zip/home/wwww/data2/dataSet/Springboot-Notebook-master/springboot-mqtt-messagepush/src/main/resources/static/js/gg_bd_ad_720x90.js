﻿/*document.writeln('<div style="margin-left:420px"><div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare" style="margin:10px auto;">');
document.writeln('<a class="bds_tsina"></a>');
document.writeln('<a class="bds_tqq"></a>');
document.writeln('<a class="bds_renren"></a>');
document.writeln('<a class="bds_qzone"></a>');
document.writeln('<a class="bds_douban"></a>');
document.writeln('<a class="bds_xg"></a>');
document.writeln('<span class="bds_more">更多</span>');
document.writeln('<a class="shareCount"></a>');
document.writeln('</div></div>');
document.writeln('<script type="text/javascript" id="bdshare_js" data="type=tools" ></script>');
document.writeln('<script type="text/javascript" id="bdshell_js"></script>');
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();*/


//document.writeln("<div style=\"width:728px;margin:10px auto;\"><script type=\"text/javascript\"><!--");
//document.writeln("google_ad_client = \"ca-pub-0107013120141921\";");
//document.writeln("/* demo页面横幅广告 */")
//document.writeln("google_ad_slot = \"4192399144\";");
//document.writeln("google_ad_width = 728;");
//document.writeln("google_ad_height = 90;");
//document.writeln("//-->");
//document.writeln("</script>");
//document.writeln("<script type=\"text/javascript\"");
//document.writeln("src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">");
//document.writeln("</script></div>");

//document.writeln("<div style=\"width:728px;margin:10px auto;\">")
//document.writeln('<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>');
//document.writeln('<!-- 评道demo横幅 -->');
//document.writeln('<ins class="adsbygoogle"');
//document.writeln('     style="display:inline-block;width:728px;height:90px"');
//document.writeln('     data-ad-client="ca-pub-3171310320403916"');
//document.writeln('     data-ad-slot="5686750586"></ins>');
//document.writeln('<script>');
//document.writeln('(adsbygoogle = window.adsbygoogle || []).push({});');
//document.writeln('</script>');
//document.writeln("</div>");

//document.writeln("<div style=\"width:728px;margin:10px auto;\">")
//document.writeln('<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>');
//document.writeln('<!-- html5tricks-demo -->');
//document.writeln('<ins class="adsbygoogle"');
//document.writeln('     style="display:inline-block;width:728px;height:90px"');
//document.writeln('     data-ad-client="ca-pub-4188263447419139"');
//document.writeln('     data-ad-slot="1639624407"></ins>');
//document.writeln('<script>');
//document.writeln('(adsbygoogle = window.adsbygoogle || []).push({});');
//document.writeln('</script>');
//document.writeln("</div>");

document.write ('<script data-ad-client="ca-pub-3171310320403916" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>');

document.writeln("<div style=\"width:970px;margin:10px auto;\">")
document.writeln('<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>');
document.writeln('<!-- html5tricks-demo-big -->');
document.writeln('<ins class="adsbygoogle"');
document.writeln('     style="display:inline-block;width:970px;height:250px"');
document.writeln('     data-ad-client="ca-pub-3171310320403916"');
document.writeln('     data-ad-slot="1077930102"></ins>');
document.writeln('<script>');
document.writeln('(adsbygoogle = window.adsbygoogle || []).push({});');
document.writeln('</script>');
document.writeln("</div>");

//document.writeln('<script type="text/javascript">');
//document.writeln('var sogou_ad_id=362534;');
//document.writeln('var sogou_ad_height=90;');
//document.writeln('var sogou_ad_width=728;');
//document.writeln('</script>');
//document.writeln("<script type='text/javascript' src='http://images.sohu.com/cs/jsfile/js/c.js'></script>");

//document.writeln("<div style=\"width:336px;margin:10px auto;\">")
//document.writeln('<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>');
//document.writeln('<!-- 码农网底部矩形 -->');
//document.writeln('<ins class="adsbygoogle"');
//document.writeln('     style="display:inline-block;width:336px;height:280px"');
//document.writeln('     data-ad-client="ca-pub-3171310320403916"');
//document.writeln('     data-ad-slot="2263352181"></ins>');
//document.writeln('<script>');
//document.writeln('(adsbygoogle = window.adsbygoogle || []).push({});');
//document.writeln('</script>');
//document.writeln("</div>");






//document.writeln('<div style="width:336px;margin:5px auto;"><script type="text/javascript">');
//document.writeln('/*网页素材demo矩形*/');
//document.writeln('var cpro_id = "u1282812";');
//document.writeln('</script>');
//document.writeln('<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script></div>');


//document.writeln("<div align=\"center\"><p style=\"font-size:14px;\">==如非特殊说明，素材均转载自网络，如侵犯了你的知识产权，请邮件联系：tx_itivy@163.com，我们会尽快处理！==</p></div>");


document.write ('<div style="display:none"><script language="javascript" type="text/javascript" src="//js.users.51.la/16741667.js"></script></div>');
document.write ('<div style="display:none"><script language="javascript" type="text/javascript" src="//js.users.51.la/17278758.js"></script></div>');

document.writeln('<style type="text/css">.source-url{font-size:15px;text-align:center}</style>');
