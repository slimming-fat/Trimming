package com.xiaofu.formatting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootGlobalFormattingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootGlobalFormattingApplication.class, args);
	}

}
