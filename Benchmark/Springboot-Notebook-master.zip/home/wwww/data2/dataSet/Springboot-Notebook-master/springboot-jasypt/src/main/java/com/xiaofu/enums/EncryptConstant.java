package com.xiaofu.enums;


public interface EncryptConstant {

    // 加密
    String ENCRYPT = "encrypt";

    // 解密
    String DECRYPT = "decrypt";
}
