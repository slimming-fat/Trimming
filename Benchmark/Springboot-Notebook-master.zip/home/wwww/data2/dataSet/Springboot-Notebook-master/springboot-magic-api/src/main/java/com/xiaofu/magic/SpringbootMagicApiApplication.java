package com.xiaofu.magic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootMagicApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootMagicApiApplication.class, args);
	}

}
