### magic-api

springboot集成magic-api实现API接口的快速开发

无需按照JAVA开发规范，定义一系列controller、service、vo、dto等类

提供可视化操作界面编辑API接口逻辑