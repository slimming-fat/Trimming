//package com.xiaofu.magic;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class SpringbootMagicApiApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
