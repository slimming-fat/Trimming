package com.xiaofu.report;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootTestngReportApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootTestngReportApplication.class, args);
	}

}
