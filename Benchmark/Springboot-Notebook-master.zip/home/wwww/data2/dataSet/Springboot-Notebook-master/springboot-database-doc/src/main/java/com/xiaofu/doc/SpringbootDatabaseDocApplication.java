package com.xiaofu.doc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDatabaseDocApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDatabaseDocApplication.class, args);
	}

}
