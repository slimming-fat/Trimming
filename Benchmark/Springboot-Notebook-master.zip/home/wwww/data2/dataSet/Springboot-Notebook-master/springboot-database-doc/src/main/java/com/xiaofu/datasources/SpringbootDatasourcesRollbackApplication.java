package com.xiaofu.datasources;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDatasourcesRollbackApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDatasourcesRollbackApplication.class, args);
	}

}
