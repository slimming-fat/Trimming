package com.xiaofu.mapstruct;

import junit.framework.TestCase;
import org.junit.Test;

/**
 * @Auther: zhifu.xin@ipinyou.com
 * @Date: 2021/9/10 15:56
 * @Description:
 */
public class MapStruct_1Test extends TestCase {

}