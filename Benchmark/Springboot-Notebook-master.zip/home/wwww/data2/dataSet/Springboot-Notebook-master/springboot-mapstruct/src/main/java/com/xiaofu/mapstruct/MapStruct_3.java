package com.xiaofu.mapstruct;

/**
 * @author xiaofu
 * @Description:
 * @date 2021/09/10
 */
public class MapStruct_3 {
}
