package com.chengxy.unifiedlog.entity;

import lombok.Data;

/**
 * @Author: xiaofu
 * @Description:
 */
@Data
public class OrderVO {

    private String OrderNo;

}
