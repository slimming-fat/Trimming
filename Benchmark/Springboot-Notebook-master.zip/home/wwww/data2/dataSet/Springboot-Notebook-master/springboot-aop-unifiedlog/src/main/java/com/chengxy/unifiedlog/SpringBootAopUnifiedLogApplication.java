package com.chengxy.unifiedlog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootAopUnifiedLogApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootAopUnifiedLogApplication.class, args);
	}
}
