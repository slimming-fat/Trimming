/**
 * Licensed to the Austrian Association for Software Tool Integration (AASTI)
 * under one or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information regarding copyright
 * ownership. The AASTI licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.openengsb.core.ekb.api;

import java.util.UUID;

/**
 * The persist interface provides the functions to maintain the models of the EDB. This includes the conversion of
 * models and sanity checks of models.
 */
public interface PersistInterface {

    /**
     * Does a sanity check of the EKBCommit and the status of the EDB when this models are changed. After passed sanity
     * check, the models are persisted.
     */
    void commit(EKBCommit commit) throws SanityCheckException, EKBException;

    /**
     * Does a sanity check of the EKBCommit and the status of the EDB when this models are changed. After passed sanity
     * check, the models are persisted. The expectedContextHeadRevision defines which revision should be the head for
     * the current context. If there is a different head revision for the context, an EKBConcurrentException is thrown.
     * A null value for the expectedContextHeadRevision means that it is assumed that there is no commit for the context
     * so far.
     */
    void commit(EKBCommit commit, UUID expectedContextHeadRevision) throws SanityCheckException, EKBException;

    /**
     * Persist the changes of the EKBCommit without performing sanity checks of them.
     */
    void forceCommit(EKBCommit commit) throws EKBException;

    /**
     * Persist the changes of the EKBCommit without performing sanity checks of them. The expectedContextHeadRevision
     * defines which revision should be the head for the current context. If there is a different head revision for the
     * context, an EKBConcurrentException is thrown. A null value for the expectedContextHeadRevision means that it is
     * assumed that there is no commit for the context so far.
     */
    void forceCommit(EKBCommit commit, UUID expectedContextHeadRevision) throws EKBException;

    /**
     * Only perform the sanity checks of the EKBCommit.
     */
    SanityCheckReport check(EKBCommit commit) throws EKBException;

    /**
     * Reverts the models which are contained in the commit with the given revision to the version they had in the
     * corresponding commit. If there is no commit with the given revision, an EKBException is thrown.
     */
    void revertCommit(String revision) throws EKBException;

    /**
     * Reverts the models which are contained in the commit with the given revision to the version they had in the
     * corresponding commit. If there is no commit with the given revision, an EKBException is thrown. The
     * expectedContextHeadRevision defines which revision should be the head for the current context. If there is a
     * different head revision for the context, an EKBConcurrentException is thrown. A null value for the
     * expectedContextHeadRevision means that it is assumed that there is no commit for the context so far.
     */
    void revertCommit(String revision, UUID expectedContextHeadRevision) throws EKBException;

    /**
     * Deletes the commit corresponding revision IFF it is the last commit in its context. Only the last commit in a
     * context can be deleted to ensure consistency. The context is locked during the delete.
     * 
     * @param revision of the commit to delete
     * @param contextId of the context the commit belongs to and that should be locked
     * @throws EKBException
     */
    void deleteCommit(UUID revision, String contextId) throws EKBException;
}
