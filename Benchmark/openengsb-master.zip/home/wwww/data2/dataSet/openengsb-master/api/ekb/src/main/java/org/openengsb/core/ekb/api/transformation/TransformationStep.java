/**
 * Licensed to the Austrian Association for Software Tool Integration (AASTI)
 * under one or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information regarding copyright
 * ownership. The AASTI licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.openengsb.core.ekb.api.transformation;

import java.util.HashMap;
import java.util.Map;

import com.google.common.base.Joiner;
import com.google.common.base.Objects;

/**
 * Describes a transforming step in the transformation progress. Contains all informations to perform a transformation
 * operation on source fields and target fields.
 */
public class TransformationStep {
    private String targetField;
    private String operationName;
    private Map<String, String> operationParams;
    private String[] sourceFields;

    public TransformationStep() {
        operationParams = new HashMap<String, String>();
        sourceFields = new String[0];
    }

    public String getTargetField() {
        return targetField;
    }

    public void setTargetField(String targetField) {
        this.targetField = targetField;
    }

    public String getOperationName() {
        return operationName;
    }

    public void setOperationName(String operationName) {
        this.operationName = operationName;
    }

    public Map<String, String> getOperationParams() {
        return operationParams;
    }

    public void setOperationParams(Map<String, String> operationParams) {
        this.operationParams = operationParams;
    }

    public String getOperationParamater(String key) {
        return operationParams.get(key);
    }

    public void setOperationParameter(String key, String value) {
        operationParams.put(key, value);
    }

    public String[] getSourceFields() {
        return sourceFields;
    }

    public void setSourceFields(String... sourceFields) {
        this.sourceFields = sourceFields;
    }

    @Override
    public String toString() {
        String sources = sourceFields != null ? Joiner.on(",").join(sourceFields) : "";
        String params = operationParams != null ? Joiner.on(",").withKeyValueSeparator(":").join(operationParams) : "";
        return Objects.toStringHelper(this.getClass())
                .add("operation", operationName)
                .add("sources", sources)
                .add("target", targetField)
                .add("parameters", params).toString();
    }
}
