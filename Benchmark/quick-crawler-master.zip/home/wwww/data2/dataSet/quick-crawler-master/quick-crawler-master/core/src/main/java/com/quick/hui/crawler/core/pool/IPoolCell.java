package com.quick.hui.crawler.core.pool;

/**
 * Created by yihui on 2017/8/6.
 */
public interface IPoolCell {

    /**
     * 清空所有状态
     */
    void clear();

}
