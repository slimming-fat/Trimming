package com.quick.hui.crawler.core.pool;

/**
 * Created by yihui on 2017/8/6.
 */
public interface ObjectFactory<T> {

    T create();

}
