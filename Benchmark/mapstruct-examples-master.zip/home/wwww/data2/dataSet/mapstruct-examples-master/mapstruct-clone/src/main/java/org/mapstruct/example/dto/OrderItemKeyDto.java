package org.mapstruct.example.dto;

/**
 * @author Sjaak Derksen
 */
public class OrderItemKeyDto {

    private long stockNumber;

    public long getStockNumber() {
        return stockNumber;
    }

    public void setStockNumber(long stockNumber) {
        this.stockNumber = stockNumber;
    }
}
