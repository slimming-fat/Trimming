package org.mapstruct.example.dto;

/**
 * @author Filip Hrisafov
 */
public class OrderItemDto {

    public String name;
    public Long quantity;
}
