# Using MapStruct with Ant

This example project shows how to use MapStruct with Apache Ant. For the sake of simplicity it assumes
there is a seeded Maven repository containing MapStruct as well as some test dependencies in ~/.m2/repository.
Typically these JARs would be part of the project itself or Ivy as a dependency management tool would be used.

To build the project, run "ant build".
