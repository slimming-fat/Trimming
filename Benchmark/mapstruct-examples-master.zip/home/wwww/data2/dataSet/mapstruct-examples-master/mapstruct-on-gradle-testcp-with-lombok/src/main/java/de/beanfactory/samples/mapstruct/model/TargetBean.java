package de.beanfactory.samples.mapstruct.model;

import lombok.Data;

@Data
public class TargetBean {
    int id;
    String data;
}
