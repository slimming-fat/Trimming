package de.beanfactory.samples.mapstruct.model;

import java.util.Objects;
import lombok.Data;

@Data
public class TestTargetBean {
    private int id;
    private String data;
}
