package org.mapstruct.example.protobuf;

/**
 * @author Thomas Kratz
 */
public enum Permission {

    ADMIN,
    USER,
    NONE
}
