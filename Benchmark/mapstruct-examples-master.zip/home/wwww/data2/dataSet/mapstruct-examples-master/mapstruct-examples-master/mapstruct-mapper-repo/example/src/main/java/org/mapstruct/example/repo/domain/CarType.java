/**
 * 
 */
package org.mapstruct.example.repo.domain;

/**
 * @author jucheme
 *
 */
public enum CarType {

	SPORTS, OTHER;

}
