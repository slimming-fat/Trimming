# Parity Matching Algorithm Performance Test

Parity Matching Algorithm Performance Test contains microbenchmarks for Parity
Matching Algorithm.

## Usage

Run Parity Matching Algorithm Performance Test with Java:

```
java -jar parity-match-perf-test.jar
```

## License

Released under the Apache License, Version 2.0.
