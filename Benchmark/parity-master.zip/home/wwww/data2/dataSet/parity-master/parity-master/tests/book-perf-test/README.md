# Parity Order Book Performance Test

Parity Order Book Performance Test contains microbenchmarks for Parity Order
Book.

## Usage

Run Parity Order Book Performance Test with Java:

```
java -jar parity-book-perf-test.jar
```

## License

Released under the Apache License, Version 2.0.
