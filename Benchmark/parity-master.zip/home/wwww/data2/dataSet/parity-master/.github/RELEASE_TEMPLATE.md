## Release Notes

- ...

## Maven

The following artifacts are available in the Central Repository:

Name                      | Artifact ID    | Version
--------------------------|----------------|--------
Parity Order Book         | `parity-book`  | `...`
Parity File Formats       | `parity-file`  | `...`
Parity Matching Algorithm | `parity-match` | `...`
Parity Network Protocols  | `parity-net`   | `...`
Parity Utilities          | `parity-util`  | `...`

The **Group ID** for all artifacts is `com.paritytrading.parity`.
