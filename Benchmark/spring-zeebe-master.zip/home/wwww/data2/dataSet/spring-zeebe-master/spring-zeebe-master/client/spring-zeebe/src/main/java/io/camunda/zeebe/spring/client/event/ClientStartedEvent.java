package io.camunda.zeebe.spring.client.event;

public class ClientStartedEvent {

}
