package io.camunda.zeebe.spring.client.event;

import org.springframework.context.event.EventListener;

public class EventLoggerHandler {

  @EventListener
  public void logEvent() {
  }
}
