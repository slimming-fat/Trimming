

# qr_pay

技术栈：springboot + 前端thymeleaf +  二维码插件jquery.qrcode.min.js + lombok日志

**聚合支付**之一个二维码同时支持微信和支付宝  
###聚合支付：顾名思义，就是把所有的电子支付集中，对外只展示一套二维码。   



敏感信息已做清除  
1.开发者需要拿到微信、支付宝牌照将敏感信息补充完整，  
2.聚合支付思路见博客   https://blog.csdn.net/u013897685/article/details/84037133


>>version 1.0.1  updated  on  2020.06.10 00:00:00
