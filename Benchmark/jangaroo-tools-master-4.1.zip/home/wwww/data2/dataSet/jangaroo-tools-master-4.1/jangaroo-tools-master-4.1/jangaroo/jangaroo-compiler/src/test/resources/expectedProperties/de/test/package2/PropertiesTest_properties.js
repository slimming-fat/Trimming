
/**
 * Overrides of ResourceBundle "PropertiesTest" for Locale "de".
 * @see PropertiesTest_properties#INSTANCE
 */
Ext.define("test.package2.PropertiesTest_de_properties", {
  override: "test.package2.PropertiesTest_properties",
 key: "Die Platte \"{1}\" enthält {0}.",
 madeUp: "Das hier gibt es nur auf Deutsch."
});