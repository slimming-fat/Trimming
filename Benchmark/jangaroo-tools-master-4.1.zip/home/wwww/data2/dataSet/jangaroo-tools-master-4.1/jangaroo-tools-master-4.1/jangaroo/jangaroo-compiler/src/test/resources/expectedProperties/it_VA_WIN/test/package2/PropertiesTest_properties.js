
/**
 * intentionally empty: no overrides at all
 * @see PropertiesTest_properties#INSTANCE
 */
Ext.define("test.package2.PropertiesTest_it_VA_WIN_properties", {
  override: "test.package2.PropertiesTest_properties"
});