package net.jangaroo.jooc.json;

/**
 * Pseude-JSON may also contain JavaScript code.
 */
public interface Code {
  String getCode();
}
