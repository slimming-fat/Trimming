

 class TestUndeclaredIdeError {
  
   constructor() {
    undeclaredIde6 = 5;
    var x:any = undeclaredIde7;
    undeclaredIde8;
  }
}
export default TestUndeclaredIdeError;
