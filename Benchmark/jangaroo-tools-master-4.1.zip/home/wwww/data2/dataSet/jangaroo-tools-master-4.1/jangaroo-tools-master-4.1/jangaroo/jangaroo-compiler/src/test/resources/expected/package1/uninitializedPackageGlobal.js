/*package package1 {

import package1.someOtherPackage.SomeOtherClass;*/

// This comment to vanish in API
/**
 * Some package-global documentation;
 */
Ext.define("package1.uninitializedPackageGlobal", function(uninitializedPackageGlobal) {/*public var uninitializedPackageGlobal:SomeOtherClass;

}

============================================== Jangaroo part ==============================================*/
    return {__factory__: function() {
        return(null);
      }};
});
