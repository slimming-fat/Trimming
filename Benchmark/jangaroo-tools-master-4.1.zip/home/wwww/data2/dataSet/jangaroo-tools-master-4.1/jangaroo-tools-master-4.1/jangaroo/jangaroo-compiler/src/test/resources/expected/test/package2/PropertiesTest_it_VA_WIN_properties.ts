import PropertiesTest_properties from "./PropertiesTest_properties";
import ResourceBundleUtil from "@jangaroo/runtime/l10n/ResourceBundleUtil";

/**
 * intentionally empty: no overrides at all
 * @see PropertiesTest_properties#INSTANCE
 */
ResourceBundleUtil.override(PropertiesTest_properties, {
});
