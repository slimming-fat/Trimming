

class TestPrototypeConstants {

  readonly foo:string = "FOO";
  readonly bar:Record<string,any> = {};

}
export default TestPrototypeConstants;
