import NaN from "../NaN";
import undefined from "../undefined";


class ParameterInitializers {
  constructor(str = "foo", integer = 1, num2 = NaN,
                                        bool = false, obj = null, undef?) {
  }
}
export default ParameterInitializers;
