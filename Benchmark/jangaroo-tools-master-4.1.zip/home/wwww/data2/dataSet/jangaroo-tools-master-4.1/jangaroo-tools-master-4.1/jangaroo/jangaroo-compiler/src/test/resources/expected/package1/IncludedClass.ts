import {metadata} from '@jangaroo/runtime/AS3';
/*
@AnotherAnnotation*/

 class IncludedClass {
}
metadata(IncludedClass, ["AnotherAnnotation"]);

export default IncludedClass;
