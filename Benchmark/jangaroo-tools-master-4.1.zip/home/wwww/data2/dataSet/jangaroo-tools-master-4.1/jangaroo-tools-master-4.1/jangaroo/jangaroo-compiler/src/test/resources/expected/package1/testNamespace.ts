

/**
 * Some ASDoc for the namespace.
 */
// this comment should vanish in API!
 namespace = "http://testNamespace";
export default testNamespace;
