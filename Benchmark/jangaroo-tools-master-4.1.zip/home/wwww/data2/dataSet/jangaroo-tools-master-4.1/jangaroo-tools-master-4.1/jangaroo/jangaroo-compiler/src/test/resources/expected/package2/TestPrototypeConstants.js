/*package package2 {*/

Ext.define("package2.TestPrototypeConstants", function(TestPrototypeConstants) {/*public class TestPrototypeConstants {

  public const foo:String = "FOO";
  public const bar:Object =*/function bar_(){this.bar=( {});}/*;

}*/function TestPrototypeConstants$() {this.super$pL8X();}/*
}

============================================== Jangaroo part ==============================================*/
    return {
      foo: "FOO",
      super$pL8X: function() {
        bar_.call(this);
      },
      constructor: TestPrototypeConstants$
    };
});
