

/**
 * This is some class documentation.
 */
class TestRestResourceAnnotation {
  static readonly REST_RESOURCE_URI_TEMPLATE: string = "test/{id:[0-9]+}";
  /**
   * This is some member documentation.
   */
  static readonly #ANOTHER_CONST: number = 42;
}
export default TestRestResourceAnnotation;
