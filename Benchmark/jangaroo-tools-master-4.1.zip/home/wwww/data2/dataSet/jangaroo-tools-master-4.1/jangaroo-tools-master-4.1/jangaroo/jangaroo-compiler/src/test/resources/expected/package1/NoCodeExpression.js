/*package package1 {
[RemoteClass("{this is not a code expression}", alias="{this is also not a code expression}")]*/
Ext.define("package1.NoCodeExpression", function(NoCodeExpression) {/*public class NoCodeExpression {
}
}

============================================== Jangaroo part ==============================================*/
    return {metadata: {"": [
      "RemoteClass",
      [
        "",
        "{this is not a code expression}",
        "alias",
        "{this is also not a code expression}"
      ]
    ]}};
});
