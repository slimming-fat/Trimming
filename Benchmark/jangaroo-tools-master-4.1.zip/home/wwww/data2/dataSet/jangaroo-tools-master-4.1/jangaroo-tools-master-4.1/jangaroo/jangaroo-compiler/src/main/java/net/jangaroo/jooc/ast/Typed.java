package net.jangaroo.jooc.ast;

/**
 * Created with IntelliJ IDEA.
 * User: fwienber
 * Date: 01.03.13
 * Time: 13:36
 * To change this template use File | Settings | File Templates.
 */
public interface Typed {
  TypeRelation getOptTypeRelation();
}
