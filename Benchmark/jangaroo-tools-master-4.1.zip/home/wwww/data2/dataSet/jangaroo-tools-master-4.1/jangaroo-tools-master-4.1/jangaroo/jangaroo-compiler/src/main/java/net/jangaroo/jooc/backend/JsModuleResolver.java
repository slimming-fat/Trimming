package net.jangaroo.jooc.backend;

import net.jangaroo.jooc.CompilationUnitResolver;

public class JsModuleResolver extends ModuleResolverBase {
  public JsModuleResolver(CompilationUnitResolver compilationUnitModelResolver) {
    super(compilationUnitModelResolver);
  }
}
