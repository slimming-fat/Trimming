package net.jangaroo.jooc.ast;

public interface ObjectFieldOrSpread extends AstNode {
}
