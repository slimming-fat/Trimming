/*
[PublicApi]*/
/**
 * This properties class is a "hook" for extensions, but otherwise empty.
 * @see EmptyPropertiesTest_properties#INSTANCE
 */
Ext.define("testPackage.EmptyPropertiesTest_properties", {
}, function() {
  this.INSTANCE = new this();
});