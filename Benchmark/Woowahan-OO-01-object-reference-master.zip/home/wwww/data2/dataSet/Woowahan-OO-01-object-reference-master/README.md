### '우아한 객체지향' 샘플

##### 2019년 6월 20일 우아한 Tech 세미나

- 슬라이드: [https://www.slideshare.net/baejjae93/ss-150432699]()

- Main Class: org.eternity.food.FoodApplication