package de.neuland.jade4j.helper.beans;



public class TestBean {
	private Level2TestBean level2;

	public Level2TestBean getLevel2() {
		return level2;
	}

	public void setLevel2(Level2TestBean level2) {
		this.level2 = level2;
	}
}
