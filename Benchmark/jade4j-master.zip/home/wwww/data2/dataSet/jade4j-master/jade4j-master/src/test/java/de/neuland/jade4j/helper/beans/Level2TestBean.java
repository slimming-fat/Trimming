package de.neuland.jade4j.helper.beans;

public class Level2TestBean {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
