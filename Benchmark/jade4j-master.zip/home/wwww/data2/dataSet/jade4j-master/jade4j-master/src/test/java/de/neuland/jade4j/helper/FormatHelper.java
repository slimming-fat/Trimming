package de.neuland.jade4j.helper;

public class FormatHelper {
	public String money(Number amount) {
		return amount.toString() + " €";
	}
}
