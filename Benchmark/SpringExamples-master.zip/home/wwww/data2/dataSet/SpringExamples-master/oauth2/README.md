# Oauth2 examples

Tutorials related to this project:

1. [Spring boot oauth2 auth server](https://howtodoinjava.com/spring5/security5/oauth2-auth-server/)