package com.springexamples.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MainClassOne 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(MainClassOne.class, args);
    }
}
