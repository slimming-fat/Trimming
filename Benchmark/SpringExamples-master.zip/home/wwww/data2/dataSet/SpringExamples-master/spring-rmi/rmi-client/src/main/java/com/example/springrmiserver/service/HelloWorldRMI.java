package com.example.springrmiserver.service;

public interface HelloWorldRMI {
	public String sayHelloRmi(String msg);
}
