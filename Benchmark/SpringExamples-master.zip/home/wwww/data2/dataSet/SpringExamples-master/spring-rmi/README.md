# Spring remoting

Tutorials related to this project:

1. [Spring Boot RMI](https://howtodoinjava.com/spring-boot2/spring-remoting-rmi-hessian/)
