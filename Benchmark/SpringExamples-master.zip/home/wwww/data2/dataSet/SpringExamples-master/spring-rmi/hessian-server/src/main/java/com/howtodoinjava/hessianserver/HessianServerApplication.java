package com.howtodoinjava.hessianserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HessianServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(HessianServerApplication.class, args);
	}
}
