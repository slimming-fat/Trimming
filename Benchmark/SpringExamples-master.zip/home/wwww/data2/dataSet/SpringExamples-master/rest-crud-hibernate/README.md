# REST CRUD

Tutorials related to this project:

1. [Spring boot crud operations example with hibernate](https://howtodoinjava.com/spring-boot2/spring-boot-crud-hibernate/)
2. [Spring boot datasource configuration](https://howtodoinjava.com/spring-boot2/datasource-configuration/)
3. [@Repository annotation in Spring Boot](https://howtodoinjava.com/spring-boot/repository-annotation/)
4. [Spring Boot - @DataJpaTest](https://howtodoinjava.com/spring-boot2/testing/datajpatest-annotation/)