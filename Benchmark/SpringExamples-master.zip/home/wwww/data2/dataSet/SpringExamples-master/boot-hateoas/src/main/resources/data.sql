INSERT INTO actor VALUES ('1', 'John', 'Doe', '10-Jan-1952');
INSERT INTO actor VALUES ('2', 'Amy', 'Eugene', '05-07-1985');
INSERT INTO actor VALUES ('3', 'Laverne', 'Mann', '11-12-1988');
INSERT INTO actor VALUES ('4', 'Janice', 'Preston', '19-02-1960');
INSERT INTO actor VALUES ('5', 'Pauline', 'Rios', '29-08-1977');

INSERT INTO album VALUES ('1', 'Top Hits Vol 1', 'Top hits vol 1. description', '10-03-1981');
INSERT INTO album VALUES ('2', 'Top Hits Vol 2', 'Top hits vol 2. description', '10-03-1982');
INSERT INTO album VALUES ('3', 'Top Hits Vol 3', 'Top hits vol 3. description', '10-03-1983');
INSERT INTO album VALUES ('4', 'Top Hits Vol 4', 'Top hits vol 4. description', '10-03-1984');
INSERT INTO album VALUES ('5', 'Top Hits Vol 5', 'Top hits vol 5. description', '10-03-1985');
INSERT INTO album VALUES ('6', 'Top Hits Vol 6', 'Top hits vol 6. description', '10-03-1986');
INSERT INTO album VALUES ('7', 'Top Hits Vol 7', 'Top hits vol 7. description', '10-03-1987');
INSERT INTO album VALUES ('8', 'Top Hits Vol 8', 'Top hits vol 8. description', '10-03-1988');
INSERT INTO album VALUES ('9', 'Top Hits Vol 9', 'Top hits vol 9. description', '10-03-1989');
INSERT INTO album VALUES ('10', 'Top Hits Vol 10', 'Top hits vol 10. description', '10-03-1990');

INSERT INTO actor_album VALUES (1, 1);
INSERT INTO actor_album VALUES (1, 2);
INSERT INTO actor_album VALUES (2, 3);
INSERT INTO actor_album VALUES (2, 4);
INSERT INTO actor_album VALUES (3, 5);
INSERT INTO actor_album VALUES (3, 6);
INSERT INTO actor_album VALUES (4, 7);
INSERT INTO actor_album VALUES (4, 8);
INSERT INTO actor_album VALUES (5, 9);
INSERT INTO actor_album VALUES (5, 10);