# Related tutorials

1. [Spring HATEOAS Tutorial](https://howtodoinjava.com/spring-boot/rest-with-spring-hateoas-example/)
2. [Spring HATEOAS - Embedded collection model name](https://howtodoinjava.com/spring5/hateoas/embedded-collection-name/)
3. [Spring HATEOAS - Pagination Links](https://howtodoinjava.com/spring5/hateoas/pagination-links/)