# Spring Webflux

Tutorials related to this project:

1. [Spring WebFlux Tutorial](https://howtodoinjava.com/spring-webflux/spring-webflux-tutorial/)
2. [Spring boot webflux test with @WebFluxTest with WebTestClient](https://howtodoinjava.com/spring-webflux/webfluxtest-with-webtestclient/).
3. [Spring boot @MockBean](https://howtodoinjava.com/spring-boot2/spring-mockbean-annotation/)