# Related tutorials

1. [Spring Batch - Writing to Multiple Destinations with Classifier](https://howtodoinjava.com/spring-batch/classifier-multi-destinations/)