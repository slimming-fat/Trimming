package com.springexamples.demo.service;

public interface UserService {
	
	public String testUserService();

}
