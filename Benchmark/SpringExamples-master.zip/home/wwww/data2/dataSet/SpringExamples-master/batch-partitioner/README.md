# Related tutorials

1. [Spring Batch - Partitioning](https://howtodoinjava.com/spring-batch/spring-batch-step-partitioning/)