# Related tutorials

1. [Spring boot - Send email with attachment](https://howtodoinjava.com/spring-boot2/send-email-with-attachment/)