package org.openstack4j.api.gbp;

import org.openstack4j.api.AbstractTest;

/**
 * Test cases for service chain on GBP
 *
 * @author vinod borole
 */
public class ServicechainServiceTest extends AbstractTest {

    @Override
    protected Service service() {
        // TODO Auto-generated method stub
        return null;
    }

}
