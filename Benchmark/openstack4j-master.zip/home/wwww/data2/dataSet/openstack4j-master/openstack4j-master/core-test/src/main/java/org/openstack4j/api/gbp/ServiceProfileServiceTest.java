package org.openstack4j.api.gbp;

import org.openstack4j.api.AbstractTest;

/**
 * Test cases for service profile on GBP
 *
 * @author vinod borole
 */
public class ServiceProfileServiceTest extends AbstractTest {

    @Override
    protected Service service() {
        // TODO Auto-generated method stub
        return null;
    }

}
