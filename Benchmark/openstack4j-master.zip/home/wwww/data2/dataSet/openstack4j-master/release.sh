mvn release:prepare release:perform -DignoreSnapshots=true -DskipTests -Darguments=-DskipTests
