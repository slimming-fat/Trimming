package com.riversoft.weixin.mp.card.bean;

/**
 * Created by exizhai on 11/30/2015.
 */
public class Color {

    private String name;
    private String value;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
