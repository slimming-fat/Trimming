package com.riversoft.weixin.common.message;

/**
 * Created by exizhai on 10/3/2015.
 */
public interface Message {
}
