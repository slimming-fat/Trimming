package fr.inria.spirals.repairnator.process.step.repair.soraldbot;

public class SoraldConstants {
    public static final String SORALD_GIT_PATCHES_DIR = "SoraldGitPatches";
    public static final String SPOON_SNIPER_MODE = "SNIPER";
    public static final String SORALD_TOOL_NAME = "SoraldBot";
}
