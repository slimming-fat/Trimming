package fr.inria.spirals.repairnator.realtime;

public class Constants {
    public final static String SORALD_NAME = "SoraldBot";
    public final static String SEQUENCER_NAME = "SequencerRepair";
}
