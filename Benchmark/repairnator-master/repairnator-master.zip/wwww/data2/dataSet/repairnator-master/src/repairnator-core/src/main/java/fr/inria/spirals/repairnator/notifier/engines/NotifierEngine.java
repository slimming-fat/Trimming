package fr.inria.spirals.repairnator.notifier.engines;

/**
 * Created by urli on 30/03/2017.
 */
public interface NotifierEngine {
    void notify(String subject, String message);
}
