package fr.inria.spirals.repairnator.process.step.checkoutrepository;

/**
 * Created by fernanda on 02/03/17.
 */
public enum CheckoutType {
    NO_CHECKOUT, CHECKOUT_PATCHED_BUILD, CHECKOUT_BUGGY_BUILD, CHECKOUT_BUGGY_BUILD_SOURCE_CODE, CHECKOUT_BUGGY_BUILD_TEST_CODE
}
