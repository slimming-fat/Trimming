package fr.inria.spirals.repairnator.process.step.push;

public enum CommitType {
    COMMIT_BUGGY_BUILD, COMMIT_HUMAN_PATCH, COMMIT_REPAIR_INFO, COMMIT_PROCESS_END, COMMIT_CHANGED_TESTS
}
