package fr.inria.spirals.repairnator.process.nopol;

/**
 * Created by urli on 16/02/2017.
 */
public enum NopolStatus {
    NOTLAUNCHED, RUNNING, NOPATCH, TIMEOUT, PATCH, EXCEPTION
}
