The documentation of the Repairnator Github bot is at <https://github.com/eclipse/repairnator/blob/master/doc/repairnator-github-app.md>
