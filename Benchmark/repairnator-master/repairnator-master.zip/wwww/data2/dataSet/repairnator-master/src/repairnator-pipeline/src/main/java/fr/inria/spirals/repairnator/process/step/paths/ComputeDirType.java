package fr.inria.spirals.repairnator.process.step.paths;

public enum ComputeDirType {
    COMPUTE_SOURCE_DIR, COMPUTE_TEST_DIR
}
