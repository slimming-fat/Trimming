package fr.inria.spirals.repairnator.process.nopol;

/**
 * Created by urli on 08/03/2017.
 */
public enum IgnoreStatus {
    IGNORE_FAILING, IGNORE_ERRORING, NOTHING_TO_IGNORE
}
