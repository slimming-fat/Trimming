package fr.inria.spirals.repairnator.states;

/**
 * Created by fernanda on 24/02/17.
 */
public enum ScannedBuildStatus {
    ONLY_FAIL, FAILING_AND_PASSING, PASSING_AND_PASSING_WITH_TEST_CHANGES
}
