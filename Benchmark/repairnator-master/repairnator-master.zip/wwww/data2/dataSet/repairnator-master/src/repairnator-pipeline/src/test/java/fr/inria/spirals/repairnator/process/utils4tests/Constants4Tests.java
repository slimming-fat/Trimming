package fr.inria.spirals.repairnator.process.utils4tests;

public class Constants4Tests {

    public static final String Z3_SOLVER_PATH_DIR = "src/test/resources/z3/";
    public static final String Z3_SOLVER_NAME_LINUX = "z3_for_linux";
    public static final String Z3_SOLVER_NAME_MAC = "z3_for_mac";

}
