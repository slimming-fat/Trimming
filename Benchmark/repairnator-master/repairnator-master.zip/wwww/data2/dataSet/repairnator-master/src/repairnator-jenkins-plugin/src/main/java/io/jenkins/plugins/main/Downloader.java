package io.jenkins.plugins.main;

public interface Downloader {
	void download();
}