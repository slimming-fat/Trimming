package io.jenkins.plugins.main;

public interface Installer {
	void install();
}