package fr.inria.spirals.repairnator.states;

public enum BearsMode {
    FAILING_PASSING, PASSING_PASSING, BOTH
}
