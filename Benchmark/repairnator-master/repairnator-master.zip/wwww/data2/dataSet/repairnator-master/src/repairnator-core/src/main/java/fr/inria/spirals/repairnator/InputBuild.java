package fr.inria.spirals.repairnator;

import java.util.List;

public interface InputBuild {
    String toString();
    List<String> getEnvVariables();
}
