package fr.inria.spirals.repairnator.process.inspectors.properties.features;

public enum Features {
    P4J, // prophet4j
    S4R, // sketch4repair
    ODS, // 202 ODS features
}
