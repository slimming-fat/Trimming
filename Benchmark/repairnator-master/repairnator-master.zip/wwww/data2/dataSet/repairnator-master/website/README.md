# Website

This directory contains the necessary stuff to deploy a website that displays statistics comings from a MongoDB instance filled with Repairnator data.
It's composed of 2 parts:
 - [repairnator-mongo-rest-api](repairnator-mongo-rest-api): it offers a REST-like API towards the MongoDB;
 - [repairnator-site](repairnator-site): consumes this API to display the information. 