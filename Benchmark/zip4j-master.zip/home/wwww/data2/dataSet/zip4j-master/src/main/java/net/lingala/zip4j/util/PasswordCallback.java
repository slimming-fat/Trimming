package net.lingala.zip4j.util;

public interface PasswordCallback {

    char[] getPassword();
}
