* Bob Carroll <bob.carroll@alum.rit.edu> @rcarz
* Kyle Chaplin <chaplinkyle@gmail.com> @chaplinkyle
* Alesandro Lang <info@alesandro-lang.com> @alesandroLang
* Javier Molina <javinovich@gmail.com> @javinovich
* Joseph McCarthy <luckymikuhatsune@gmail.com>
* Magnus Lundberg <ludde89l@gmail.com>
* Anders Kreinøe <anders@kreinoee.dk> @Kreinoee
* Andrey Kuzmin <agkoozmin@gmail.com> @nach-o-man
* Pierre-Luc Dupont <pldupont@gmail.com> @pldupont
* Vivek Ganesan <vivek@vivekganesan.com> @vivganes
