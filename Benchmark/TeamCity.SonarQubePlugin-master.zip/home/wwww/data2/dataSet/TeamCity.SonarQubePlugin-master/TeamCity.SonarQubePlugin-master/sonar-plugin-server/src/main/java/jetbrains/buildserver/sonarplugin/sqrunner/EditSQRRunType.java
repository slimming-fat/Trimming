/*
 * Copyright 2000-2022 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jetbrains.buildserver.sonarplugin.sqrunner;

import jetbrains.buildServer.controllers.ActionErrors;
import jetbrains.buildServer.controllers.StatefulObject;
import jetbrains.buildServer.controllers.admin.projects.BuildTypeForm;
import jetbrains.buildServer.controllers.admin.projects.EditRunTypeControllerExtension;
import jetbrains.buildServer.serverSide.BuildTypeSettings;
import jetbrains.buildServer.serverSide.SBuildServer;
import jetbrains.buildServer.serverSide.SProject;
import jetbrains.buildserver.sonarplugin.Constants;
import jetbrains.buildserver.sonarplugin.Util;
import jetbrains.buildserver.sonarplugin.manager.SQSInfo;
import jetbrains.buildserver.sonarplugin.manager.SQSManager;
import jetbrains.buildserver.sonarplugin.msbuild.tool.SQMSConstants;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

/**
 * Created by Andrey Titov on 5/29/14.
 *
 * Controller for the Edit SonarQube Runner page. Adds SonarQube Servers available for the current project.
 */
public class EditSQRRunType implements EditRunTypeControllerExtension {
    @NotNull
    private final SQSManager mySqsManager;

    public EditSQRRunType(@NotNull final SBuildServer server,
                          @NotNull final SQSManager mySqsManager) {
        this.mySqsManager = mySqsManager;
        server.registerExtension(EditRunTypeControllerExtension.class, Constants.RUNNER_TYPE, this);
        server.registerExtension(EditRunTypeControllerExtension.class, SQMSConstants.SONAR_QUBE_MSBUILD_RUN_TYPE_ID, this);
    }

    @SuppressWarnings("unchecked")
    public void fillModel(@NotNull final HttpServletRequest request,
                          @NotNull final BuildTypeForm form,
                          @NotNull final Map model) {
        SProject project = form.getProject();
        final List<SQSInfo> availableServers = mySqsManager.getAvailableServers(project);
        model.put("servers", availableServers);
        final String sonarServer = getSonarServer(form);

        if (Util.isEmpty(sonarServer)) {
            model.put("showSelectServer", Boolean.TRUE);
        } else if (mySqsManager.getServer(form.getProject(), sonarServer) == null) {
            model.put("showUnknownServer", Boolean.TRUE);
        }

        model.put("project", form.getProject());
    }

    public void updateState(@NotNull final HttpServletRequest request, @NotNull final BuildTypeForm form) {
        // do nothing
    }

    @Nullable
    public StatefulObject getState(@NotNull final HttpServletRequest request, @NotNull final BuildTypeForm form) {
        return null;
    }

    @NotNull
    public ActionErrors validate(@NotNull final HttpServletRequest request, @NotNull final BuildTypeForm form) {
        final ActionErrors errors = new ActionErrors();
        final String sonarServer = getSonarServer(form);
        if (Util.isEmpty(sonarServer)) {
            errors.addError("sonarServer", "SonarQube server should be set");
        } else {
            final SQSInfo server = mySqsManager.getServer(form.getProject(), sonarServer);
            if (server == null) {
                errors.addError("sonarServer", "This SonarQube server doesn't exist");
            }
        }
        return errors;
    }

    public void updateBuildType(@NotNull final HttpServletRequest request,
                                @NotNull final BuildTypeForm form,
                                @NotNull final BuildTypeSettings buildTypeSettings,
                                @NotNull final ActionErrors errors) {
        // do nothing
    }

    private String getSonarServer(@NotNull BuildTypeForm form) {
        return form.getBuildRunnerBean().getPropertiesBean().getProperties().get("sonarServer");
    }
}
