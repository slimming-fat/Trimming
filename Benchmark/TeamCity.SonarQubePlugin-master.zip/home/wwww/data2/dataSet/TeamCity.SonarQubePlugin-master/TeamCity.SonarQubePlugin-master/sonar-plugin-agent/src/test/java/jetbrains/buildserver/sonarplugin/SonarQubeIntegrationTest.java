package jetbrains.buildserver.sonarplugin;

import org.junit.Test;

public class SonarQubeIntegrationTest extends AbstractSonarQubeTest {

}
