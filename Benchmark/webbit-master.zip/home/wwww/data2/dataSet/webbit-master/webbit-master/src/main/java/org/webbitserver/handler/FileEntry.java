package org.webbitserver.handler;

public class FileEntry {
    public final String name;

    public FileEntry(String name) {
        this.name = name;
    }
}
