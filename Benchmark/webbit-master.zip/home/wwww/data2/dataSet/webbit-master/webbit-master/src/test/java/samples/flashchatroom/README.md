#Flash Chat Room Example

This example show how to use a Webbit WebSocket server with the 
[web-socket-js](https://github.com/gimite/web-socket-js) Flash 
WebSocket client.