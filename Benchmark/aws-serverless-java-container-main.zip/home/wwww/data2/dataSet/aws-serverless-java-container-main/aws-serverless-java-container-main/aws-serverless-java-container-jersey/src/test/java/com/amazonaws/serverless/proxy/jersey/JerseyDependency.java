package com.amazonaws.serverless.proxy.jersey;

// This class is used to test HK2 dependency injection.
public class JerseyDependency {

}
