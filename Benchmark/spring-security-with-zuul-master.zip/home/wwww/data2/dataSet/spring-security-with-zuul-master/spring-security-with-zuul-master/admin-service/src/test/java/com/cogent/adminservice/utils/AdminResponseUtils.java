package com.cogent.adminservice.utils;

/**
 * @author smriti on 7/21/19
 */
public class AdminResponseUtils {
}
