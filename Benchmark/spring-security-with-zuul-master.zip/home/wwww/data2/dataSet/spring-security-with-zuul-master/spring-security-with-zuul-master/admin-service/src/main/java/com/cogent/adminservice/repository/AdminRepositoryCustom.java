package com.cogent.adminservice.repository;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

/**
 * @author smriti on 7/21/19
 */
@Repository
@Qualifier("AdminRepositoryCustom")
public interface AdminRepositoryCustom {


}

