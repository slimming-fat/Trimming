package in.xnnyygn.xraft.kvstore.message;

public class Success {

    public static final Success INSTANCE = new Success();

}
