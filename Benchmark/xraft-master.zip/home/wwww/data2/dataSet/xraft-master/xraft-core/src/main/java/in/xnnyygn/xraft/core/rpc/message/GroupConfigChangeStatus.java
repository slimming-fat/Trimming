package in.xnnyygn.xraft.core.rpc.message;

public enum GroupConfigChangeStatus {

    OK,
    TIMEOUT,
    NOT_LEADER;

}
