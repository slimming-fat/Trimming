package in.xnnyygn.xraft.core.node.role;

/**
 * Role name.
 */
public enum RoleName {

    FOLLOWER, CANDIDATE, LEADER;

}
