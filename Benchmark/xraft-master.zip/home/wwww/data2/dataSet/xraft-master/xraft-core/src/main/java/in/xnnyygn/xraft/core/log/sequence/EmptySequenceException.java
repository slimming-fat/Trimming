package in.xnnyygn.xraft.core.log.sequence;

import in.xnnyygn.xraft.core.log.LogException;

class EmptySequenceException extends LogException {
}
