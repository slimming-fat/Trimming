package in.xnnyygn.xraft.core.node;

public enum NodeMode {

    STANDALONE,
    STANDBY,
    GROUP_MEMBER;

}
