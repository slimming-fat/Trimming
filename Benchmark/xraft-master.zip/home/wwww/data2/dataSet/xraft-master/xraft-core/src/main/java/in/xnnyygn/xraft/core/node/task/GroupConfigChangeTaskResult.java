package in.xnnyygn.xraft.core.node.task;

public enum  GroupConfigChangeTaskResult {

    OK,
    TIMEOUT,
    REPLICATION_FAILED,
    ERROR

}
