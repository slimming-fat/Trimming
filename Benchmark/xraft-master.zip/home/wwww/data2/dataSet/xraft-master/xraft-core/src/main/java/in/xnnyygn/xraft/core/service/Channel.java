package in.xnnyygn.xraft.core.service;

public interface Channel {

    Object send(Object payload);

}
