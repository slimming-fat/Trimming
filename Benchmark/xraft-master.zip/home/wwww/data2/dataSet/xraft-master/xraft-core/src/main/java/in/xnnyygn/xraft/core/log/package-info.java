/**
 * Log related.
 */
package in.xnnyygn.xraft.core.log;