These plug-ins are part of the Refractions training course! For more information please see our website at http://refractions.net/products/udig/

A brief outline of these materials is also available on our wiki.
- http://udig.refractions.net/confluence/display/DEV/2+Training+Materials
