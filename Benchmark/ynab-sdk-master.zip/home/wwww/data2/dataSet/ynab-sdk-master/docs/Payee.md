
# Payee

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**name** | **String** |  | 
**deleted** | **Boolean** | Whether or not the payee has been deleted.  Deleted payees will only be included in delta requests. | 



