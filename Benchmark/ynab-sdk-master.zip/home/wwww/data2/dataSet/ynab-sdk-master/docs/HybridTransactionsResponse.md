
# HybridTransactionsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**HybridTransactionsWrapper**](HybridTransactionsWrapper.md) |  | 



