
# BulkTransactions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactions** | [**List&lt;SaveTransaction&gt;**](SaveTransaction.md) |  | 



