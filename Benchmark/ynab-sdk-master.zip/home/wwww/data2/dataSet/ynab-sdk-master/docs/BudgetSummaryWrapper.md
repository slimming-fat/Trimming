
# BudgetSummaryWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**budgets** | [**List&lt;BudgetSummary&gt;**](BudgetSummary.md) |  | 



