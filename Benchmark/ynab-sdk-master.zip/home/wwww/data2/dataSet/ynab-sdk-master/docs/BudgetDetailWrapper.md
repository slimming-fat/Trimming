
# BudgetDetailWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**budget** | [**BudgetDetail**](BudgetDetail.md) |  | 
**serverKnowledge** | [**BigDecimal**](BigDecimal.md) | The knowledge of the server | 



