
# PayeesWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payees** | [**List&lt;Payee&gt;**](Payee.md) |  | 



