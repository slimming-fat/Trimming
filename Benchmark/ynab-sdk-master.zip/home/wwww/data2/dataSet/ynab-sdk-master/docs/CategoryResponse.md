
# CategoryResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**CategoryWrapper**](CategoryWrapper.md) |  | 



