
# CurrencyFormat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isoCode** | **String** |  | 
**exampleFormat** | **String** |  | 
**decimalDigits** | [**BigDecimal**](BigDecimal.md) |  | 
**decimalSeparator** | **String** |  | 
**symbolFirst** | **Boolean** |  | 
**groupSeparator** | **String** |  | 
**currencySymbol** | **String** |  | 
**displaySymbol** | **Boolean** |  | 



