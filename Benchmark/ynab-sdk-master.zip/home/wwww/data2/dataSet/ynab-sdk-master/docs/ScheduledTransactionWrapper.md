
# ScheduledTransactionWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scheduledTransaction** | [**ScheduledTransactionDetail**](ScheduledTransactionDetail.md) |  | 



