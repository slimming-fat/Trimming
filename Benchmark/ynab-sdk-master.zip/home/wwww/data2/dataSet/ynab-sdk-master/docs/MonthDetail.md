
# MonthDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**month** | [**LocalDate**](LocalDate.md) |  | 
**categories** | [**List&lt;Category&gt;**](Category.md) | The budget month categories | 



