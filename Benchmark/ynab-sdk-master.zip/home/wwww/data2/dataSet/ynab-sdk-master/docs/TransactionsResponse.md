
# TransactionsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**TransactionsWrapper**](TransactionsWrapper.md) |  | 



