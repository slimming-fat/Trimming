
# MonthSummariesResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**MonthSummariesWrapper**](MonthSummariesWrapper.md) |  | 



