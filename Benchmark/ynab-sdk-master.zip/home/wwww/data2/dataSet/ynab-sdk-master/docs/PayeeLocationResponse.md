
# PayeeLocationResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**PayeeLocationWrapper**](PayeeLocationWrapper.md) |  | 



