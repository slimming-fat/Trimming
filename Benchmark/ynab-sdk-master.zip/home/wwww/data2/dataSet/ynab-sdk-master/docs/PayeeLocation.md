
# PayeeLocation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String**|  | 
**payeeId** | **String**|  | 
**deleted** | **Boolean** | Whether or not the payee location has been deleted.  Deleted payee locations will only be included in delta requests. | 



