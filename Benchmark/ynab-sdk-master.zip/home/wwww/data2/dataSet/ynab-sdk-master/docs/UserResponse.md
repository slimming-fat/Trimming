
# UserResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**UserWrapper**](UserWrapper.md) |  | 



