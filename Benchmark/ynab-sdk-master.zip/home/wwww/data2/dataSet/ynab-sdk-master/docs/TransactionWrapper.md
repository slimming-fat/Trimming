
# TransactionWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transaction** | [**TransactionDetail**](TransactionDetail.md) |  | 



