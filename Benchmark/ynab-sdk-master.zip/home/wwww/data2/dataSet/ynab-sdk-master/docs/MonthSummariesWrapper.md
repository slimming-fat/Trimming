
# MonthSummariesWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**months** | [**List&lt;MonthSummary&gt;**](MonthSummary.md) |  | 



