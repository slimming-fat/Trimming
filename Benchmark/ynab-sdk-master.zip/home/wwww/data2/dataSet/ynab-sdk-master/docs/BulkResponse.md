
# BulkResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**BulkIdWrapper**](BulkIdWrapper.md) |  | 



