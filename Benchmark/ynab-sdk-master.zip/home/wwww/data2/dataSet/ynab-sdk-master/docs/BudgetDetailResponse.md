
# BudgetDetailResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**BudgetDetailWrapper**](BudgetDetailWrapper.md) |  | 



