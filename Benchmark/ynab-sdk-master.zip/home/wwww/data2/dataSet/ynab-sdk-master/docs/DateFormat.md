
# DateFormat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**format** | **String** |  | 



