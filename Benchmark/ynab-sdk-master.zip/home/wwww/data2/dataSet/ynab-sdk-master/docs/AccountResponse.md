
# AccountResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**AccountWrapper**](AccountWrapper.md) |  | 



