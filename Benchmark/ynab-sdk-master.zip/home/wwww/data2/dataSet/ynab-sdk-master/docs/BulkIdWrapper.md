
# BulkIdWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bulk** | [**BulkIds**](BulkIds.md) |  | 



