
# CategoriesResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**CategoryGroupsWrapper**](CategoryGroupsWrapper.md) |  | 



