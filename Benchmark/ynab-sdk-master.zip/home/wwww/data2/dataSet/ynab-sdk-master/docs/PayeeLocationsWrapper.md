
# PayeeLocationsWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payeeLocations** | [**List&lt;PayeeLocation&gt;**](PayeeLocation.md) |  | 



