
# BudgetSummaryResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**BudgetSummaryWrapper**](BudgetSummaryWrapper.md) |  | 



