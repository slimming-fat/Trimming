
# PayeesResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**PayeesWrapper**](PayeesWrapper.md) |  | 



