
# TransactionResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**TransactionWrapper**](TransactionWrapper.md) |  | 



