
# AccountsWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accounts** | [**List&lt;Account&gt;**](Account.md) |  | 



