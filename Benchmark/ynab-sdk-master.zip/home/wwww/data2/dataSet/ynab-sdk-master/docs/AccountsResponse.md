
# AccountsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**AccountsWrapper**](AccountsWrapper.md) |  | 



