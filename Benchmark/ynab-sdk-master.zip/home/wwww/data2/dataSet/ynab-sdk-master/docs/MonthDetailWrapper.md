
# MonthDetailWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**month** | [**MonthDetail**](MonthDetail.md) |  | 



