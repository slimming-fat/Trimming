
# PayeeLocationsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**PayeeLocationsWrapper**](PayeeLocationsWrapper.md) |  | 



