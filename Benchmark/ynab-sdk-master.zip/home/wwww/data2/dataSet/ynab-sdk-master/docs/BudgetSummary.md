
# BudgetSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**String**](String.md) |  | 
**name** | **String** |  | 
**dateFormat** | [**DateFormat**](DateFormat.md) |  |  [optional]
**currencyFormat** | [**CurrencyFormat**](CurrencyFormat.md) |  |  [optional]



