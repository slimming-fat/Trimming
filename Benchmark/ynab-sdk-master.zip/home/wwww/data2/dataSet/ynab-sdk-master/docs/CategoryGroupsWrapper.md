
# CategoryGroupsWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categoryGroups** | [**List&lt;CategoryGroupWithCategories&gt;**](CategoryGroupWithCategories.md) |  | 



