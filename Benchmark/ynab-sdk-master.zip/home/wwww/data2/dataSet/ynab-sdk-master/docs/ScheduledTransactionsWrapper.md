
# ScheduledTransactionsWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scheduledTransactions** | [**List&lt;ScheduledTransactionDetail&gt;**](ScheduledTransactionDetail.md) |  | 



