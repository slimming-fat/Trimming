
# ScheduledTransactionsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ScheduledTransactionsWrapper**](ScheduledTransactionsWrapper.md) |  | 



