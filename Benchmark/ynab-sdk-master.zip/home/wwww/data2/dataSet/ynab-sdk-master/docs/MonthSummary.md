
# MonthSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**month** | [**LocalDate**](LocalDate.md) |  | 



