
# PayeeLocationWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payeeLocation** | [**PayeeLocation**](PayeeLocation.md) |  | 



