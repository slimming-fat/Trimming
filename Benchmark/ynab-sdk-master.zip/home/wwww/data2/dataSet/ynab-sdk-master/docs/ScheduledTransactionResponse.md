
# ScheduledTransactionResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ScheduledTransactionWrapper**](ScheduledTransactionWrapper.md) |  | 



