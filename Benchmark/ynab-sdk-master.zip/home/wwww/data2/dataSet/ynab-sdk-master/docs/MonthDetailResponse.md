
# MonthDetailResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**MonthDetailWrapper**](MonthDetailWrapper.md) |  | 



