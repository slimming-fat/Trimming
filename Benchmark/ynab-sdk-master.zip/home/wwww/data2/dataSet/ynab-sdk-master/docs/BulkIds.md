
# BulkIds

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactionIds** | **List&lt;String&gt;** | The list of Transaction IDs that were created. | 
**duplicateImportIds** | **List&lt;String&gt;** | If any Transactions were not created because they had an import_id matching a transaction already on the same account, the specified import_id(s) will be included in this list. | 



