
# TransactionsWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactions** | [**List&lt;TransactionDetail&gt;**](TransactionDetail.md) |  | 



