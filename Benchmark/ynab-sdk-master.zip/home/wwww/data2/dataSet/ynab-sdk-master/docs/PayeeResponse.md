
# PayeeResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**PayeeWrapper**](PayeeWrapper.md) |  | 



