
# HybridTransactionsWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactions** | [**List&lt;HybridTransaction&gt;**](HybridTransaction.md) |  | 



