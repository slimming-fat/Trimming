
# SaveTransactionWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transaction** | [**SaveTransaction**](SaveTransaction.md) |  | 



