
# PayeeWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payee** | [**Payee**](Payee.md) |  | 



