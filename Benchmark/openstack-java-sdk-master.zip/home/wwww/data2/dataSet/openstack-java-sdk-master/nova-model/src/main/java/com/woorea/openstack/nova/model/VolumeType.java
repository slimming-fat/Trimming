package com.woorea.openstack.nova.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName("volume-type")
public class VolumeType implements Serializable {

}
