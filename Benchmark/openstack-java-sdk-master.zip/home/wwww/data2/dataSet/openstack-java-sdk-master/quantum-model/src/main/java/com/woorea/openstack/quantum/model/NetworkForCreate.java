package com.woorea.openstack.quantum.model;

import com.fasterxml.jackson.annotation.JsonRootName;

@SuppressWarnings("serial")
@JsonRootName("network")
@Deprecated
public class NetworkForCreate extends Network {
}
