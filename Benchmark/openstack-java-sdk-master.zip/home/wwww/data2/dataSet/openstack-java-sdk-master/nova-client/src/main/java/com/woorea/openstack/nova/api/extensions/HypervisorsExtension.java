package com.woorea.openstack.nova.api.extensions;

public class HypervisorsExtension {

}
