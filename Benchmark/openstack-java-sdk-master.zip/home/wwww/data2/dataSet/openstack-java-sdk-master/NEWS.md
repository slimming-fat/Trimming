# 3.2.9 / 2020-04-07
* glance: Add Support for Image Service API v2

# 3.2.8 / 2020-01-29
* jackson upgraded to com.fasterxml version 2.9.x
* commons-httpclient upgraded to org.apache.httpcomponents 4.5

# 3.2.7 / 2019-05-03
* Remove maven-gpg-plugin

# 3.2.6 / 2019-05-03
* RESTEasyConnector: Support RESTEasy 3.6.3.Final

# 3.2.5 / 2018-11-14
* neutron: Add support for `port_security_enabled` on Networks

# 3.2.4 / 2018
* Improved backward compatibility to 3.1.3

# 3.2.3 / 2018-06-24
* No user visible changes

# 3.2.2 / 2018-06-23
* Add keystone v3 support
* Add missing nova utility methods for server actions
* Add heat support
* Add router support
* All fixes and improvements up to 3.1.3

# 3.1.3 / 2018-05-18
* Cinder: Add support for `os-terminate_connection`
* neutron: Support parameter mtu

# 3.1.2 / 2017-01-28
* RESTEasyConnector: Isolate the creation of ClientExecutor

# 3.1.1 / 2015-05-06
* cinder: introduce client and model
* java 7
* Fixes and improvements up to 3.0.6

# 3.2.1 / 2013-07-26
* No user visible changes

# 3.2.0 / 2013-07-26
* support quota/limits/usage operations
* logging enhancements

# 3.1.0 / 2013-07-21

