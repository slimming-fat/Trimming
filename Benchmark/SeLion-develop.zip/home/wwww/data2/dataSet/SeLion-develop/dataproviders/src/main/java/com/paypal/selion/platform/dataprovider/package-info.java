/**
 * A collection of interfaces which provides declaration of SeLion data providers.
 */
package com.paypal.selion.platform.dataprovider;