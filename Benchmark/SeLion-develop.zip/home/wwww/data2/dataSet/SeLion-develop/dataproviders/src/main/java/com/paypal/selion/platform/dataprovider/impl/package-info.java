/**
 * A collection of classes which load external data sources for data driven test scenarios. 
 * Commonly used with TestNG's DataProvider.
 */
package com.paypal.selion.platform.dataprovider.impl;