/**
 * POJOS for SeLion's XmlDataProvider implementation
 */
package com.paypal.selion.platform.dataprovider.pojos;