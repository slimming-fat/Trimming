/**
 * Filters which can be applied to any TestNG DataProvider data source in SeLion.
 */
package com.paypal.selion.platform.dataprovider.filter;