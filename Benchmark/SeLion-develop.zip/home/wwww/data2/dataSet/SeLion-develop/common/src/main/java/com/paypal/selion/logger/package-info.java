/**
 * Contains the Logger used throughout SeLion.
 */
package com.paypal.selion.logger;