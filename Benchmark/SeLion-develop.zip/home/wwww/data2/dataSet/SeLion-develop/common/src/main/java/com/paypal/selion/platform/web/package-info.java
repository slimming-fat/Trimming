/**
 * Common classes for SeLion PageYAML needs
 */
package com.paypal.selion.platform.web;