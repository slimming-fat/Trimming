/**
 * TestNG add-ons for enhancing output.
 */
package com.paypal.selion.reports.runtime;