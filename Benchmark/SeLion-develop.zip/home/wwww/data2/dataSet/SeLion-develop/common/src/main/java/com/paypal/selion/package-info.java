/**
 * Conmon classes for which are used by more than one SeLion component.
 */
package com.paypal.selion;