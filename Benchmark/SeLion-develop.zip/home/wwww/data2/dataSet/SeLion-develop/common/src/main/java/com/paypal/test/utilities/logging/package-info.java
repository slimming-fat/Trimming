/**
 * Contains re-usable logging utilities
 */
package com.paypal.test.utilities.logging;