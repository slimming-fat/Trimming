/**
 * A package which contains configuration information for SeLion.
 */
package com.paypal.selion.configuration;