/**
 * Contains a common set of utilities.
 */
package com.paypal.selion.platform.utilities;