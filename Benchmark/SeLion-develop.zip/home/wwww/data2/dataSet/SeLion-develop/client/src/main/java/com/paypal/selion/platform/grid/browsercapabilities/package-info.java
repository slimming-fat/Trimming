/**
 * Browser initiation objects for various browsers supported by SeLion.
 */
package com.paypal.selion.platform.grid.browsercapabilities;