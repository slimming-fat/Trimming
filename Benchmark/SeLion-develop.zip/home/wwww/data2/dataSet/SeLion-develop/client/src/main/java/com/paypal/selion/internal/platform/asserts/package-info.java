/**
 * Package containing internal classes required for customized hard and soft assertion in SeLion.
 */
package com.paypal.selion.internal.platform.asserts;