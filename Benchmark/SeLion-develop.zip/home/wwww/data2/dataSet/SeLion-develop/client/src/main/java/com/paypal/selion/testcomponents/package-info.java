/**
 * Contains re-usable page object components for testing.
 */
package com.paypal.selion.testcomponents;