/**
 * Package containing configuration information that are internal to SeLion framework.
 */
package com.paypal.selion.internal.configuration;