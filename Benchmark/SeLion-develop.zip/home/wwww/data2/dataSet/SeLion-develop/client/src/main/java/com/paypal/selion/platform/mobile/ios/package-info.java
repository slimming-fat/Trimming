/**
 * Contains the interfaces and classes for iOS page objects.
 */
package com.paypal.selion.platform.mobile.ios;