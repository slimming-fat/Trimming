/**
 * This package houses all of the custom annotations that are used by SeLion.
 */
package com.paypal.selion.annotations;