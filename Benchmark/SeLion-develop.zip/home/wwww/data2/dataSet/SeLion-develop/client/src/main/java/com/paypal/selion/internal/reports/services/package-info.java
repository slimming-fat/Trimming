/**
 * Package containing internal classes for reporting services.
 */
package com.paypal.selion.internal.reports.services;