/**
 * Package containing internal classes to generate test execution reports in HTML format.
 */
package com.paypal.selion.internal.reports.html;