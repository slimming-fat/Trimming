/**
 * Contains the common set of utilities to assist in writing tests using SeLion.
 */
package com.paypal.selion.platform.utilities;