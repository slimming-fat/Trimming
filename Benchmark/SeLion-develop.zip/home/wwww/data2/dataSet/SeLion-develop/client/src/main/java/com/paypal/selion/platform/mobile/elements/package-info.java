/**
 * Contains common element interfaces for both Android and iOS
 */
package com.paypal.selion.platform.mobile.elements;