/**
 * Package containing internal classes supporting runtime report generation.
 */
package com.paypal.selion.internal.reports.runtimereport;