/**
 * Classes that provide an abstraction to all the HTML elements used in SeLion.
 */
package com.paypal.selion.platform.html;