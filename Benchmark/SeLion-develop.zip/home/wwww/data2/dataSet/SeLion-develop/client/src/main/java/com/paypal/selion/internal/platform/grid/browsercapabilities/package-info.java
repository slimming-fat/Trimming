/**
 * Package containing various internal browser initiation objects for various browsers supported by SeLion.
 */
package com.paypal.selion.internal.platform.grid.browsercapabilities;