/**
 * Contains the classes and exceptions classes common to iOS and Android platforms.
 */
package com.paypal.selion.platform.mobile;