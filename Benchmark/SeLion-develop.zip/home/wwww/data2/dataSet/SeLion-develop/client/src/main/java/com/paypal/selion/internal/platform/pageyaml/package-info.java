/**
 * Internal package housing all the classes related to parsing the GUI Object map to create SeLion specific Page Objects. 
 */
package com.paypal.selion.internal.platform.pageyaml;