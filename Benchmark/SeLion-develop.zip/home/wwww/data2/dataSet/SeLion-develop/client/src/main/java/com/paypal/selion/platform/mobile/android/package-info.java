/**
 * Contains the interfaces and classes for Android page objects.
 */
package com.paypal.selion.platform.mobile.android;