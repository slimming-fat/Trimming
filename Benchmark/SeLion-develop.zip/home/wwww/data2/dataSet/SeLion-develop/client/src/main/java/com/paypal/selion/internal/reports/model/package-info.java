/**
 * Package containing internal classes related Web logging, extracting HTML source and taking screen shots to assist in test reporting.
 */
package com.paypal.selion.internal.reports.model;