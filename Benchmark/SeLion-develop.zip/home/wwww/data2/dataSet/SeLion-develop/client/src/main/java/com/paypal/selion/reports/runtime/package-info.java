/**
 * Reporting related classes and listener for debugging.
 */
package com.paypal.selion.reports.runtime;