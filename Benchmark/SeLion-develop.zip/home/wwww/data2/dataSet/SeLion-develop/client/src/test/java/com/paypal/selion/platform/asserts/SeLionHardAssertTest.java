/*-------------------------------------------------------------------------------------------------------------------*\
|  Copyright (C) 2014 PayPal                                                                                          |
|                                                                                                                     |
|  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance     |
|  with the License.                                                                                                  |
|                                                                                                                     |
|  You may obtain a copy of the License at                                                                            |
|                                                                                                                     |
|       http://www.apache.org/licenses/LICENSE-2.0                                                                    |
|                                                                                                                     |
|  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed   |
|  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for  |
|  the specific language governing permissions and limitations under the License.                                     |
\*-------------------------------------------------------------------------------------------------------------------*/

package com.paypal.selion.platform.asserts;

import org.testng.annotations.Test;

public class SeLionHardAssertTest {

    SeLionHardAssert hardAssert = new SeLionHardAssert();

    @Test(groups = { "unit" })
    public void hardAssertTest1() {

        hardAssert.assertEquals(true, true, "Hard Assert 1");
        hardAssert.assertTrue(true, "Hard Assert 2");
        hardAssert.assertNotNull(true, "Hard Assert 3");
    }

    @Test(groups = { "unit" })
    public void hardAssertTest2() {

        hardAssert.assertNotEquals(true, false, "Hard Assert 4");
        hardAssert.assertFalse(false, "Hard Assert 5");
    }

}
