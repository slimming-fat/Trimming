/**
 * Package containing internal classes to generate test execution reports in Excel format.
 */
package com.paypal.selion.internal.reports.excelreport;