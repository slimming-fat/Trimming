/**
 * A collection of classes that support local and remote test executions, concurrent session management and custom annotation to drive UI tests.
 */
package com.paypal.selion.platform.grid;