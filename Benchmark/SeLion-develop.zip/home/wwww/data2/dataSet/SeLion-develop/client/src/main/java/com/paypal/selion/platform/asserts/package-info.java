/**
 * Contains classes required for customized hard and soft assertion in SeLion.
 */
package com.paypal.selion.platform.asserts;