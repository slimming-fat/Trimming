/**
 * This package houses some of the utilities that are internally consumed by SeLion. 
 */
package com.paypal.selion.internal.utils;