/**
 * Contains the customized event strategy for web elements.
 */
package com.paypal.selion.platform.html.support.events;