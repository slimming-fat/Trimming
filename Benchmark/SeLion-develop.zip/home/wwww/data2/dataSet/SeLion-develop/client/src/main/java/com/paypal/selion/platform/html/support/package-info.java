/**
 * Contains the customized location strategy for identifying web elements.
 */
package com.paypal.selion.platform.html.support;