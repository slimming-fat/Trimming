#/bin/sh

export ANT_HOME=tools/ant

tools/ant/bin/ant $@
