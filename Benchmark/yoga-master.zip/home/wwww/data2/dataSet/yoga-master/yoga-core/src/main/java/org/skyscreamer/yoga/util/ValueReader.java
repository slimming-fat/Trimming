package org.skyscreamer.yoga.util;

public interface ValueReader
{
    Object getValue( String property );
}
