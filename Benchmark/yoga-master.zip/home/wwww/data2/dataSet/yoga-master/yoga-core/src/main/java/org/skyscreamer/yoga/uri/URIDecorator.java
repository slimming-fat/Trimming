package org.skyscreamer.yoga.uri;

public interface URIDecorator
{
    StringBuilder decorate( StringBuilder uri );
}
