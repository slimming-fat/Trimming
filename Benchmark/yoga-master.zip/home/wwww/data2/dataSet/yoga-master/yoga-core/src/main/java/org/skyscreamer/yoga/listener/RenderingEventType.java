package org.skyscreamer.yoga.listener;

public enum RenderingEventType
{
    LIST_CHILD,
    POJO_CHILD,
    MAP_CHILD
}
