package org.skyscreamer.yoga.springmvc.builder;


public class YogaSpringMVCBuilder
{

}
