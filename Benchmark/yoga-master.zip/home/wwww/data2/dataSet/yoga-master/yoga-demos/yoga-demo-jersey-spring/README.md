## Run the Yoga demo on Jersey ##

    % git clone git@github.com:skyscreamer/yoga.git
    % cd yoga
    % mvn install
    % cd yoga-demos/yoga-demo-jersey
    % mvn jetty:run

