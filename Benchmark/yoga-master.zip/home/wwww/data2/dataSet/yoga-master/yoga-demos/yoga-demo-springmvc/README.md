## Run the Yoga demo on Spring MVC ##

    % git clone git@github.com:skyscreamer/yoga.git
    % cd yoga
    % mvn install
    % cd yoga-demos/yoga-demo-springmvc
    % mvn jetty:run

