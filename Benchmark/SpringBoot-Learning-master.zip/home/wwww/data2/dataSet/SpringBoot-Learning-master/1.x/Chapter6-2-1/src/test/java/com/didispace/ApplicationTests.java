package com.didispace;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;


/**
 *
 * @author 程序猿DD
 * @version 1.0.0
 * @blog http://blog.didispace.com
 *
 */
@SpringBootTest
public class ApplicationTests {

	@Test
	public void test1() throws Exception {

	}

}
