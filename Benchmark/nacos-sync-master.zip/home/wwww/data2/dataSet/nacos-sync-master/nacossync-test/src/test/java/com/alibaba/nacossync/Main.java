/**
 * Alipay.com Inc. Copyright (c) 2004-2018 All Rights Reserved.
 */
package com.alibaba.nacossync;

/**
 *
 * @author NacosSync
 * @version $Id: Main.java, v 0.1 2018年11月13日 下午10:31 NacosSync Exp $
 */
public class Main {
    public static void main(String[] args) {

    }
}