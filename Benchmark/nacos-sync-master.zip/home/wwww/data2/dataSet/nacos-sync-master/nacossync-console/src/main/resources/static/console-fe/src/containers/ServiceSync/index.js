import ServiceSync from './ServiceSync';

export default ServiceSync;
