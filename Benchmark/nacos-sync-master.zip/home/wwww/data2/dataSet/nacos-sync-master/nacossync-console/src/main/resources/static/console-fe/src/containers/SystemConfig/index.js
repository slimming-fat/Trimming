import SystemConfig from './SystemConfig';

export default SystemConfig;
