import FuncHead from './FuncHead';

export default FuncHead;
