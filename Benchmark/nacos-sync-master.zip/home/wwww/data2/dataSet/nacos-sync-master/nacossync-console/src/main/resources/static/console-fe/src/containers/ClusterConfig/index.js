import ClusterConfig from './ClusterConfig';

export default ClusterConfig;
