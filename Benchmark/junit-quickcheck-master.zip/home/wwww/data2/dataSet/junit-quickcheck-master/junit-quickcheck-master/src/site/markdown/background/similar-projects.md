# Similar projects

* [jqwik](https://jqwik.net) - Built on JUnit 5.
* [QuickTheories](https://github.com/NCR-CoDE/QuickTheories)
* [QuickCheck](http://java.net/projects/quickcheck/pages/Home). This appears
to be test framework-agnostic, focusing instead on generators of random
values.
* [ScalaCheck](http://code.google.com/p/scalacheck/). For testing
Java or Scala code using Scala.
* [fj.test package of FunctionalJava (formerly Reductio)]
(http://functionaljava.org/)
* [JCheck](http://www.jcheck.org/)
