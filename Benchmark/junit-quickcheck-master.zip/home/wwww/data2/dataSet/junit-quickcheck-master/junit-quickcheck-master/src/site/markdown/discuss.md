# Discuss

There is [a Google group for junit-quickcheck](https://groups.google.com/d/forum/junit-quickcheck).
