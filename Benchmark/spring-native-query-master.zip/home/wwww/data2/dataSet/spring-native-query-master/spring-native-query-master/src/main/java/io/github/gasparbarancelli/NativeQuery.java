package io.github.gasparbarancelli;

public interface NativeQuery {

}
