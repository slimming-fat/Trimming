package io.github.gasparbarancelli;

public interface NativeQueryTenantNamedParameterJdbcTemplateInterceptor {

    String getTenant();

}
