package com.devonfw.module.beanmapping.common.impl.orika;

import org.springframework.stereotype.Component;

import com.devonfw.module.beanmapping.common.base.BaseOrikaConfig;

/**
 * {@link BaseOrikaConfig} for test.
 */
@Component
public class OrikaConfig extends BaseOrikaConfig {

}
