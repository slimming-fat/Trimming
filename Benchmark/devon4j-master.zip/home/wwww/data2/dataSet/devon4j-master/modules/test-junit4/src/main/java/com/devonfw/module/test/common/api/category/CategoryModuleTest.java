package com.devonfw.module.test.common.api.category;

/**
 * This is the JUnit {@link org.junit.experimental.categories.Category}
 */
public interface CategoryModuleTest {

}
