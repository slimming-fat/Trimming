package com.devonfw.module.test.common.base.clean;

/**
 * Interface for the central component performing all {@link #cleanup() cleanups}.
 */
public interface TestCleaner extends AbstractTestCleaner {

}
