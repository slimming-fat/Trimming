package com.devonfw.test.app;

import javax.inject.Named;

import com.devonfw.module.security.common.base.accesscontrol.AccessControlConfig;

/**
 * Config for tests.
 *
 */
@Named
public class TestAccessControlConfig extends AccessControlConfig {
}
