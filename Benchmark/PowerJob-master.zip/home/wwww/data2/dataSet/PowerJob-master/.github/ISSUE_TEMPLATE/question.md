---
name: "\U0001F914 Question"
about: Usage question that isn't answered in docs or discussion
labels: question
---

## Question

Before asking a question, make sure you have（在提问之前，请确保你已经）:

- Read documentation（仔细阅读了官方文档）
- Googled your question（百度搜索了你的问题）
- Searched open and closed GitHub issues（搜索了开放和关闭的 GitHub issues）

Please pay attention on issues you submitted, because we maybe need more details. 