package tech.powerjob.worker.background;

/**
 * 定期检查资源释放情况（长时间未释放的 TaskTracker 和 DB记录）
 *
 * @author tjq
 * @since 2020/3/29
 */
public class ReleaseCheckRunnable implements Runnable {
    @Override
    public void run() {

    }
}
