package com.barchart.udt;

import org.junit.Test;

public class TestAndroidLoaderUDT {

	@Test
	public void load() {

	}

}
