document.write('<div id="header">');
document.write('  <table width="100%" border="0">')
;document.write(' <tr>');
document.write('    <td><a href="http://www.slf4j.org/">');
document.write('      <img src="' + prefix + 'images/logos/slf4j-logo.jpg" alt="" border="0" height="100"/>');
document.write('       </a>')
document.write('    </td>')


document.write('   <td style="vertical-align:bottom;">');

document.write('    <div style="display: flex; float: right; align-items: flex-end;">');
document.write('       <iframe src="https://github.com/sponsors/qos-ch/button" title="Sponsor qos-ch" height="35" width="116" style="border: 0; margin-left: 1ex;"></iframe>');

document.write('      <a href="https://github.com/qos-ch/slf4j" style="margin-left: 1ex;">');
document.write('        <img src="' + prefix + 'images/GitHub-Mark-32px.png" alt="Source code" border="0"/>');
document.write('      </a>');

document.write('      <a href="https://twitter.com/qos_ch" style="margin-left: 1ex;  margin-right: 16em;">');
document.write('        <img height="32px" src="' + prefix + 'images/TwitterLogo_blue.svg" alt="Follow @qos_ch on Twitter" border="0"/>');
document.write('       </a>');

document.write('    </div>')
document.write('   </td>');
document.write('     </tr></table>');

//document.write('<td align="right"><a id="job" href="http://logback.qos.ch/job.html">');
//document.write('<img src="' + prefix + 'images/myjob.png" alt="" border="0"/>');
//document.write('</a></td>')


document.write('  <div id="headerLine"></div>');
document.write('</div>');
