package xyz.staffjoy.whoami;

public class WhoAmIConstant {
    public static final String SERVICE_NAME = "whoami-service";
}
