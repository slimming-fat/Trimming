package xyz.staffjoy.web;

public class WebConstant {
    public static final String SERVICE_NAME = "www-service";
}
