# RoboPods for Flurry

Measure, track and analyze app performance, user acquisition and activity with Flurry Analytics.

## Available RoboPods

| Platform                                  | Version | Description                  |
|-------------------------------------------|---------|------------------------------|
| [ios](ios/)                               | 7.3.0   | Flurry iOS binding           |
| [ios-ads](ios-ads/)                       | 7.3.0   | Flurry Ads iOS binding       |
| [ios-analytics](ios-analytics/)           | 7.3.0   | Flurry Analytics iOS binding |

## Official website

https://developer.yahoo.com/analytics/