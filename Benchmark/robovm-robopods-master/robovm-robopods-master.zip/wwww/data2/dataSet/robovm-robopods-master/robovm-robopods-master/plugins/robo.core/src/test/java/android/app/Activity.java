package android.app;

/**
 * Stub class used to override android.app.Activity
 */
public class Activity {}
