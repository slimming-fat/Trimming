# RoboPods for Google Analytics

Collect, configure, and analyze your data to reach the right audience.

## Available RoboPods

| Platform                 | Version | Description                                     |
|--------------------------|---------|-------------------------------------------------|
| [iOS](ios/)              | 3.15    | Google Analytics iOS binding                    |
| [iOS-noads](ios-noads/)  | 3.15    | Google Analytics iOS binding without ad support |

## Official website

http://www.google.com/analytics/