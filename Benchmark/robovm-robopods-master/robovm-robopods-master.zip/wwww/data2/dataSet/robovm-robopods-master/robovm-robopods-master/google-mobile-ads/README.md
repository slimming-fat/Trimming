# RoboPods for AdMob

AdMob is a mobile ads network. Gain insights about your users, drive more in-app purchases, and maximize your ad revenue.

## Available RoboPods

| Platform    | Version |
|-------------|---------|
| [iOS](ios/) | 7.5.2   |
|             |         |

## Official website

https://developers.google.com/admob