# RoboPods for Heyzap

The mobile ad network Heyzap runs multiple premium networks under one integration so you can dynamically test ad networks against each other and visualize their combined performance.


## Available RoboPods

| Platform            | Version |
|---------------------|---------|
| [iOS](ios/)         | 9.3.5   |
|                     |         |

## Official website

https://www.heyzap.com/