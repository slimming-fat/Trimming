# RoboPods for Google SignIn

Get users into your apps quickly and securely, using a registration system they already use and trust—their Google account.

## Available RoboPods

| Platform    | Version |
|-------------|---------|
| [iOS](ios/) | 2.4.0   |
|             |         |

## Official website

https://developers.google.com/identity/