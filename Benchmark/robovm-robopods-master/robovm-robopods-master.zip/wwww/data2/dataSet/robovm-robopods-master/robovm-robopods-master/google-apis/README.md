# RoboPods for Google APIs

Google APIs is used by several Google services such as Google Analytics to configure them in a single configuration file.

## Available RoboPods

| Platform    | Version |
|-------------|---------|
| [iOS](ios/) | 1.0     |
|             |         |