# RoboPods for Google Play Game Services

Start integrating popular gaming features in your mobile games and web games by using the Google Play games services APIs.

## Available RoboPods

| Platform    | Version |
|-------------|---------|
| [iOS](ios/) | 2.0     |
|             |         |

## Official website

https://developers.google.com/games/services/