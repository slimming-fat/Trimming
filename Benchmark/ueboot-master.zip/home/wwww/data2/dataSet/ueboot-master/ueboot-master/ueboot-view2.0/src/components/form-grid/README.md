## 依赖的组件
  - deep-extend (深度copy对象)
  https://github.com/unclechu/node-deep-extend
- vue-resource(ajax异步请求)
  - iview(主体UI样式);
https://www.iviewui.com/
