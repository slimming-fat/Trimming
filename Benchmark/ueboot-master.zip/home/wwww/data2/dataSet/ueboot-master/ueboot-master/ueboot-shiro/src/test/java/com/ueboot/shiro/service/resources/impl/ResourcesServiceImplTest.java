package com.ueboot.shiro.service.resources.impl;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * @author yangkui
 * createTime:2018/11/27:59 PM
 */
public class ResourcesServiceImplTest {

    @Test
    public void getUserResources() {
    }

    @Test
    public void findByResourceType() {
    }

    @Test
    public void findById() {
    }

    @Test
    public void findByParentId() {
    }

    @Test
    public void deleteResource() {
    }
}