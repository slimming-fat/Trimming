package com.ueboot.shiro.service.organization.impl;

/**
 * @author yangkui
 * createTime:2018/11/27:30 PM
 */
public class Test {
}
