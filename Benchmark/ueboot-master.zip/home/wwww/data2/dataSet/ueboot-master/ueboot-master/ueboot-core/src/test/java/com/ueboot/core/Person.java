/*
 * Copyright (c)  2018, XiQiao
 * All rights reserved. 
 *
 * Id:Person.java   2018-08-29 18:09 wanglijun
 */
package com.ueboot.core;

/**
 * <p>
 * Title:
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Copyright: Copyright (c) 2018
 * </p>
 * <p>
 * Company: XiQiao
 * </p>
 *
 * @author: wanglijun
 * @create: 2018-08-29 18:09
 * @version：1.0
 */

public class Person {

}
