# 说明
- 当前目录为示例代码，用于本地调试ueboot框架使用
- 示例代码模拟了使用ueboot的一些场景，启动时定位到examples目录下，执行npm run serve命令即可
