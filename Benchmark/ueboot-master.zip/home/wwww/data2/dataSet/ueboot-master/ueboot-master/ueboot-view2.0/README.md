# taobao npm 私服
npm i --save --registry=https://registry.npm.taobao.org

# ueboot 框架使用示例说明
> 基于iView4.x开发的一套CRUD开发组件，可以快速完成单表的CRUD功能，配合后端ueboot组件，快速完成前后端开发

 - 详细使用文档，参见： http://www.ueboot.com

