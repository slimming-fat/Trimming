import UFormGrid from './UFormGrid.vue'
UFormGrid.install=function (Vue) {
  Vue.component(UFormGrid.name,UFormGrid);
};
export default UFormGrid
