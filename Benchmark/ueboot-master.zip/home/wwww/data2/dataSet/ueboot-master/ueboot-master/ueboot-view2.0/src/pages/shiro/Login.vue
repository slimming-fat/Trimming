<template>
    <div style="height: 100%">
        <div class="login" v-if="config.page_login.theme === 'theme1'">
            <Row class="vm-login vm-panel">
                <i-col span="14" class="login-ad">
                    <span class="photo-author"></span>
                </i-col>
                <i-col span="10" class="login-form">
                    <div class="login-header">
                        <img :src="config.logoImage" :alt="config.sysTitle">
                        <p><span>{{config.sysTitle}}</span></p>
                    </div>
                    <div class="login-form">
                        <Form ref="formCustom" :model="formCustom" class="login-container">
                            <i-input v-model="formCustom.username" placeholder="请输入登录账号"></i-input>
                            <i-input v-model="formCustom.password" type="password" placeholder="请输入密码"></i-input>
                            <Row type="flex" justify="space-between"  v-if="config.page_login.captcha.show">
                                <i-col span="16">
                                    <i-input type="text" @on-enter="handleSubmit('formCustom')"
                                             v-model="formCustom.captcha" :maxlength="config.page_login.captcha.codeCount"
                                             placeholder="请输入验证码"></i-input>
                                </i-col>
                                <i-col span="8">
                                    <img :src="captchaUrl" @click="changeCaptchaUrl" width="100%" height="45px"
                                         style="border-radius: 4px"/>
                                </i-col>
                            </Row>
                            <Button type="primary" @click="handleSubmit('formCustom')" :loading="loading">登录</Button>
                        </Form>
                    </div>
                    <div class="login-footer">
                    </div>
                </i-col>
            </Row>
        </div>
        <div v-if="config.page_login.theme === 'theme2'" style="height: 100%;">
            <div class="form-body without-side">
                <div class="website-logo">
                    <div class="logo">
                        <img class="logo-size" :src="config.logoImage" :alt="config.sysTitle"
                             :style="config.page_login.logoStyle" v-if="config.logoImage!==''">
                    </div>
                </div>
                <div class="row">
                    <div class="img-holder">
                        <div class="bg"></div>
                        <div class="info-holder">
                            <img
                                src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 890.649 841.993'%3E%3Cdefs%3E%3Cstyle%3E.cls-1,.cls-3,.cls-4%7Bfill:%238982bc%7D.cls-1%7Bopacity:.17%7D.cls-2%7Bfill:%23ddd6ff%7D.cls-14,.cls-3%7Bopacity:.18%7D.cls-6%7Bfill:%23624fb5%7D.cls-7%7Bfill:%23fff%7D.cls-12%7Bfill:%23c4b9ff%7D.cls-13%7Bfill:%23fe9887%7D.cls-15%7Bfill:%233f327a%7D.cls-16%7Bfill:%23f7d3a9%7D.cls-17%7Bfill:%23ffc359%7D.cls-18%7Bfill:%23353e70%7D.cls-19%7Bfill:%23d69e43%7D.cls-21%7Bfill:%232c2656%7D.cls-23%7Bfill:%23ce6c5f%7D.cls-24%7Bfill:%23453c87%7D.cls-25%7Bfill:%23dba246%7D.cls-26%7Bfill:%23d3ab84%7D.cls-28%7Bfill:%23232049%7D.cls-32%7Bfill:rgba(255,255,255,.18)%7D.cls-34%7Bfill:%2358bb85%7D.cls-37%7Bfill:%23ffd052%7D.cls-39%7Bfill:rgba(255,255,255,.44)%7D.cls-41%7Bfill:rgba(255,255,255,.29)%7D.cls-42%7Bfill:rgba(255,255,255,.32)%7D%3C/style%3E%3C/defs%3E%3Cg id='Group_456' data-name='Group 456' transform='translate(-.018 -.097)'%3E%3Cellipse id='Ellipse_20' cx='46.393' cy='4.303' class='cls-1' data-name='Ellipse 20' rx='46.393' ry='4.303' transform='translate(192.102 833.485)'/%3E%3Cpath id='Path_650' d='M142.285 405.5c0 2.432-20.764 4.3-46.393 4.3S49.5 407.934 49.5 405.5s20.764-4.3 46.393-4.3 46.392 1.871 46.392 4.3z' class='cls-1' data-name='Path 650' transform='translate(43.083 349.227)'/%3E%3Cellipse id='Ellipse_21' cx='57.617' cy='4.303' class='cls-1' data-name='Ellipse 21' rx='57.617' ry='4.303' transform='translate(664.82 757.91)'/%3E%3Cpath id='Path_651' d='M263.361 404.448c0 2.058-18.333 3.741-40.781 3.741s-40.781-1.684-40.781-3.741 18.333-3.741 40.781-3.741c22.636-.187 40.781 1.493 40.781 3.741z' class='cls-1' data-name='Path 651' transform='translate(158.272 348.785)'/%3E%3Cg id='Group_310' data-name='Group 310' transform='translate(187.239 272.097)'%3E%3Cpath id='Path_652' d='M101.4 146v476.272h506.016V161.9z' class='cls-2' data-name='Path 652' transform='translate(-98.968 -145.065)'/%3E%3Cpath id='Path_653' d='M177.283 333.3L169.8 462.563l254.037-4.115z' class='cls-3' data-name='Path 653' transform='translate(-39.414 18.011)'/%3E%3Cpath id='Path_654' d='M177.167 468.184l-3.367-128.7L416.051 326.2l4.3 138.429z' class='cls-4' data-name='Path 654' transform='translate(-35.932 11.83)'/%3E%3Cpath id='Path_655' d='M220.3 245.061l2.806 120.284 250.108-2.058L461.616 222.8z' class='cls-3' data-name='Path 655' transform='translate(4.554 -78.197)'/%3E%3Cpath id='Path_656' fill='%23eff3fb' d='M100.1 174.308l508.448 3.554v-20.577L100.1 145.5z' data-name='Path 656' transform='translate(-100.1 -145.5)'/%3E%3Cpath id='Path_657' d='M100.1 160.9v41.716h508.448v-38.162z' class='cls-6' data-name='Path 657' transform='translate(-100.1 -132.092)'/%3E%3Ccircle id='Ellipse_22' cx='14.778' cy='14.778' r='14.778' class='cls-7' data-name='Ellipse 22' transform='rotate(-76.761 54.335 10.249)'/%3E%3Cpath id='Path_658' d='M144.3 169.4v10.1h74.078v-10.1' class='cls-7' data-name='Path 658' transform='translate(-61.616 -124.691)'/%3E%3Cpath id='Path_659' d='M206 165.6v26.938h187.441v-24.693z' class='cls-7' data-name='Path 659' transform='translate(-7.896 -128)'/%3E%3Ctext id='Text' fill='%234d7eb7' font-family='Gilroy-Light,Gilroy' font-size='10' font-weight='300' transform='translate(210.57 54.244)'%3E%3Ctspan x='0' y='0'%3EText%3C/tspan%3E%3C/text%3E%3Cg id='Group_309' data-name='Group 309' transform='translate(14.03 13.095)'%3E%3Ccircle id='Ellipse_23' cx='3.18' cy='3.18' r='3.18' fill='%23fc846d' data-name='Ellipse 23'/%3E%3Ccircle id='Ellipse_24' cx='3.18' cy='3.18' r='3.18' fill='%23f9d452' data-name='Ellipse 24' transform='translate(14.591)'/%3E%3Cpath id='Path_660' fill='%2357be8b' d='M129.56 155.68a3.18 3.18 0 1 1-3.18-3.18 3.045 3.045 0 0 1 3.18 3.18z' data-name='Path 660' transform='translate(-94.018 -152.5)'/%3E%3C/g%3E%3Cpath id='Rectangle_23' d='M0 0h6.734v85.302H0z' class='cls-12' data-name='Rectangle 23' transform='translate(43.212 103.635)'/%3E%3Cpath id='Path_661' d='M134.5 204.822v7.109h92.411l1.122-8.231z' class='cls-4' data-name='Path 661' transform='translate(-70.149 -94.827)'/%3E%3Cpath id='Path_662' d='M217.9 199.635v7.109h257.591l3.18-8.044z' class='cls-4' data-name='Path 662' transform='translate(2.465 -99.18)'/%3E%3Cpath id='Path_663' d='M217.9 303.135v7.109h257.591l3.18-8.044z' class='cls-4' data-name='Path 663' transform='translate(2.465 -9.066)'/%3E%3Cpath id='Path_664' d='M217.9 212.735v7.109h98.023l1.309-8.044z' class='cls-4' data-name='Path 664' transform='translate(2.465 -87.775)'/%3E%3Cpath id='Path_665' d='M217.9 316.522v7.109h98.023l1.309-8.231z' class='cls-4' data-name='Path 665' transform='translate(2.465 2.427)'/%3E%3Cpath id='Path_666' d='M135 216.1v7.3h92.224l.374-6.547z' class='cls-4' data-name='Path 666' transform='translate(-69.714 -84.031)'/%3E%3Cpath id='Path_667' d='M134.8 228.8v7.109h92.224l.374-6.547z' class='cls-4' data-name='Path 667' transform='translate(-69.888 -72.973)'/%3E%3Cpath id='Path_668' d='M134.8 242.7v7.3h92.224l.374-6.547z' class='cls-4' data-name='Path 668' transform='translate(-69.888 -60.871)'/%3E%3Cpath id='Path_669' d='M220.3 241.648l10.476 127.018 241.5-19.829-10.66-129.637z' class='cls-13' data-name='Path 669' transform='translate(4.554 -81.332)'/%3E%3C/g%3E%3Cg id='Group_311' class='cls-14' data-name='Group 311' transform='translate(624.647 525.175)'%3E%3Cpath id='Path_670' d='M338.368 298.582a53.746 53.746 0 0 1-4.3-13.095 4.559 4.559 0 0 1 0-2.245c.374-1.684 2.432-2.619 4.115-2.432a7 7 0 0 1 4.3 2.619c1.122 1.309 2.245 2.806 3.367 3.928a26.764 26.764 0 0 0 2.806 2.058 51.551 51.551 0 0 0 7.3 3.367c1.684.561 3.367.935 4.49 2.058a14.083 14.083 0 0 1-5.612.748 68.858 68.858 0 0 0-17.4 1.871 1.794 1.794 0 0 1 1.684-.374' class='cls-4' data-name='Path 670' transform='translate(-333.925 -280.787)'/%3E%3C/g%3E%3Cg id='Group_312' class='cls-14' data-name='Group 312' transform='translate(642.46 457.998)'%3E%3Cpath id='Path_671' d='M364.124 299.357c-4.677-2.432-5.986-8.231-7.3-13.282a91.839 91.839 0 0 0-11.037-26.563 15.392 15.392 0 0 1-2.245-4.677 8.315 8.315 0 0 1 4.3-8.418 13.57 13.57 0 0 1 9.727-1.122z' class='cls-4' data-name='Path 671' transform='translate(-343.447 -244.876)'/%3E%3C/g%3E%3Cg id='Group_354' data-name='Group 354' transform='translate(629.594 460.268)'%3E%3Cg id='Group_338' data-name='Group 338'%3E%3Cpath id='Path_672' d='M366.3 381.445l2.993 4.864 3.741-1.871-3.367-5.238z' class='cls-2' data-name='Path 672' transform='translate(-310.683 -130.195)'/%3E%3Cpath id='Path_673' d='M384.469 390.448s-16.649-3.928-19.268-1.871 19.268 4.864 19.268 4.864z' class='cls-15' data-name='Path 673' transform='translate(-311.829 -122.549)'/%3E%3Cpath id='Path_674' d='M347.1 294.052s.187-8.418-.374-8.418c-1.5-.374-1.684 3.928-1.684 3.928s-2.619-8.231-3.741-7.857c-.748.187.187 5.051.187 5.051s-2.058-3.741-3.18-3.554c-.935.187 1.122 5.425 1.122 5.425s-1.871-2.432-2.806-2.245c-.748.187 5.986 11.411 5.986 11.411z' class='cls-16' data-name='Path 674' transform='translate(-336.569 -215.091)'/%3E%3Cpath id='Path_675' d='M368.879 328.3S342.5 360.288 355.6 397.889c13.282 37.6 22.074 41.529 22.074 41.529l7.67-3.928S370.563 400.321 370 387.6c-.561-11.6 19.642-38.91 19.642-38.91l-4.116 103.448 9.727 1.31s26-115.981 23.2-124.961c-2.62-9.353-14.218-22.448-49.574-.187z' class='cls-15' data-name='Path 675' transform='translate(-323.177 -185.175)'/%3E%3Cpath id='Path_676' d='M374.53 313.118l5.8 43.774 47.328-5.612L408.389 283l-14.217 2.245-10.1 1.122c-5.8.748-9.353 1.684-13.469 5.8l-16.464 18.893-8.231-19.642-7.109 3.554s5.8 35.73 15.152 32.176c6.362-2.432 20.579-14.03 20.579-14.03z' class='cls-17' data-name='Path 676' transform='translate(-334.626 -213.953)'/%3E%3Cpath id='Path_677' d='M356.56 253.8s10.476 26.376 11.785 30.492 30.118 24.132 30.118 24.132l-14.217 6.547-27.873-25.815L350.2 253.8h6.36z' class='cls-17' data-name='Path 677' transform='translate(-324.701 -239.377)'/%3E%3Cg id='Group_313' data-name='Group 313' transform='translate(38.539 38.171)'%3E%3Cpath id='Path_678' d='M361.341 268.7l-3.928 13.843a5.708 5.708 0 0 0 3.928 7.108l1.871.561v9.914h8.418a5.429 5.429 0 0 0 5.425-5.425v-22.447z' class='cls-16' data-name='Path 678' transform='translate(-357.171 -264.575)'/%3E%3Cpath id='Path_679' d='M369.186 292.881c-1.5-1.122-3.741-3.18-3.741-5.986 0 0 5.8-.187 4.3-4.3-.935-2.432-4.3-.561-4.3-.561s1.309-5.051.561-6.734c0 0-10.1 0-8.418-5.986 0 0 2.806-2.619 9.166-2.806 6.36-.374 9.727 10.289 9.727 10.289l-5.238 15.339c-.56.932-1.496 1.306-2.057.745z' class='cls-18' data-name='Path 679' transform='translate(-356.972 -266.495)'/%3E%3C/g%3E%3Cpath id='Path_680' d='M352.653 260.513s-5.238-6.547-5.051-6.921c.935-1.309 3.741 1.871 3.741 1.871s-3.18-8.044-1.871-8.605c.748-.187 2.806 4.115 2.806 4.115s-.748-4.3.187-4.864c.935-.374 2.432 4.864 2.432 4.864s0-2.993.935-3.367c.561-.187 2.432 12.721 2.432 12.721h-5.612z' class='cls-16' data-name='Path 680' transform='translate(-326.967 -246.09)'/%3E%3Cg id='Group_314' data-name='Group 314' transform='translate(38.959 91.617)'%3E%3Cpath id='Path_681' d='M369 295.13c0 .187-.561.374-1.684 1.309-.935.748-2.432 1.871-3.928 2.993-3.18 2.245-5.8 3.928-5.986 3.741s2.432-2.058 5.425-4.3c1.5-1.122 2.993-2.058 4.115-2.806 1.312-.937 2.058-1.124 2.058-.937z' class='cls-19' data-name='Path 681' transform='translate(-357.395 -295.065)'/%3E%3C/g%3E%3Cg id='Group_315' data-name='Group 315' transform='translate(44.767 64.931)'%3E%3Cpath id='Path_682' d='M374.156 280.8h.187c.187 0 .187.374.374.561a8.389 8.389 0 0 1-.187 2.058 7.44 7.44 0 0 1-1.122 2.993 9.372 9.372 0 0 1-1.31 1.5 5.849 5.849 0 0 1-1.871.935 25.271 25.271 0 0 1-6.922.935c-1.684 0-2.806-.187-2.806-.374s1.122 0 2.806-.187a34.247 34.247 0 0 0 6.547-1.122 5.289 5.289 0 0 0 2.806-2.058 8.821 8.821 0 0 0 1.122-2.806 9.649 9.649 0 0 0 .374-2.058c.189-.19-.185-.377.002-.377z' class='cls-19' data-name='Path 682' transform='translate(-360.5 -280.8)'/%3E%3C/g%3E%3Cg id='Group_316' data-name='Group 316' transform='translate(18.578 96.92)'%3E%3Cpath id='Path_683' d='M346.874 304.26a.819.819 0 0 1 .187.561h-.374a14.273 14.273 0 0 1-.187-3.18c.187-2.058.561-3.741.748-3.741s.187 1.684 0 3.741c0 1.31-.187 2.619-.187 3.18h-.374a.819.819 0 0 1 .187-.561z' class='cls-19' data-name='Path 683' transform='translate(-346.5 -297.9)'/%3E%3C/g%3E%3Cg id='Group_317' data-name='Group 317' transform='translate(19.39 95.984)'%3E%3Cpath id='Path_684' d='M348.18 303.2a8.545 8.545 0 0 1-.935-2.806c-.374-1.684-.374-2.993-.187-2.993a8.547 8.547 0 0 1 .935 2.806c.187 1.683.374 2.993.187 2.993z' class='cls-19' data-name='Path 684' transform='translate(-346.934 -297.4)'/%3E%3C/g%3E%3Cg id='Group_318' data-name='Group 318' transform='translate(3.799 79.299)'%3E%3Cpath id='Path_685' d='M346.644 288.517a18.293 18.293 0 0 1-3.928 1.871c-2.245.748-4.115 1.309-4.115 1.122a18.3 18.3 0 0 1 3.928-1.871c2.244-.748 4.115-1.309 4.115-1.122z' class='cls-19' data-name='Path 685' transform='translate(-338.6 -288.481)'/%3E%3C/g%3E%3Cg id='Group_319' data-name='Group 319' transform='translate(45.113 133.211)'%3E%3Cpath id='Path_686' d='M406.358 317.3s-.561.374-1.5.935a25.594 25.594 0 0 1-4.677 1.684c-4.115 1.122-9.914 2.432-16.275 3.554-3.18.561-6.173 1.122-8.979 1.5s-5.238.748-7.483.935a13.482 13.482 0 0 1-5.051-.374c-1.122-.187-1.871-.561-1.684-.561a12.1 12.1 0 0 0 1.871.374 22.17 22.17 0 0 0 5.051 0 63.66 63.66 0 0 0 7.3-1.122c2.806-.374 5.8-.935 8.979-1.5 6.36-1.122 12.159-2.432 16.275-3.367a47.617 47.617 0 0 0 4.677-1.5 4.514 4.514 0 0 0 1.496-.558z' class='cls-19' data-name='Path 686' transform='translate(-360.685 -317.3)'/%3E%3C/g%3E%3Cpath id='Path_687' fill='%238982bc' d='M368.276 294.9s-2.806 20.39-8.605 23.57l-1.871-14.965z' data-name='Path 687' opacity='.25' transform='translate(-318.084 -203.592)'/%3E%3Cpath id='Path_688' d='M359.786 274.618a11.414 11.414 0 0 1-2.432-2.806c-.374-1.31.187-4.49 1.31-5.238 1.309-.748 2.993 0 4.49.187 2.245.374 4.49-.561 6.922-.748 2.245-.187 5.051.561 5.8 2.619.187.374.187.935.748 1.122h.561c1.871-.187 2.993 1.871 2.993 3.741-.187 1.871-1.122 3.367-1.5 5.051-.935 3.741.748 8.044-.935 11.6-1.31 2.806-5.425 5.238-8.231 3.18l3.554-16.088z' class='cls-18' data-name='Path 688' transform='translate(-318.573 -228.767)'/%3E%3Cpath id='Path_689' d='M377.577 382s-15.527 6.922-16.462 10.1 18.333-7.857 18.333-7.857z' class='cls-15' data-name='Path 689' transform='translate(-315.226 -127.757)'/%3E%3Cg id='Group_320' data-name='Group 320' transform='translate(37.284 197.541)'%3E%3Cpath id='Path_690' d='M366.04 351.71c.187.187-1.871 1.5-4.49 2.993s-4.864 2.245-5.051 2.058a37.084 37.084 0 0 1 4.677-2.806c2.624-1.31 4.677-2.433 4.864-2.245z' class='cls-21' data-name='Path 690' transform='translate(-356.5 -351.689)'/%3E%3C/g%3E%3Cg id='Group_321' data-name='Group 321' transform='translate(39.886 202.005)'%3E%3Cpath id='Path_691' d='M364.643 354.122c0 .187-1.5.748-3.367 1.871s-3.18 2.058-3.367 1.871 1.122-1.5 2.993-2.619c1.87-.936 3.741-1.31 3.741-1.123z' class='cls-21' data-name='Path 691' transform='translate(-357.891 -354.075)'/%3E%3C/g%3E%3Cg id='Group_322' data-name='Group 322' transform='translate(70.395 207.447)'%3E%3Cpath id='Path_692' d='M384.863 360.381c0 .187-2.619-.187-5.425-1.122a18.619 18.619 0 0 1-5.238-2.245c0-.187 2.432.561 5.425 1.5 2.806.931 5.238 1.68 5.238 1.867z' class='cls-21' data-name='Path 692' transform='translate(-374.2 -356.984)'/%3E%3C/g%3E%3Cg id='Group_323' data-name='Group 323' transform='translate(71.518 204.837)'%3E%3Cpath id='Path_693' d='M385.089 360.1c0 .187-2.432-.374-5.425-1.684a15.241 15.241 0 0 1-4.864-2.806c.187-.187 2.432.935 5.238 2.058a42.606 42.606 0 0 1 5.051 2.432z' class='cls-21' data-name='Path 693' transform='translate(-374.8 -355.589)'/%3E%3C/g%3E%3Cg id='Group_337' data-name='Group 337' transform='translate(35.897 142.751)'%3E%3Cg id='Group_324' data-name='Group 324' transform='translate(19.646 108.825)'%3E%3Cpath id='Path_694' d='M366.334 380.622c.187-.187.561.187.935.935.374.561.561 1.122.374 1.31s-.561-.187-.935-.935-.561-1.31-.374-1.31z' class='cls-21' data-name='Path 694' transform='translate(-366.261 -380.575)'/%3E%3C/g%3E%3Cg id='Group_325' data-name='Group 325' transform='translate(14.669 100.057)'%3E%3Cpath id='Path_695' d='M363.6 375.911c.187-.187.935.748 1.5 2.058.748 1.122 1.122 2.245.935 2.432s-.935-.748-1.5-2.058a10.922 10.922 0 0 1-.935-2.432z' class='cls-21' data-name='Path 695' transform='translate(-363.6 -375.887)'/%3E%3C/g%3E%3Cg id='Group_326' data-name='Group 326' transform='translate(10.318 91.102)'%3E%3Cpath id='Path_696' d='M361.323 371.1a6.119 6.119 0 0 1 1.31 2.058c.561 1.31.935 2.245.748 2.432a6.119 6.119 0 0 1-1.309-2.058c-.562-1.123-.936-2.245-.749-2.432z' class='cls-21' data-name='Path 696' transform='translate(-361.274 -371.1)'/%3E%3C/g%3E%3Cg id='Group_327' data-name='Group 327' transform='translate(6.575 81.935)'%3E%3Cpath id='Path_697' d='M359.323 366.2a5.8 5.8 0 0 1 1.309 2.245c.561 1.31.748 2.432.561 2.432a5.8 5.8 0 0 1-1.309-2.245c-.374-1.31-.748-2.432-.561-2.432z' class='cls-21' data-name='Path 697' transform='translate(-359.273 -366.2)'/%3E%3C/g%3E%3Cg id='Group_328' data-name='Group 328' transform='translate(3.558 72.395)'%3E%3Cpath id='Path_698' d='M357.734 361.1a4.418 4.418 0 0 1 1.122 2.245c.374 1.31.561 2.432.374 2.432a4.418 4.418 0 0 1-1.122-2.245c-.374-1.31-.561-2.432-.374-2.432z' class='cls-21' data-name='Path 698' transform='translate(-357.661 -361.1)'/%3E%3C/g%3E%3Cg id='Group_329' data-name='Group 329' transform='translate(1.122 62.667)'%3E%3Cpath id='Path_699' d='M356.436 355.9c.187 0 .561.935.935 2.432.374 1.309.374 2.432.187 2.432s-.561-.935-.935-2.432c-.187-1.31-.374-2.432-.187-2.432z' class='cls-21' data-name='Path 699' transform='translate(-356.359 -355.9)'/%3E%3C/g%3E%3Cg id='Group_330' data-name='Group 330' transform='translate(0 52.753)'%3E%3Cpath id='Path_700' d='M356.023 350.6c.187 0 .374 1.122.561 2.432 0 1.31 0 2.432-.187 2.432s-.374-1.122-.561-2.432 0-2.432.187-2.432z' class='cls-21' data-name='Path 700' transform='translate(-355.759 -350.6)'/%3E%3C/g%3E%3Cg id='Group_331' data-name='Group 331' transform='translate(.078 42.651)'%3E%3Cpath id='Path_701' d='M356.361 345.2c.187 0 .187 1.122.187 2.432-.187 1.31-.374 2.432-.561 2.432s-.187-1.122-.187-2.432c.187-1.31.374-2.432.561-2.432z' class='cls-21' data-name='Path 701' transform='translate(-355.8 -345.2)'/%3E%3C/g%3E%3Cg id='Group_332' data-name='Group 332' transform='translate(1.264 32.924)'%3E%3Cpath id='Path_702' d='M357.68 340c.187 0 .187 1.122-.187 2.432a6.676 6.676 0 0 1-.935 2.432c-.187 0-.187-1.122.187-2.432.373-1.497.747-2.432.935-2.432z' class='cls-21' data-name='Path 702' transform='translate(-356.434 -340)'/%3E%3C/g%3E%3Cg id='Group_333' data-name='Group 333' transform='translate(3.936 23.383)'%3E%3Cpath id='Path_703' d='M359.616 334.9c.187 0 0 1.122-.561 2.432s-.935 2.245-1.122 2.245 0-1.122.561-2.432a4.418 4.418 0 0 1 1.122-2.245z' class='cls-21' data-name='Path 703' transform='translate(-357.862 -334.9)'/%3E%3C/g%3E%3Cg id='Group_334' data-name='Group 334' transform='translate(7.699 14.404)'%3E%3Cpath id='Path_704' d='M362.167 330.1c.187.187-.187 1.122-.748 2.432a4.076 4.076 0 0 1-1.5 2.058c-.187 0 .187-1.122.748-2.432.752-1.31 1.313-2.058 1.5-2.058z' class='cls-21' data-name='Path 704' transform='translate(-359.874 -330.1)'/%3E%3C/g%3E%3Cg id='Group_335' data-name='Group 335' transform='translate(12.575 5.962)'%3E%3Cpath id='Path_705' d='M365.323 325.611c.187.187-.374 1.122-1.122 2.245s-1.5 2.058-1.684 1.871.374-1.122 1.122-2.245 1.497-2.058 1.684-1.871z' class='cls-21' data-name='Path 705' transform='translate(-362.481 -325.587)'/%3E%3C/g%3E%3Cg id='Group_336' data-name='Group 336' transform='translate(18.153)'%3E%3Cpath id='Path_706' d='M367.216 322.4c.187.187 0 .748-.561 1.122-.374.561-.935.935-1.122.748s0-.748.561-1.122c.561-.561.935-.748 1.122-.748z' class='cls-21' data-name='Path 706' transform='translate(-365.462 -322.4)'/%3E%3C/g%3E%3C/g%3E%3C/g%3E%3Cg id='Group_353' data-name='Group 353' transform='translate(43.229 153.414)'%3E%3Cg id='Group_339' data-name='Group 339' transform='translate(52.215 12.72)'%3E%3Cpath id='Path_707' d='M415.107 470.711c-.561.187-7.109-30.118-14.591-67.718-7.67-37.413-13.282-67.905-12.908-68.092.561-.187 7.109 30.118 14.591 67.718 7.67 37.6 13.469 67.905 12.908 68.092z' class='cls-4' data-name='Path 707' transform='translate(-387.591 -334.9)'/%3E%3C/g%3E%3Cg id='Group_340' data-name='Group 340' transform='translate(74.663 12.72)'%3E%3Cpath id='Path_708' d='M427.107 470.711c-.561.187-7.109-30.118-14.591-67.718-7.67-37.413-13.282-67.905-12.908-68.092.561-.187 7.109 30.118 14.591 67.718 7.67 37.6 13.469 67.905 12.908 68.092z' class='cls-4' data-name='Path 708' transform='translate(-399.591 -334.9)'/%3E%3C/g%3E%3Cpath id='Rectangle_24' d='M0 0h67.531v12.721H0z' class='cls-4' data-name='Rectangle 24' transform='translate(12.388)'/%3E%3Cg id='Group_343' data-name='Group 343' transform='translate(0 6.547)'%3E%3Cg id='Group_341' data-name='Group 341' transform='translate(18.146)'%3E%3Cpath id='Path_709' d='M393.925 331.6c.561 0-4.677 31.988-11.411 71.085-6.734 39.284-12.721 70.9-13.095 70.9-.561 0 4.677-31.988 11.411-71.272 6.735-39.098 12.534-70.9 13.095-70.713z' class='cls-4' data-name='Path 709' transform='translate(-369.378 -331.6)'/%3E%3C/g%3E%3Cg id='Group_342' data-name='Group 342'%3E%3Cpath id='Path_710' d='M384.225 331.6c.561 0-4.677 31.988-11.411 71.085-6.734 39.284-12.721 70.9-13.095 70.9-.561 0 4.677-31.988 11.411-71.272 6.735-39.098 12.721-70.9 13.095-70.713z' class='cls-4' data-name='Path 710' transform='translate(-359.678 -331.6)'/%3E%3C/g%3E%3C/g%3E%3Cpath id='Path_711' d='M393.8 365.2h22.261l1.122 5.238h-22.448z' class='cls-4' data-name='Path 711' transform='translate(-329.969 -295.798)'/%3E%3Cg id='Group_344' data-name='Group 344' transform='translate(2.473 134.119)'%3E%3Cpath id='Path_712' d='M379.52 399.991c0 .561-3.928 1.5-9.166 2.245-5.051.748-9.353.935-9.353.374s3.928-1.5 9.166-2.245c5.05-.565 9.166-.749 9.353-.374z' class='cls-4' data-name='Path 712' transform='translate(-361 -399.796)'/%3E%3C/g%3E%3Cg id='Group_345' data-name='Group 345' transform='translate(4.344 122.202)'%3E%3Cpath id='Path_713' d='M380.52 393.752c0 .561-3.928 1.5-9.166 2.245-5.051.748-9.353.935-9.353.374s3.928-1.5 9.166-2.245c5.05-.748 9.353-.935 9.353-.374z' class='cls-4' data-name='Path 713' transform='translate(-362 -393.426)'/%3E%3C/g%3E%3Cg id='Group_346' data-name='Group 346' transform='translate(6.402 108.547)'%3E%3Cpath id='Path_714' d='M381.62 386.452c0 .561-3.928 1.5-9.166 2.245-5.051.748-9.353.935-9.353.374s3.928-1.5 9.166-2.245c5.05-.748 9.353-.935 9.353-.374z' class='cls-4' data-name='Path 714' transform='translate(-363.1 -386.126)'/%3E%3C/g%3E%3Cg id='Group_347' data-name='Group 347' transform='translate(8.833 94.891)'%3E%3Cpath id='Path_715' d='M382.92 379.152c0 .561-3.928 1.5-9.166 2.245-5.051.748-9.353.935-9.353.374s3.928-1.5 9.166-2.245c5.05-.748 9.166-.935 9.353-.374z' class='cls-4' data-name='Path 715' transform='translate(-364.4 -378.826)'/%3E%3C/g%3E%3Cg id='Group_348' data-name='Group 348' transform='translate(10.517 82.731)'%3E%3Cpath id='Path_716' d='M383.82 372.652c0 .561-3.928 1.5-9.166 2.245-5.051.748-9.353.935-9.353.374s3.928-1.5 9.166-2.245c5.05-.748 9.166-.935 9.353-.374z' class='cls-4' data-name='Path 716' transform='translate(-365.3 -372.326)'/%3E%3C/g%3E%3Cg id='Group_349' data-name='Group 349' transform='translate(13.51 70.385)'%3E%3Cpath id='Path_717' d='M385.42 366.052c0 .561-3.928 1.5-9.166 2.245-5.051.748-9.353.935-9.353.374s3.928-1.5 9.166-2.245 9.353-.935 9.353-.374z' class='cls-4' data-name='Path 717' transform='translate(-366.9 -365.725)'/%3E%3C/g%3E%3Cg id='Group_350' data-name='Group 350' transform='translate(15.568 57.103)'%3E%3Cpath id='Path_718' d='M386.52 358.952c0 .561-3.928 1.5-9.166 2.245-5.051.748-9.353.935-9.353.374s3.928-1.5 9.166-2.245c5.05-.748 9.353-.935 9.353-.374z' class='cls-4' data-name='Path 718' transform='translate(-368 -358.626)'/%3E%3C/g%3E%3Cg id='Group_351' data-name='Group 351' transform='translate(18 42.512)'%3E%3Cpath id='Path_719' d='M387.82 351.152c0 .561-3.928 1.5-9.166 2.245-5.051.748-9.353.935-9.353.374s3.928-1.5 9.166-2.245c5.05-.748 9.353-.935 9.353-.374z' class='cls-4' data-name='Path 719' transform='translate(-369.3 -350.826)'/%3E%3C/g%3E%3Cg id='Group_352' data-name='Group 352' transform='translate(21.18 26.237)'%3E%3Cpath id='Path_720' d='M389.52 342.452c0 .561-3.928 1.5-9.166 2.245-5.051.748-9.353.935-9.353.374s3.928-1.5 9.166-2.245c5.05-.748 9.166-.935 9.353-.374z' class='cls-4' data-name='Path 720' transform='translate(-371 -342.126)'/%3E%3C/g%3E%3C/g%3E%3C/g%3E%3Cg id='Group_365' data-name='Group 365' transform='translate(98.969 482.361)'%3E%3Cpath id='Path_721' d='M54.571 332.948s-2.993 8.792-.935 15.152 4.115 4.116 4.115 4.116a10.213 10.213 0 0 1-1.122-5.986c.374-3.554 1.122-4.677 1.122-4.677l1.684 7.483a38.016 38.016 0 0 0 1.122-3.741c.561-2.245-1.122-6.36-.748-8.605.374-2.058 1.122-4.49 1.122-4.49z' class='cls-16' data-name='Path 721' transform='translate(-52.914 -193.209)'/%3E%3Cpath id='Path_722' d='M119.947 278.323l.561-3.367s-3.367-7.483-2.432-8.979a37.31 37.31 0 0 1 4.49-4.677l2.058.374s3.741 4.864 4.115 6.547-1.871 7.483-3.367 11.972z' class='cls-16' data-name='Path 722' transform='translate(3.678 -254.94)'/%3E%3Cpath id='Path_723' fill='%237fbbef' d='M119.5 260.706l1.871 15.34 2.058-.374-2.058-15.152-1.122-2.619z' data-name='Path 723' transform='translate(5.06 -257.9)'/%3E%3Cpath id='Path_724' d='M119.2 263.358l2.245-2.058s1.122 2.245-1.309 4.677z' class='cls-16' data-name='Path 724' transform='translate(4.799 -254.94)'/%3E%3Cg id='Group_355' data-name='Group 355' transform='translate(68.628 263.203)'%3E%3Cpath id='Path_725' d='M93.628 398.6l.187 5.612-3.928.561-.187-6.173z' class='cls-16' data-name='Path 725' transform='translate(-89.513 -398.6)'/%3E%3Cpath id='Path_726' d='M89.974 402.672s16.836-2.993 19.268-.935-19.642 3.928-19.642 3.928z' class='cls-15' data-name='Path 726' transform='translate(-89.6 -396.498)'/%3E%3C/g%3E%3Cg id='Group_356' data-name='Group 356' transform='translate(4.089 240.007)'%3E%3Cpath id='Path_727' d='M63.8 389.567l-4.677 3.18-2.619-3.18 5.238-3.367z' class='cls-16' data-name='Path 727' transform='translate(-53.881 -386.2)'/%3E%3Cpath id='Path_728' d='M57.719 388s11.224 12.721 10.85 16.088c-.561 3.18-13.469-14.778-13.469-14.778z' class='cls-15' data-name='Path 728' transform='translate(-55.1 -384.633)'/%3E%3C/g%3E%3Cpath id='Path_729' d='M128.834 323.9s14.03 12.908 14.4 61.171c.187 48.263-16.649 80.252-16.649 80.252H114.8s19.455-60.61-2.432-100.642c0 0-7.3 46.767-46.018 82.5L57 437.263s28.621-35.917 28.808-80.626c0-8.792 1.5-13.469-1.5-23.383z' class='cls-6' data-name='Path 729' transform='translate(-49.356 -200.436)'/%3E%3Cpath id='Path_730' d='M123.924 317.015s36.852-9.915 46.205-35.73l5.238-11.785 7.109 2.432s-1.871 47.328-47.515 60.236l-.748 2.806a78.27 78.27 0 0 0-.374 37.787l4.677 9.54-49.2 11.037s-6.173-24.132-.374-49.573c0 0-10.663-2.432-28.621 47.889l-6.921-1.31s9.915-67.531 45.644-76.884z' class='cls-13' data-name='Path 730' transform='translate(-52.491 -247.8)'/%3E%3Cg id='Group_357' data-name='Group 357' transform='translate(5.355 36.478)'%3E%3Cpath id='Path_731' d='M98.988 280.1l2.806 12.908a5.486 5.486 0 0 1-4.115 6.36l-1.684.374-.561 8.979-12.534-.935 1.871-25.441z' class='cls-16' data-name='Path 731' transform='translate(-32.161 -275.049)'/%3E%3Cpath id='Path_732' d='M88.1 302.612s5.051-2.245 5.238-5.986c0 0-6.547-4.115-4.3-5.8s5.8 2.432 5.8 2.432-1.871-5.8-1.122-7.3c0 0 9.166.561 8.044-4.864 0 0-2.432-2.432-8.231-3.18s-9.727 8.792-9.727 8.792z' class='cls-18' data-name='Path 732' transform='translate(-31.377 -276.984)'/%3E%3Cpath id='Path_733' d='M97.318 278.9a7.519 7.519 0 0 0-4.864-1.5 14.844 14.844 0 0 0-11.411 5.425 14.673 14.673 0 0 0-2.993 12.346 8.819 8.819 0 0 0 1.122 2.806c1.5 2.245 4.115 3.18 6.547 3.928 2.245.748 5.986 2.058 7.857.748 0 0-2.806-8.979-1.122-14.4a34.4 34.4 0 0 1 4.864-9.353z' class='cls-18' data-name='Path 733' transform='translate(-36.665 -277.4)'/%3E%3Cpath id='Path_734' d='M98.285 284.033c-3.367-2.619-8.979-1.871-11.411 1.5-1.684 2.245-2.058 5.425-4.3 7.109-2.619 2.058-6.36 1.122-9.54.748-5.8-.374-11.972 2.058-15.152 6.922s-2.806 11.972 1.5 15.9a13.75 13.75 0 0 0 10.663 3.18c3.741-.187 7.483-1.684 11.037-2.993 5.051-2.058 10.476-5.238 12.159-10.476 1.122-3.554.187-7.67.748-11.411.187-1.122.561-2.432 1.5-2.806.748-.374 1.871 0 2.619 0 2.245-.187 3.554-2.806 2.806-4.864a6.929 6.929 0 0 0-4.864-3.928' class='cls-18' data-name='Path 734' transform='translate(-55.777 -272.996)'/%3E%3C/g%3E%3Cpath id='Path_735' d='M88.243 293.5a45.985 45.985 0 0 0-8.979 6.921c-2.619 2.806-4.677 6.173-4.864 10.1 0 .935 0 2.058.748 2.619a4.689 4.689 0 0 0 1.309.748c3.928 1.122 7.857-1.309 11.224-3.554 5.612-3.741 11.411-7.483 15.714-12.72a1.24 1.24 0 0 0 .374-1.31 2.582 2.582 0 0 0-.748-.561c-3.741-1.309-10.663-1.122-14.778-2.245' class='cls-6' data-name='Path 735' transform='translate(-34.207 -226.904)'/%3E%3Cg id='Group_358' data-name='Group 358' transform='translate(36.996 66.409)'%3E%3Cpath id='Path_736' d='M105.632 298.264a2.314 2.314 0 0 0-.374.561 6.13 6.13 0 0 1-1.122 1.5c-.187.374-.561.748-.748 1.122a8.134 8.134 0 0 0-1.122 1.31c-.374.374-.748.935-1.309 1.5a11.286 11.286 0 0 1-1.5 1.5 39.479 39.479 0 0 1-8.231 6.547 25.791 25.791 0 0 1-5.612 2.619 19.434 19.434 0 0 1-6.547 1.309H75.7a3.018 3.018 0 0 1-1.684-.561 2.515 2.515 0 0 1-1.122-1.31 5.214 5.214 0 0 1 .187-3.367c.374-.935.561-2.058.935-2.806A17.158 17.158 0 0 1 77.2 303.5c1.122-1.31 2.245-2.432 3.367-3.554a95.22 95.22 0 0 1 5.238-4.864c.561-.561 1.122-.935 1.5-1.31a2.314 2.314 0 0 0 .561-.374 2.317 2.317 0 0 0-.374.561l-1.309 1.31c-1.122 1.122-2.993 2.806-5.051 4.864-1.122 1.122-2.058 2.245-3.18 3.554a16.733 16.733 0 0 0-2.993 4.677c-.374.935-.561 1.871-.935 2.806a3.715 3.715 0 0 0-.187 2.806 2.773 2.773 0 0 0 2.245 1.5 10.171 10.171 0 0 0 3.367 0 34.847 34.847 0 0 0 6.36-1.31 36.551 36.551 0 0 0 5.425-2.619 43.067 43.067 0 0 0 8.044-6.36l1.5-1.5c.374-.561.935-.935 1.309-1.5.374-.374.748-.935 1.122-1.31s.561-.748.935-1.122a6.132 6.132 0 0 0 1.122-1.5c.179.196.179.009.366.009z' class='cls-23' data-name='Path 736' transform='translate(-72.691 -293.4)'/%3E%3C/g%3E%3Cg id='Group_359' data-name='Group 359' transform='translate(42.139 74.453)'%3E%3Cpath id='Path_737' d='M103.238 298.074s-.561.374-1.684 1.309a23.894 23.894 0 0 0-3.554 4.3 63.813 63.813 0 0 0-3.18 7.67c-.561 1.5-1.122 2.993-1.871 4.677a17.92 17.92 0 0 1-3.18 4.49 12.916 12.916 0 0 1-5.051 2.993 13.781 13.781 0 0 1-2.619.748 3.738 3.738 0 0 1-2.806-.374 2.7 2.7 0 0 1-1.684-2.058 5.525 5.525 0 0 1-.374-2.432 19.676 19.676 0 0 1 1.122-3.928l.374.187a1.707 1.707 0 0 1-1.5.561 1.894 1.894 0 0 1-1.309-.748 2.183 2.183 0 0 1-.374-2.058 3.046 3.046 0 0 1 .561-1.122l.374-.374a8.92 8.92 0 0 0-.748 1.5 2.3 2.3 0 0 0 .374 1.871 3.046 3.046 0 0 0 1.122.561c.374 0 .935 0 1.122-.374l.935-1.122-.561 1.31a21.865 21.865 0 0 0-1.117 3.739 3.7 3.7 0 0 0 .374 2.058 3.3 3.3 0 0 0 1.5 1.684 3.555 3.555 0 0 0 2.432.187 19.2 19.2 0 0 0 2.619-.748 12.3 12.3 0 0 0 4.864-2.993 16.233 16.233 0 0 0 2.993-4.3c.748-1.5 1.309-2.993 2.058-4.49a52.12 52.12 0 0 1 3.367-7.857 14.909 14.909 0 0 1 3.741-4.3c.187-.187.561-.374.748-.561s.374-.187.561-.374c.184.368.371.368.371.368z' class='cls-23' data-name='Path 737' transform='translate(-75.44 -297.7)'/%3E%3C/g%3E%3Cpath id='Path_738' d='M79.652 323.519s-3.741 11.224 5.425 5.051c9.353-6.36 10.663-29.369 10.663-29.369s-6.361 23.008-16.088 24.318z' class='cls-3' data-name='Path 738' transform='translate(-30.292 -221.941)'/%3E%3Cg id='Group_360' data-name='Group 360' transform='translate(74.427 209.355)'%3E%3Cpath id='Path_739' d='M103.55 370.162c0 .187-2.432.187-5.425.561s-5.238.935-5.425.748c0-.187 2.245-1.122 5.238-1.5 3.18-.371 5.612.003 5.612.191z' class='cls-24' data-name='Path 739' transform='translate(-92.7 -369.814)'/%3E%3C/g%3E%3Cg id='Group_361' data-name='Group 361' transform='translate(74.801 205.757)'%3E%3Cpath id='Path_740' d='M104.872 367.907a8.461 8.461 0 0 1-1.5 1.122 11.7 11.7 0 0 1-4.3 1.309 16.881 16.881 0 0 1-4.49-.187c-1.122-.374-1.684-.561-1.684-.748s2.806.748 6.173.187a25.112 25.112 0 0 0 5.801-1.683z' class='cls-24' data-name='Path 740' transform='translate(-92.9 -367.891)'/%3E%3C/g%3E%3Cg id='Group_362' data-name='Group 362' transform='translate(37.157 193.614)'%3E%3Cpath id='Path_741' d='M78.432 368.7c0 .187-2.058-.748-3.741-2.993-1.684-2.058-2.058-4.3-1.871-4.3s.935 1.871 2.432 3.928c1.497 1.865 3.18 3.174 3.18 3.365z' class='cls-24' data-name='Path 741' transform='translate(-72.777 -361.4)'/%3E%3C/g%3E%3Cg id='Group_363' data-name='Group 363' transform='translate(35.33 197.881)'%3E%3Cpath id='Path_742' d='M78.16 367.832c-.187 0-.187-.374-.748-.748a11.871 11.871 0 0 0-2.245-1.31 24.708 24.708 0 0 1-3.367-2.058c0-.187 1.684.374 3.554 1.5A11.662 11.662 0 0 1 77.6 366.9c.747.371.747.932.56.932z' class='cls-24' data-name='Path 742' transform='translate(-71.8 -363.681)'/%3E%3C/g%3E%3Cg id='Group_364' data-name='Group 364' transform='translate(54.785 159.381)'%3E%3Cpath id='Path_743' d='M101.094 351.518a7.292 7.292 0 0 1-2.993-.374c-1.871-.561-4.115-1.871-6.734-2.993-2.619-1.309-4.864-2.432-6.547-3.367s-2.619-1.5-2.619-1.684c0 0 1.122.374 2.806 1.122s4.115 1.871 6.547 3.18a65.866 65.866 0 0 0 6.547 3.18c1.87.749 2.993.749 2.993.936z' class='cls-24' data-name='Path 743' transform='translate(-82.2 -343.1)'/%3E%3C/g%3E%3C/g%3E%3Cg id='Group_366' class='cls-14' data-name='Group 366' transform='translate(372.423 271.011)'%3E%3Cpath id='Path_744' d='M201.911 147.315c-2.619 2.058-3.367 6.173-2.432 9.353.935 3.367 2.993 6.173 5.051 8.792 5.238 6.734 10.85 13.469 16.836 19.829 2.806 3.18 5.8 6.173 8.044 9.727 9.166 14.217 6.173 32.924 7.857 49.76.374 3.741 2.245 8.605 5.986 8.418a6.691 6.691 0 0 0 3.928-1.684 30.661 30.661 0 0 0 12.908-24.319c0-2.806-.187-5.612.561-8.231 1.309-3.741 4.49-6.173 7.109-8.979 5.425-5.986 7.857-13.843 10.289-21.513 2.619-8.792 5.238-18.52 1.122-26.751-2.993-5.8-8.979-9.353-14.965-11.785-19.642-7.857-41.529-4.864-62.48-1.871' class='cls-4' data-name='Path 744' transform='translate(-199.094 -144.919)'/%3E%3C/g%3E%3Cg id='Group_377' data-name='Group 377' transform='translate(354.19 184.359)'%3E%3Cg id='Group_367' data-name='Group 367' transform='translate(68.753 190.064)'%3E%3Cpath id='Path_745' d='M230.315 200.2l.187 5.612-4.115.561-.187-6.173z' class='cls-16' data-name='Path 745' transform='translate(-226.013 -200.2)'/%3E%3Cpath id='Path_746' d='M226.474 204.271s16.836-2.993 19.268-.935-19.642 3.928-19.642 3.928z' class='cls-15' data-name='Path 746' transform='translate(-226.1 -198.098)'/%3E%3C/g%3E%3Cg id='Group_368' data-name='Group 368' transform='translate(76.796 157.327)'%3E%3Cpath id='Path_747' d='M237.947 184.758l-2.806 4.864-3.741-1.684 3.18-5.238z' class='cls-16' data-name='Path 747' transform='translate(-229.529 -182.7)'/%3E%3Cpath id='Path_748' d='M232.271 185.5s15.714 6.547 16.649 9.727-18.52-7.483-18.52-7.483z' class='cls-15' data-name='Path 748' transform='translate(-230.4 -180.262)'/%3E%3C/g%3E%3Cpath id='Path_749' d='M267.266 122.359c6.547-4.115-1.871-7.67 5.986-7.109 1.684 0 3.741.187 5.051-.748 1.871-1.309 2.245-3.928 1.684-6.173A12.578 12.578 0 0 0 268.2 98.6c-7.483-.187-13.843 6.173-21.326 5.8-2.806-.187-5.425-1.309-8.231-2.058-7.857-2.432-18.145-1.122-22.074 6.173-1.122 1.871-1.5 4.115-2.806 5.986-3.367 5.425-10.476 6.36-15.714 9.727a19.525 19.525 0 0 0-8.605 17.958c.374 2.806 1.309 5.986 3.741 7.67 0 0 8.044 10.289 26.189 0s47.892-27.497 47.892-27.497z' class='cls-13' data-name='Path 749' transform='translate(-189.347 -98.598)'/%3E%3Cpath id='Path_750' d='M222.9 126.911c2.806-3.18 46.018 44.148 55.372 49.2 9.166 5.051 7.108 0 7.108 0l-18.52-20.577-35.542-40.034z' class='cls-6' data-name='Path 750' transform='translate(-160.134 -83.882)'/%3E%3Cpath id='Path_751' d='M247.859 113.15a22.675 22.675 0 0 0-23.945 2.619l-.187.187c-11.972 9.54-26.938 28.247-22.448 60.236l42.09-5.051s-5.986-7.109 1.684-28.247c4.116-11.6 7.857-22.448 7.857-22.448z' class='cls-12' data-name='Path 751' transform='translate(-179.668 -87.892)'/%3E%3Cpath id='Path_752' d='M213.875 126.491s3.554 37.788 17.771 42.838 39.845 5.051 39.845 5.051 2.058-2.619-25.254-9.166c-1.122-.187-2.245-.561-3.554-.748 0 0-15.527-8.979-14.591-36.291a25.07 25.07 0 0 0-.187-3.741c-.561-3.928-2.619-12.159-8.231-11.411-7.482.935-5.799 13.468-5.799 13.468z' class='cls-6' data-name='Path 752' transform='translate(-168.132 -86.081)'/%3E%3Cpath id='Path_753' d='M200.9 147.99s31.988 38.536 38.536 49.947c6.36 11.411 3.554 52 5.612 53.127s10.289 0 10.289 0l.561-30.679.374-16.088a58.954 58.954 0 0 0-3.928-22.635l-8.605-22.822s35.356 2.245 29.182 20.016c-7.857 22.261-14.965 39.284-14.965 39.284l7.109 2.806s33.485-42.09 25.628-60.61-47.7-17.023-47.7-17.023z' class='cls-17' data-name='Path 753' transform='translate(-179.288 -59.691)'/%3E%3Cg id='Group_369' data-name='Group 369' transform='translate(63.596 6.689)'%3E%3Cpath id='Path_754' d='M250.574 109.909l-5.612 11.972a5.32 5.32 0 0 1-7.109 2.432l-1.5-.748-2.619 2.993a5.032 5.032 0 0 1-7.109.374l-1.309-1.122a5.893 5.893 0 0 1-.561-8.231l13.098-14.779z' class='cls-16' data-name='Path 754' transform='translate(-223.344 -101.628)'/%3E%3Cpath id='Path_755' d='M226.9 120.743s5.238 1.309 7.67-1.5c0 0-2.806-7.109 0-7.3 2.806 0 2.993 5.425 2.993 5.425s2.058-5.8 3.554-6.36c0 0 6.921 6.173 9.353 1.122 0 0-.374-3.367-4.49-7.483s-12.346-1.871-12.346-1.871z' class='cls-13' data-name='Path 755' transform='translate(-220.247 -102.173)'/%3E%3C/g%3E%3Cg id='Group_370' data-name='Group 370' transform='translate(63.328 23.574)'%3E%3Cpath id='Path_756' d='M232.927 119.992s0 .187-.374.561a3.525 3.525 0 0 1-1.684.748 13.926 13.926 0 0 1-2.806 0 3.017 3.017 0 0 1-1.684-.561 4.371 4.371 0 0 1-1.309-1.309 9.979 9.979 0 0 1-1.871-5.8c0-1.5.374-2.432.561-2.432s0 .935 0 2.432a9.947 9.947 0 0 0 1.871 5.425l1.122 1.122a3.468 3.468 0 0 0 1.309.374 12.223 12.223 0 0 0 2.619 0 3.735 3.735 0 0 0 1.684-.374.82.82 0 0 0 .562-.186z' class='cls-6' data-name='Path 756' transform='translate(-223.2 -111.2)'/%3E%3C/g%3E%3Cg id='Group_371' data-name='Group 371' transform='translate(34.332 36.482)'%3E%3Cpath id='Path_757' d='M224.536 118.1a19.436 19.436 0 0 1-1.122 1.871c-.748 1.309-1.684 2.993-2.993 5.051a122.028 122.028 0 0 0-8.605 17.21 56.448 56.448 0 0 0-2.806 10.289 50.17 50.17 0 0 0-.748 8.605 42.643 42.643 0 0 0 .374 5.8c.187 1.309.374 2.058.374 2.058a1.448 1.448 0 0 0-.187-.561 5.783 5.783 0 0 0-.374-1.5 34.011 34.011 0 0 1-.748-5.8 51.436 51.436 0 0 1 .561-8.792 60.83 60.83 0 0 1 2.806-10.289 102.151 102.151 0 0 1 8.979-17.21c1.31-2.058 2.432-3.741 3.18-4.864.748-1.307 1.122-1.868 1.309-1.868z' class='cls-6' data-name='Path 757' transform='translate(-207.7 -118.1)'/%3E%3C/g%3E%3Cpath id='Path_758' d='M222.4 117.814a17.758 17.758 0 0 0 8.418 2.993c4.49.187 7.3-18.707 7.3-18.707z' class='cls-13' data-name='Path 758' transform='translate(-160.569 -95.549)'/%3E%3Cg id='Group_372' data-name='Group 372' transform='translate(38.448 89.796)'%3E%3Cpath id='Path_759' d='M215.325 146.6a3.737 3.737 0 0 1 .187 2.058 12.078 12.078 0 0 1-1.122 4.677 11.182 11.182 0 0 1-2.806 3.928 10.61 10.61 0 0 1-1.684 1.122s.561-.561 1.309-1.5a17.952 17.952 0 0 0 2.432-3.928 16.768 16.768 0 0 0 1.309-4.49c.188-1.119.188-1.867.375-1.867z' class='cls-25' data-name='Path 759' transform='translate(-209.9 -146.6)'/%3E%3C/g%3E%3Cg id='Group_373' data-name='Group 373' transform='translate(44.434 104.761)'%3E%3Cpath id='Path_760' d='M213.1 154.6a5.534 5.534 0 0 1 .561.748c.374.561.935 1.122 1.684 2.058q2.245 2.806 6.173 7.857a91.529 91.529 0 0 1 7.857 12.533 51.848 51.848 0 0 1 3.367 8.044 72.853 72.853 0 0 1 2.245 9.166 240.689 240.689 0 0 1 2.806 32.924c0 4.3 0 7.67-.187 10.1 0 1.122-.187 2.058-.187 2.806 0 .561 0 .935-.187.935v-3.741c0-2.432 0-5.8-.187-9.915a242.61 242.61 0 0 0-2.993-32.737 72.536 72.536 0 0 0-2.058-9.166 51.852 51.852 0 0 0-3.367-8.044 81.626 81.626 0 0 0-7.67-12.533c-2.432-3.367-4.49-6.173-5.986-8.044q-1.122-1.4-1.684-2.245c0-.372-.187-.559-.187-.746z' class='cls-25' data-name='Path 760' transform='translate(-213.1 -154.6)'/%3E%3C/g%3E%3Cg id='Group_374' data-name='Group 374' transform='translate(63.018 94.473)'%3E%3Cpath id='Path_761' d='M223.157 149.1c.187 0 .374 1.122.935 2.245.374 1.309.935 2.245.748 2.245-.187.187-.935-.748-1.5-2.058-.37-1.31-.37-2.432-.183-2.432z' class='cls-25' data-name='Path 761' transform='translate(-223.034 -149.1)'/%3E%3C/g%3E%3Cg id='Group_375' data-name='Group 375' transform='translate(56.014 85.278)'%3E%3Cpath id='Path_762' d='M224.733 148.89c-.187.187-1.309-.935-2.806-2.245s-2.806-2.245-2.619-2.432 1.5.561 3.18 1.871c1.497 1.309 2.432 2.616 2.245 2.806z' class='cls-25' data-name='Path 762' transform='translate(-219.29 -144.185)'/%3E%3C/g%3E%3Cg id='Group_376' data-name='Group 376' transform='translate(68.94 94.631)'%3E%3Cpath id='Path_763' d='M226.2 152.02a2.048 2.048 0 0 1 .748-.374 22.108 22.108 0 0 0 2.432-1.122 27.515 27.515 0 0 1 9.914-1.309 30.522 30.522 0 0 1 6.734 1.309 16.646 16.646 0 0 1 6.921 4.115 12.917 12.917 0 0 1 2.432 3.741 17.405 17.405 0 0 1 .935 4.49 37.568 37.568 0 0 1 .187 4.677 43.929 43.929 0 0 1-.187 4.864 36.534 36.534 0 0 1-2.245 9.166c-1.122 2.806-2.432 5.425-3.554 8.044q-3.648 7.576-6.173 13.469c-1.871 3.741-3.18 6.921-4.3 8.979-.561 1.122-1.122 1.871-1.309 2.245a5.53 5.53 0 0 1-.561.748l.374-.748a24.483 24.483 0 0 0 1.309-2.432c1.122-2.058 2.432-5.238 4.115-9.166s3.741-8.418 6.173-13.469c1.122-2.619 2.432-5.238 3.554-8.044a35.11 35.11 0 0 0 2.245-8.979 39.106 39.106 0 0 0 .187-4.677 34.58 34.58 0 0 0-.187-4.49 16.015 16.015 0 0 0-.935-4.3 14.229 14.229 0 0 0-2.245-3.554 17.032 17.032 0 0 0-6.547-3.928 28.577 28.577 0 0 0-6.734-1.309 27.666 27.666 0 0 0-9.727 1.122c-2.434.37-3.556 1.119-3.556.932z' class='cls-25' data-name='Path 763' transform='translate(-226.2 -149.184)'/%3E%3C/g%3E%3C/g%3E%3Cg id='Group_378' class='cls-14' data-name='Group 378' transform='translate(413.776 452.383)'%3E%3Cpath id='Path_764' d='M221.2 244.354a2.9 2.9 0 0 1 1.5-2.058 4.793 4.793 0 0 1 3.928 0c1.871 1.122 2.806 3.554 3.367 5.612.561 2.245.935 4.49 2.245 6.36a2.985 2.985 0 0 0 1.684 1.309c1.309.187 2.245-.748 3.18-1.684 2.432-2.619 5.238-5.238 8.605-6.173s7.67 0 9.54 3.18a14.5 14.5 0 0 1 1.309 5.612c1.122 15.526 2.058 31.053 3.18 46.58.561 7.3.935 14.591-1.122 21.513-1.871 6.173-19.829 24.319-28.434 24.319' class='cls-4' data-name='Path 764' transform='translate(-221.2 -241.875)'/%3E%3C/g%3E%3Cg id='Group_390' data-name='Group 390' transform='translate(349.96 456.458)'%3E%3Cg id='Group_379' data-name='Group 379' transform='translate(6.948 8.131)'%3E%3Cpath id='Path_765' d='M248.791 326.8l-4.115 83.619-11.976 55.746-5.425-1.5 4.677-55.933-9.353-57.43-8.418 53.688-18.52 61.358-4.864.187 8.792-61.171-2.432-74.453z' class='cls-16' data-name='Path 765' transform='translate(-190.8 -180.14)'/%3E%3Cpath id='Path_766' d='M263.428 252.509L258 295.348l-26.563 25.815-23.945.374-8.602 15.153 3.554 13.656a45.748 45.748 0 0 1-2.432 29.931l-5.612 16.835 52.192 5.986c1.684-39.658.935-42.838-5.612-65.473l30.866-39.845V251.2z' class='cls-15' data-name='Path 766' transform='translate(-187.666 -245.962)'/%3E%3Cpath id='Path_767' d='M235.346 253.451c-2.619 1.5-19.268 44.148-19.268 44.148l.935 27.312-15.713 2.805v-31.24l27.312-48.076z' class='cls-15' data-name='Path 767' transform='translate(-181.658 -248.4)'/%3E%3C/g%3E%3Cg id='Group_380' data-name='Group 380' transform='translate(0 53.947)'%3E%3Cpath id='Path_768' d='M218.643 274.5l4.864 12.346a5.39 5.39 0 0 1-2.993 6.921l-1.684.561.748 8.979-12.533 1.122-2.245-25.439z' class='cls-16' data-name='Path 768' transform='translate(-171.663 -271.491)'/%3E%3Cpath id='Path_769' d='M211.547 299.282s4.864-4.115 4.49-7.857c0 0-7.109-2.993-5.238-5.051s5.986 1.5 5.986 1.5-2.806-5.425-2.245-6.922c0 0 9.166-.748 7.3-6.173 0 0-2.806-2.058-8.605-1.871S205 283.194 205 283.194z' class='cls-17' data-name='Path 769' transform='translate(-171.489 -272.89)'/%3E%3Cpath id='Path_770' d='M229.763 273.468a18.073 18.073 0 0 0-15.9 3.554 17.532 17.532 0 0 0-6.173 14.965c.374 3.928 1.871 8.044.374 11.6a12.965 12.965 0 0 1-3.741 4.677c-4.3 3.928-8.979 7.857-12.346 12.721s-5.612 10.85-4.677 16.649a14.285 14.285 0 0 0 2.993 6.921 20.026 20.026 0 0 1 2.619 2.993c2.619 3.928 1.122 9.353 2.806 13.843 2.058 5.612 8.792 8.231 14.778 8.792 8.231.748 17.21-.935 23.383-6.547S242.3 347.921 237.62 341c-2.245-3.367-6.36-6.36-5.986-10.476.187-2.619 2.245-4.49 3.18-6.922a11.58 11.58 0 0 0-3.367-13.843c-1.5-1.122-3.367-1.871-4.677-3.18s-2.245-3.367-1.5-5.051c.561-1.31 2.058-2.058 2.806-3.367.935-1.871-.187-4.3-1.684-5.986s-3.18-3.367-3.367-5.425a7.344 7.344 0 0 1 1.5-4.677c1.5-2.806 2.993-5.8 4.49-8.605' class='cls-17' data-name='Path 770' transform='translate(-187.086 -272.892)'/%3E%3C/g%3E%3Cpath id='Path_771' d='M195.941 329l-3.741 29.182 28.06 4.49 1.309-11.6 1.5 11.411h28.06l-2.993-27.5z' class='cls-6' data-name='Path 771' transform='translate(-182.633 -170.093)'/%3E%3Cpath id='Path_772' d='M191.535 400.1s17.023 0 19.081 2.432c2.058 2.619-20.016.374-20.016.374z' class='cls-15' data-name='Path 772' transform='translate(-184.026 -108.188)'/%3E%3Cpath id='Path_773' d='M209.774 401.571s16.836-2.993 19.268-.935-19.642 3.928-19.642 3.928z' class='cls-15' data-name='Path 773' transform='translate(-167.658 -108.35)'/%3E%3Cg id='Group_381' data-name='Group 381' transform='translate(31.079 177.003)'%3E%3Cpath id='Path_774' d='M222.407 346.019c-.187.187-4.115-1.684-9.353-3.741-5.051-2.058-9.353-3.367-9.353-3.554s1.122.187 2.806.561c1.684.561 4.115 1.31 6.734 2.245a44.147 44.147 0 0 1 6.547 2.993c1.683.935 2.619 1.496 2.619 1.496z' class='cls-24' data-name='Path 774' transform='translate(-203.7 -338.673)'/%3E%3C/g%3E%3Cg id='Group_382' data-name='Group 382' transform='translate(9.38 185.019)'%3E%3Cpath id='Path_775' d='M220.908 347.526c0 .187-1.684-.187-4.115-.748-2.619-.561-6.173-1.122-10.1-1.684s-7.67-.935-10.289-1.31-4.3-.561-4.3-.748 1.684 0 4.3.187 6.36.561 10.289 1.122 7.67 1.309 10.1 1.871c2.619.561 4.115 1.123 4.115 1.31z' class='cls-24' data-name='Path 775' transform='translate(-192.1 -342.959)'/%3E%3C/g%3E%3Cg id='Group_383' data-name='Group 383' transform='translate(39.685 188.09)'%3E%3Cpath id='Path_776' d='M236.36 344.787c0 .187-1.5.187-4.115.374s-6.173.374-9.915.561c-3.928.187-7.483.561-9.915.748s-4.115.187-4.115.187c0-.187 1.5-.374 4.115-.748s6.173-.748 9.915-.935c3.928-.187 7.483-.374 10.1-.374 2.246 0 3.93 0 3.93.187z' class='cls-24' data-name='Path 776' transform='translate(-208.3 -344.6)'/%3E%3C/g%3E%3Cg id='Group_384' data-name='Group 384' transform='translate(56.45 167.325)'%3E%3Cpath id='Path_777' d='M227.434 337.99a7.681 7.681 0 0 1-1.684.748 8.014 8.014 0 0 1-4.49-.561 7.7 7.7 0 0 1-3.367-2.993c-.561-.935-.748-1.684-.561-1.684s.374.561.935 1.5a7.7 7.7 0 0 0 3.18 2.619 8.772 8.772 0 0 0 4.115.748c1.124-.377 1.685-.567 1.872-.377z' class='cls-24' data-name='Path 777' transform='translate(-217.262 -333.5)'/%3E%3C/g%3E%3Cg id='Group_385' data-name='Group 385' transform='translate(62.645 172.75)'%3E%3Cpath id='Path_778' d='M222.867 356.6c-.187 0-.935-4.49-1.5-10.1s-.935-10.1-.748-10.1.935 4.49 1.5 10.1.936 10.1.748 10.1z' class='cls-24' data-name='Path 778' transform='translate(-220.574 -336.4)'/%3E%3C/g%3E%3Cg id='Group_386' data-name='Group 386' transform='translate(16.114 234.995)'%3E%3Cpath id='Path_779' d='M195.7 369.723c0-.187 1.5.187 3.367.748s3.367.935 3.367 1.122-1.684.187-3.554-.374a7.7 7.7 0 0 1-3.18-1.496z' class='cls-26' data-name='Path 779' transform='translate(-195.7 -369.674)'/%3E%3C/g%3E%3Cg id='Group_387' data-name='Group 387' transform='translate(15.927 234.405)'%3E%3Cpath id='Path_780' d='M203.083 369.623c0 .187-1.684.748-3.741.561-2.058 0-3.741-.561-3.741-.748s1.684 0 3.741.187c2.058 0 3.558-.187 3.741 0z' class='cls-26' data-name='Path 780' transform='translate(-195.6 -369.359)'/%3E%3C/g%3E%3Cg id='Group_388' data-name='Group 388' transform='translate(49.599 235.527)'%3E%3Cpath id='Path_781' d='M220.521 370.036a7.041 7.041 0 0 1-3.367.935c-1.871.374-3.554.187-3.554 0s1.5-.561 3.367-.748 3.367-.374 3.554-.187z' class='cls-26' data-name='Path 781' transform='translate(-213.6 -369.959)'/%3E%3C/g%3E%3Cg id='Group_389' data-name='Group 389' transform='translate(50.16 234.041)'%3E%3Cpath id='Path_782' d='M218.39 369.231a6.118 6.118 0 0 1-2.058 1.31c-1.309.561-2.245.935-2.432.748 0-.187.748-.748 2.058-1.31 1.309-.748 2.242-.935 2.432-.748z' class='cls-26' data-name='Path 782' transform='translate(-213.9 -369.164)'/%3E%3C/g%3E%3Cpath id='Path_783' d='M221.225 257.235s7.3-3.928 7.3-4.49c-.374-1.5-4.3.374-4.3.374s5.986-6.173 5.051-7.109c-.561-.561-4.3 2.619-4.3 2.619s2.245-3.741 1.5-4.49-4.115 3.554-4.115 3.554 1.309-2.806.561-3.554c-.561-.561-7.109 10.85-7.109 10.85z' class='cls-16' data-name='Path 783' transform='translate(-162.085 -244.053)'/%3E%3Cpath id='Path_784' d='M233.15 258.343s-3.18-7.67-2.619-8.044c1.122-.935 2.993 2.993 2.993 2.993s-.561-8.605.748-8.792c.748 0 1.5 4.677 1.5 4.677s.561-4.3 1.684-4.49.935 5.425.935 5.425.748-2.993 1.871-2.993c.748 0-1.5 12.908-1.5 12.908z' class='cls-16' data-name='Path 784' transform='translate(-149.318 -243.664)'/%3E%3C/g%3E%3Cg id='Group_424' data-name='Group 424' transform='translate(202.391 601.694)'%3E%3Cg id='Group_415' data-name='Group 415' transform='translate(66.409 2.822)'%3E%3Cpath id='Path_785' fill='%23f4f3ff' d='M143.7 369.967l19.268-46.767s53.314 17.958 52.753 19.081-23.2 47.515-23.2 47.515z' data-name='Path 785' transform='translate(-143.7 -323.2)'/%3E%3Cg id='Group_391' data-name='Group 391' transform='translate(12.346 7.67)'%3E%3Cpath id='Path_786' d='M166.575 327.3a.579.579 0 0 1-.187.374 4.089 4.089 0 0 0-.561.935 36.3 36.3 0 0 0-1.871 3.18c-1.684 2.806-3.741 6.547-6.173 10.85-2.245 4.3-4.115 8.231-5.425 11.224a33.245 33.245 0 0 1-1.5 3.367 3.16 3.16 0 0 0-.374.935.579.579 0 0 0-.187.374.579.579 0 0 1 .187-.374c.187-.187.187-.561.374-.935.374-.748.748-2.058 1.5-3.554 1.309-2.993 3.18-6.922 5.425-11.224s4.49-8.044 6.173-10.85c.935-1.31 1.5-2.432 2.058-3.18.187-.374.374-.561.561-.935-.187-.187 0-.187 0-.187z' class='cls-24' data-name='Path 786' transform='translate(-150.3 -327.3)'/%3E%3C/g%3E%3Cg id='Group_392' data-name='Group 392' transform='translate(23.57 6.547)'%3E%3Cpath id='Path_787' d='M186.979 341.1a.579.579 0 0 1-.374-.187c-.187-.187-.561-.187-.935-.374-.748-.374-1.871-.748-3.367-1.5-2.806-1.122-6.547-2.993-10.85-4.864-4.115-2.058-7.857-3.741-10.663-5.238a62.268 62.268 0 0 0-3.18-1.684c-.374-.187-.561-.374-.935-.374a.579.579 0 0 0-.374-.187.579.579 0 0 1 .374.187c.187.187.561.187.935.374.748.374 1.871.935 3.18 1.5 2.806 1.31 6.547 3.18 10.663 5.051s7.857 3.741 10.663 5.051a54.964 54.964 0 0 1 3.18 1.5c.374.187.561.374.935.374a2.047 2.047 0 0 1 .748.371z' class='cls-24' data-name='Path 787' transform='translate(-156.3 -326.7)'/%3E%3C/g%3E%3Cg id='Group_393' data-name='Group 393' transform='translate(36.478 16.088)'%3E%3Cpath id='Path_788' d='M184.151 331.8a.579.579 0 0 1-.187.374 9.12 9.12 0 0 0-.561 1.31c-.561 1.122-1.309 2.619-2.432 4.49-2.058 3.741-4.864 8.979-7.857 14.778s-5.425 11.224-7.109 15.152c-.935 1.871-1.5 3.554-2.058 4.677a9.119 9.119 0 0 1-.561 1.309l-.187.374a.579.579 0 0 1 .187-.374 6.793 6.793 0 0 1 .561-1.309c.374-1.122 1.122-2.806 1.871-4.677 1.684-3.928 4.115-9.353 7.109-15.152s5.8-11.037 7.857-14.778c1.122-1.871 1.871-3.367 2.432-4.49a11.083 11.083 0 0 1 .748-1.122 1.448 1.448 0 0 0 .187-.562z' class='cls-24' data-name='Path 788' transform='translate(-163.2 -331.8)'/%3E%3C/g%3E%3Cg id='Group_394' data-name='Group 394' transform='translate(26.373 11.037)'%3E%3Cpath id='Path_789' d='M187.545 342.569s-6.734-2.806-14.965-6.547-14.965-6.734-14.778-6.922c0 0 6.734 2.806 14.965 6.547s14.778 6.922 14.778 6.922z' class='cls-24' data-name='Path 789' transform='translate(-157.798 -329.1)'/%3E%3C/g%3E%3Cg id='Group_395' data-name='Group 395' transform='translate(26.173 16.088)'%3E%3Cpath id='Path_790' d='M163.694 334.606s-1.309-.748-2.993-1.5-3.18-1.122-2.993-1.309a12.573 12.573 0 0 1 3.18.935 19.957 19.957 0 0 1 2.806 1.874z' class='cls-24' data-name='Path 790' transform='translate(-157.691 -331.8)'/%3E%3C/g%3E%3Cg id='Group_396' data-name='Group 396' transform='translate(24.88 17.21)'%3E%3Cpath id='Path_791' d='M163.173 335.019s-1.309-.748-2.993-1.5-3.18-.932-3.18-1.119a10.022 10.022 0 0 1 3.367.748 10.274 10.274 0 0 1 2.806 1.871z' class='cls-24' data-name='Path 791' transform='translate(-157 -332.4)'/%3E%3C/g%3E%3Cg id='Group_397' data-name='Group 397' transform='translate(24.677 18.52)'%3E%3Cpath id='Path_792' d='M162.894 336.093s-1.309-.748-2.993-1.5-3.18-1.31-2.993-1.5a21.779 21.779 0 0 1 3.18 1.122 19.96 19.96 0 0 1 2.806 1.878z' class='cls-24' data-name='Path 792' transform='translate(-156.891 -333.1)'/%3E%3C/g%3E%3Cg id='Group_398' data-name='Group 398' transform='translate(35.618 18.811)'%3E%3Cpath id='Path_793' d='M163.974 333.526a.653.653 0 0 1 .374-.187c.187 0 .748-.187 1.122 0a1.4 1.4 0 0 1 1.122 1.31 1.374 1.374 0 0 1-.374 1.122 1.867 1.867 0 0 1-.935.748 2.373 2.373 0 0 1-1.122.187 1.591 1.591 0 0 1-.935-.561 1.54 1.54 0 0 1-.374-1.684c.561-.748.935-.935 1.122-.935.374-.187.561-.187.374-.187.187.187 0 .187-.374.187-.187 0-.374.374-.561.748a1.24 1.24 0 0 0 .374 1.309 1.794 1.794 0 0 0 1.684.374 1.6 1.6 0 0 0 1.122-1.309c0-.561-.561-.935-.935-1.122a1.193 1.193 0 0 0-1.122 0z' class='cls-24' data-name='Path 793' transform='translate(-162.74 -333.256)'/%3E%3C/g%3E%3Cg id='Group_399' data-name='Group 399' transform='translate(40.219 21.513)'%3E%3Cpath id='Path_794' d='M172.121 337.506a25.833 25.833 0 0 1-3.554-1.122 23.761 23.761 0 0 1-3.367-1.684s1.5.561 3.367 1.5a21.346 21.346 0 0 1 3.554 1.306z' class='cls-24' data-name='Path 794' transform='translate(-165.2 -334.7)'/%3E%3C/g%3E%3Cg id='Group_400' data-name='Group 400' transform='translate(39.471 22.448)'%3E%3Cpath id='Path_795' d='M167.98 336.7c0 .187-.748 0-1.684-.374s-1.5-.935-1.5-1.122l1.5.748c.936.37 1.684.557 1.684.748z' class='cls-24' data-name='Path 795' transform='translate(-164.8 -335.2)'/%3E%3C/g%3E%3Cg id='Group_401' data-name='Group 401' transform='translate(31.053 23.009)'%3E%3Cpath id='Path_796' d='M160.3 343.544h.187c.187 0 .374.187.748.187.561.187 1.5.561 2.619.935 2.245.935 5.425 2.058 8.979 3.554h-.187c1.5-2.432 2.993-5.238 4.677-8.044l.187-.187.187.187c-4.677-1.684-8.979-3.367-12.533-4.49h.187c-2.806 4.49-4.49 6.921-5.051 7.857 0 0 .374-.748 1.309-2.245.748-1.31 2.058-3.367 3.554-5.612v-.186h.187c3.554 1.31 7.857 2.806 12.533 4.49h.187l-.187.187-.187.187c-1.684 2.806-3.367 5.612-4.677 8.044v.187h-.187c-3.741-1.5-6.734-2.806-9.166-3.741a18.247 18.247 0 0 1-2.619-1.122c-.187-.187-.561-.187-.748-.374z' class='cls-24' data-name='Path 796' transform='translate(-160.3 -335.5)'/%3E%3C/g%3E%3Cg id='Group_402' data-name='Group 402' transform='translate(26.826 33.402)'%3E%3Cpath id='Path_797' d='M159.274 341.326a.653.653 0 0 1 .374-.187c.187 0 .748-.187 1.122 0a1.4 1.4 0 0 1 1.122 1.31 1.375 1.375 0 0 1-.374 1.122 1.867 1.867 0 0 1-.935.748 2.373 2.373 0 0 1-1.122.187 1.591 1.591 0 0 1-.935-.561 1.54 1.54 0 0 1-.374-1.684c.561-.748.935-1.122 1.122-.935.374-.187.561-.187.374-.187.187 0 0 0-.374.187-.187 0-.374.374-.561.748a1.24 1.24 0 0 0 .374 1.31 1.794 1.794 0 0 0 1.684.374 1.6 1.6 0 0 0 1.122-1.309c0-.561-.561-.935-.935-1.122a1.193 1.193 0 0 0-1.122 0z' class='cls-24' data-name='Path 797' transform='translate(-158.04 -341.056)'/%3E%3C/g%3E%3Cg id='Group_403' data-name='Group 403' transform='translate(31.427 36.104)'%3E%3Cpath id='Path_798' d='M167.421 345.306a25.829 25.829 0 0 1-3.554-1.122 23.756 23.756 0 0 1-3.367-1.684s1.5.561 3.554 1.5a11.285 11.285 0 0 1 3.367 1.306z' class='cls-24' data-name='Path 798' transform='translate(-160.5 -342.5)'/%3E%3C/g%3E%3Cg id='Group_404' data-name='Group 404' transform='translate(30.679 36.852)'%3E%3Cpath id='Path_799' d='M163.28 344.4c0 .187-.748 0-1.684-.374s-1.5-.935-1.5-1.122l1.5.748a7.679 7.679 0 0 1 1.684.748z' class='cls-24' data-name='Path 799' transform='translate(-160.1 -342.9)'/%3E%3C/g%3E%3Cg id='Group_405' data-name='Group 405' transform='translate(22.261 37.413)'%3E%3Cpath id='Path_800' d='M155.6 351.244h.187c.187 0 .374.187.748.187.561.187 1.5.561 2.619.935 2.245.935 5.425 2.058 8.979 3.554h-.187c1.5-2.432 2.993-5.238 4.677-8.044l.187-.187.187.187c-4.677-1.684-8.979-3.367-12.533-4.49h.187a87.936 87.936 0 0 1-5.051 7.857s.374-.748 1.309-2.245c.748-1.31 2.058-3.367 3.554-5.612v-.186h.187c3.554 1.31 7.857 2.806 12.533 4.49h.187l-.187.187-.187.187c-1.684 2.806-3.367 5.612-4.677 8.044v.187h-.187c-3.741-1.5-6.734-2.806-9.166-3.741a18.246 18.246 0 0 1-2.619-1.122c-.187-.187-.561-.187-.748-.374.188.373.001.186.001.186z' class='cls-24' data-name='Path 800' transform='translate(-155.6 -343.2)'/%3E%3C/g%3E%3Cg id='Group_406' data-name='Group 406' transform='translate(42.464 19.455)'%3E%3Cpath id='Path_801' d='M185.107 333.6s-4.115 8.418-9.166 18.52c-5.238 10.289-9.54 18.52-9.54 18.52s4.115-8.418 9.166-18.52c5.233-10.289 9.54-18.52 9.54-18.52z' class='cls-24' data-name='Path 801' transform='translate(-166.4 -333.6)'/%3E%3C/g%3E%3Cg id='Group_407' data-name='Group 407' transform='translate(54.051 23.916)'%3E%3Cpath id='Path_802' d='M182.145 339.381c0 .187-2.245-.561-4.864-1.5s-4.864-1.684-4.677-1.871c0-.187 2.245.561 4.864 1.5s4.677 1.871 4.677 1.871z' class='cls-24' data-name='Path 802' transform='translate(-172.594 -335.985)'/%3E%3C/g%3E%3Cg id='Group_408' data-name='Group 408' transform='translate(57.194 22.448)'%3E%3Cpath id='Path_803' d='M176.567 342.683a14.717 14.717 0 0 1-1.5-3.554c-.561-2.058-.935-3.741-.748-3.928.187 0 .561 1.684 1.122 3.741s1.126 3.558 1.126 3.741z' class='cls-24' data-name='Path 803' transform='translate(-174.274 -335.2)'/%3E%3C/g%3E%3Cg id='Group_409' data-name='Group 409' transform='translate(56.541 32.176)'%3E%3Cpath id='Path_804' d='M174.065 343.767c-.187 0-.187-.748 0-1.684 0-.935.187-1.684.374-1.684s.187.748 0 1.684c0 .936-.187 1.684-.374 1.684z' class='cls-24' data-name='Path 804' transform='translate(-173.925 -340.4)'/%3E%3C/g%3E%3Cg id='Group_410' data-name='Group 410' transform='translate(55.372 33.672)'%3E%3Cpath id='Path_805' d='M177.041 341.387c0 .187-.935 0-1.871.187s-1.871.374-1.871.187a3.355 3.355 0 0 1 1.871-.561 8.489 8.489 0 0 1 1.871.187z' class='cls-24' data-name='Path 805' transform='translate(-173.3 -341.2)'/%3E%3C/g%3E%3Cg id='Group_411' data-name='Group 411' transform='translate(20.56 8.792)'%3E%3Cpath id='Path_806' d='M154.708 327.9s1.309.561 2.993 1.5a12.634 12.634 0 0 1 2.993 1.5 21.787 21.787 0 0 1-3.18-1.122 11.576 11.576 0 0 1-2.806-1.878z' class='cls-24' data-name='Path 806' transform='translate(-154.69 -327.9)'/%3E%3C/g%3E%3Cg id='Group_412' data-name='Group 412' transform='translate(20.577 2.993)'%3E%3Cpath id='Path_807' d='M160.312 324.8s-1.122 2.245-2.619 5.051a36.108 36.108 0 0 1-2.993 4.864s1.122-2.245 2.619-5.051c1.681-2.806 2.993-4.864 2.993-4.864z' class='cls-24' data-name='Path 807' transform='translate(-154.7 -324.8)'/%3E%3C/g%3E%3Cg id='Group_413' data-name='Group 413' transform='translate(21.139 5.425)'%3E%3Cpath id='Path_808' d='M155.374 328.719c-.187 0-.187-.561-.374-1.31V326.1c.187 0 .187.561.374 1.31a2.545 2.545 0 0 1 0 1.309z' class='cls-24' data-name='Path 808' transform='translate(-155 -326.1)'/%3E%3C/g%3E%3Cg id='Group_414' data-name='Group 414' transform='translate(19.829 6.47)'%3E%3Cpath id='Path_809' d='M158.415 326.736c0 .187-.935.374-2.058.561s-2.058.374-2.058.187.935-.374 2.058-.561 2.058-.374 2.058-.187z' class='cls-24' data-name='Path 809' transform='translate(-154.3 -326.659)'/%3E%3C/g%3E%3C/g%3E%3Cpath id='Path_810' d='M172.2 351.827s2.432-8.044 2.806-8.044c1.5 0 .561 4.3.561 4.3s4.864-7.109 5.986-6.36c.561.374-1.684 4.677-1.684 4.677s3.18-2.993 4.115-2.432-2.619 4.677-2.619 4.677 2.432-1.871 3.367-1.31c.561.374-9.166 9.166-9.166 9.166z' class='cls-16' data-name='Path 810' transform='translate(-52.477 -304.297)'/%3E%3Cpath id='Path_811' d='M172.2 351.827s2.432-8.044 2.806-8.044c1.5 0 .561 4.3.561 4.3s4.864-7.109 5.986-6.36c.561.374-1.684 4.677-1.684 4.677s3.18-2.993 4.115-2.432-2.619 4.677-2.619 4.677 2.432-1.871 3.367-1.31c.561.374-9.166 9.166-9.166 9.166z' class='cls-16' data-name='Path 811' transform='translate(-52.477 -304.297)'/%3E%3Cg id='Group_416' data-name='Group 416' transform='translate(64.351 227.115)'%3E%3Cpath id='Path_812' d='M146.815 443.1l.187 5.612-4.115.748-.187-6.173z' class='cls-16' data-name='Path 812' transform='translate(-142.513 -443.1)'/%3E%3Cpath id='Path_813' d='M142.974 447.272s16.836-2.993 19.268-.935-19.642 3.928-19.642 3.928z' class='cls-15' data-name='Path 813' transform='translate(-142.6 -440.911)'/%3E%3C/g%3E%3Cg id='Group_417' data-name='Group 417' transform='translate(0 204.105)'%3E%3Cpath id='Path_814' d='M116.9 434.167l-4.677 3.18-2.619-3.18 5.238-3.367z' class='cls-16' data-name='Path 814' transform='translate(-106.981 -430.8)'/%3E%3Cpath id='Path_815' d='M110.819 432.6s11.224 12.72 10.85 16.088c-.561 3.18-13.469-14.778-13.469-14.778z' class='cls-15' data-name='Path 815' transform='translate(-108.2 -429.233)'/%3E%3C/g%3E%3Cpath id='Path_816' d='M181.834 368.5s14.03 13.095 14.4 61.171c.187 48.263-16.649 80.252-16.649 80.252H167.8s19.455-60.61-2.432-100.642c0 0-7.3 46.767-46.018 82.5l-9.35-9.918s28.621-35.917 28.808-80.626c0-8.792 1.5-13.469-1.5-23.383z' class='cls-15' data-name='Path 816' transform='translate(-106.633 -280.937)'/%3E%3Cg id='Group_418' data-name='Group 418' transform='translate(70.337 173.371)'%3E%3Cpath id='Path_817' d='M156.65 414.8c0 .187-2.432.187-5.425.561s-5.238.935-5.425.748c0-.187 2.245-1.122 5.238-1.5 3.18-.557 5.612.004 5.612.191z' class='cls-28' data-name='Path 817' transform='translate(-145.8 -414.37)'/%3E%3C/g%3E%3Cg id='Group_419' data-name='Group 419' transform='translate(70.711 169.856)'%3E%3Cpath id='Path_818' d='M157.972 412.507a8.459 8.459 0 0 1-1.5 1.122 11.7 11.7 0 0 1-4.3 1.309 16.881 16.881 0 0 1-4.49-.187c-1.122-.374-1.684-.561-1.684-.748s2.806.748 6.173.187c3.182-.373 5.614-1.87 5.801-1.683z' class='cls-28' data-name='Path 818' transform='translate(-146 -412.491)'/%3E%3C/g%3E%3Cg id='Group_420' data-name='Group 420' transform='translate(32.88 157.713)'%3E%3Cpath id='Path_819' d='M131.432 413.3c0 .187-2.058-.748-3.741-2.993-1.684-2.058-2.058-4.3-1.871-4.3s.935 1.871 2.432 3.928c1.684 1.865 3.367 3.174 3.18 3.365z' class='cls-28' data-name='Path 819' transform='translate(-125.777 -406)'/%3E%3C/g%3E%3Cg id='Group_421' data-name='Group 421' transform='translate(31.24 161.793)'%3E%3Cpath id='Path_820' d='M131.26 412.519c-.187 0-.187-.374-.748-.748s-1.309-.935-2.245-1.5a24.719 24.719 0 0 1-3.367-2.058c0-.187 1.684.374 3.554 1.5a11.659 11.659 0 0 1 2.246 1.687 1.738 1.738 0 0 1 .56 1.119z' class='cls-28' data-name='Path 820' transform='translate(-124.9 -408.181)'/%3E%3C/g%3E%3Cg id='Group_422' data-name='Group 422' transform='translate(50.695 123.48)'%3E%3Cpath id='Path_821' d='M154.194 396.118a7.292 7.292 0 0 1-2.993-.374c-1.871-.561-4.115-1.871-6.734-2.993-2.619-1.31-4.864-2.432-6.547-3.367s-2.619-1.5-2.619-1.684c0 0 1.122.374 2.806 1.122s4.115 1.871 6.547 3.18a65.88 65.88 0 0 0 6.547 3.18c1.87.749 2.993.749 2.993.936z' class='cls-28' data-name='Path 821' transform='translate(-135.3 -387.7)'/%3E%3C/g%3E%3Cpath id='Path_822' d='M120.5 348.268l8.231 63.79 51.818.748-7.67-48.076s25.628 24.319 36.852 14.217 12.908-20.016 12.908-20.016l-6.173-4.116s-9.166 17.585-17.585 12.159c-9.54-6.173-30.679-31.614-50.508-28.434-13.282 1.684-25.815-5.612-27.873 9.728z' class='cls-17' data-name='Path 822' transform='translate(-97.491 -307.284)'/%3E%3Cg id='Group_423' data-name='Group 423' transform='translate(6.521)'%3E%3Cpath id='Path_823' d='M143.243 323.3l4.864 12.346a5.39 5.39 0 0 1-2.993 6.922l-1.684.561.748 8.979-12.533 1.122-2.245-25.44z' class='cls-16' data-name='Path 823' transform='translate(-96.263 -320.291)'/%3E%3Cpath id='Path_824' d='M136.147 348.082s4.864-4.116 4.49-7.857c0 0-7.109-2.993-5.238-5.051s5.986 1.5 5.986 1.5-2.806-5.425-2.245-6.921c0 0 9.166-.748 7.3-6.173 0 0-2.806-2.058-8.605-1.871s-8.231 10.289-8.231 10.289z' class='cls-6' data-name='Path 824' transform='translate(-96.089 -321.69)'/%3E%3Cpath id='Path_825' d='M154.363 322.268a18.073 18.073 0 0 0-15.9 3.554 17.532 17.532 0 0 0-6.173 14.965c.374 3.928 1.871 8.044.374 11.6a12.964 12.964 0 0 1-3.741 4.677c-4.3 3.928-8.979 7.857-12.346 12.721s-5.612 10.85-4.677 16.649a14.287 14.287 0 0 0 2.993 6.922 20.019 20.019 0 0 1 2.619 2.993c2.619 3.928 1.122 9.353 2.806 13.843 2.058 5.612 8.792 8.231 14.778 8.792 8.231.748 17.21-.935 23.383-6.547s8.418-15.714 3.741-22.635c-2.245-3.367-6.36-6.36-5.986-10.476.187-2.619 2.245-4.49 3.18-6.922a11.58 11.58 0 0 0-3.367-13.843c-1.5-1.122-3.367-1.871-4.677-3.18s-2.245-3.367-1.5-5.051c.561-1.31 2.058-2.058 2.806-3.367.935-1.871-.187-4.3-1.684-5.986s-3.18-3.367-3.367-5.425a7.345 7.345 0 0 1 1.5-4.677c1.5-2.806 2.993-5.8 4.49-8.6' class='cls-6' data-name='Path 825' transform='translate(-111.686 -321.692)'/%3E%3C/g%3E%3C/g%3E%3Cpath id='Path_826' fill='rgba(255,255,255,.47)' d='M312.732 169.691H489.51s-9.353-48.263-56.12-36.665c0 0-34.607-97.836-68.654 0 0 0-29-48.45-52-48.824-49.577-.562-64.168 85.489-.004 85.489z' data-name='Path 826' transform='translate(234.984 73.224)'/%3E%3Cpath id='Path_827' fill='rgba(255,255,255,.45)' d='M68.819 120.253h166.3s-8.792-45.457-52.753-34.42c0 0-32.55-92.037-64.538 0 0 0-27.312-45.644-49.012-45.831-46.577-.562-60.233 80.251.003 80.251z' data-name='Path 827' transform='translate(24.886 34.741)'/%3E%3Cpath id='Path_828' fill='rgba(255,255,255,.2)' d='M366.927 82.932h95.03s-5.051-26-30.3-19.642c0 0-18.707-52.566-36.852 0 0 0-15.714-26-28.06-26.189-26.568-.374-34.238 45.831.182 45.831z' data-name='Path 828' transform='translate(299.389 32.216)'/%3E%3Cpath id='Path_829' d='M24.2 137.106h50.7s-2.62-13.843-16.089-10.476c0 0-9.915-28.06-19.642 0 0 0-8.418-13.843-14.965-14.03-14.217-.187-18.333 24.506-.004 24.506z' class='cls-32' data-name='Path 829' transform='translate(10.388 97.952)'/%3E%3Cpath id='Path_830' d='M433.7 30.206h50.7s-2.62-13.843-16.089-10.476c0 0-9.915-28.06-19.642 0 0 0-8.418-13.843-14.965-14.03-14.217-.187-18.333 24.506-.004 24.506z' class='cls-32' data-name='Path 830' transform='translate(366.927 4.878)'/%3E%3Cpath id='Path_831' fill='rgba(255,255,255,.17)' d='M106.927 45.934h95.03s-5.051-26-30.3-19.642c0 0-18.707-52.566-36.852 0 0 0-15.714-26-28.06-26.189-26.568-.562-34.238 45.831.182 45.831z' data-name='Path 831' transform='translate(73.016)'/%3E%3Cg id='Group_428' data-name='Group 428' transform='translate(.018 512.43)'%3E%3Cpath id='Path_832' d='M70.7 467.824c-18.333 13.843-48.076 1.31-64.538-13.095a17.5 17.5 0 0 1-5.8-9.54c-3.741-17.958 24.506-22.261 25.254-38.349.374-6.922-4.864-12.908-8.792-18.707-8.983-13.281-11.414-30.117-9.544-46.018s7.857-31.053 14.778-45.457c5.612-11.785 15.9-25.254 28.621-22.261 8.231 1.871 13.469 9.915 15.9 18.145 3.367 11.037 2.806 23.009.561 34.42-.935 5.051-2.245 10.289-.935 15.152 3.554 12.72 21.326 15.527 27.686 26.938 6.547 11.6-1.309 25.815-8.418 37.039-6.173 9.54-9.915 15.527-5.986 23.758a16.564 16.564 0 0 0 4.49 5.612c3.929 3.368 11.223 13.656-13.277 32.363z' class='cls-34' data-name='Path 832' transform='translate(-.018 -273.974)'/%3E%3Cg id='Group_425' data-name='Group 425' transform='translate(49.353 88.718)'%3E%3Cpath id='Path_833' d='M26.774 470.679c-.187 0-.374-33.485-.374-74.64s.187-74.64.374-74.64.374 33.485.374 74.64-.187 74.64-.374 74.64z' class='cls-24' data-name='Path 833' transform='translate(-26.4 -321.4)'/%3E%3C/g%3E%3Cg id='Group_426' data-name='Group 426' transform='translate(17.925 162.236)'%3E%3Cpath id='Path_834' d='M38.969 383.148a8.558 8.558 0 0 1-1.122-.748c-.748-.561-1.871-1.5-3.18-2.432-2.619-2.058-6.173-5.051-10.289-8.044-4.115-3.18-7.67-5.8-10.476-7.857a27.513 27.513 0 0 1-3.18-2.432A11.438 11.438 0 0 1 9.6 360.7a5.177 5.177 0 0 1 1.309.748q1.122.842 3.367 2.245c2.806 1.871 6.547 4.49 10.663 7.67s7.67 5.986 10.1 8.231c1.309 1.122 2.245 2.058 2.993 2.619s1.125.935.937.935z' class='cls-24' data-name='Path 834' transform='translate(-9.6 -360.7)'/%3E%3C/g%3E%3Cg id='Group_427' data-name='Group 427' transform='translate(47.856 106.116)'%3E%3Cpath id='Path_835' d='M47.674 330.7a50.411 50.411 0 0 1-3.18 4.115c-2.058 2.432-4.677 5.8-7.857 9.54-2.993 3.741-5.8 7.109-7.67 9.54a44.193 44.193 0 0 1-3.367 3.928 8.548 8.548 0 0 1 .748-1.122c.561-.748 1.309-1.684 2.245-2.993 1.871-2.619 4.49-5.986 7.483-9.728a123.076 123.076 0 0 1 8.044-9.353 25.259 25.259 0 0 0 2.432-2.806z' class='cls-24' data-name='Path 835' transform='translate(-25.6 -330.7)'/%3E%3C/g%3E%3C/g%3E%3Cg id='Group_435' data-name='Group 435' transform='translate(771.668 506.443)'%3E%3Cg id='Group_431' data-name='Group 431' transform='translate(58.88 82.137)'%3E%3Cpath id='Path_837' fill='%2376cc9b' d='M487.779 434.626c-11.411 8.605-29.744.748-40.032-8.044a9.561 9.561 0 0 1-3.554-5.8c-2.245-11.037 15.153-13.843 15.714-23.758.187-4.3-2.993-7.857-5.425-11.6-5.425-8.231-7.108-18.707-5.8-28.434 1.122-9.915 4.864-19.268 9.166-28.247 3.554-7.3 9.727-15.527 17.771-13.843 5.051 1.122 8.418 6.173 9.915 11.224 2.058 6.922 1.684 14.217.374 21.326-.561 3.18-1.5 6.36-.561 9.353 2.058 7.857 13.095 9.54 17.21 16.649 4.116 7.3-.748 15.9-5.238 23.009-3.741 5.986-6.173 9.728-3.741 14.778a16.761 16.761 0 0 0 2.806 3.554c2.058 1.875 6.548 8.235-8.605 19.833z' data-name='Path 837' transform='translate(-443.993 -314.682)'/%3E%3Cg id='Group_430' data-name='Group 430' transform='translate(27.324 13.878)'%3E%3Cpath id='Path_838' d='M458.974 471.379c-.187 0-.374-33.485-.374-74.64s.187-74.64.374-74.64.374 33.485.374 74.64-.187 74.64-.374 74.64z' class='cls-24' data-name='Path 838' transform='translate(-458.6 -322.1)'/%3E%3C/g%3E%3C/g%3E%3Cpath id='Path_839' d='M483.2 464.624c-18.333 13.843-48.076 1.31-64.538-13.095a17.5 17.5 0 0 1-5.8-9.54c-3.741-17.958 24.506-22.261 25.254-38.349.374-6.921-4.864-12.908-8.792-18.707-8.979-13.282-11.411-30.118-9.54-46.018s7.857-31.053 14.778-45.457c5.612-11.785 15.9-25.254 28.621-22.261 8.231 1.871 13.469 9.915 15.9 18.146 3.367 11.037 2.806 23.009.561 34.42-.935 5.051-2.245 10.289-.935 15.152 3.554 12.721 21.326 15.527 27.686 26.938 6.547 11.6-1.309 25.815-8.605 37.039-6.173 9.54-9.914 15.527-5.986 23.758a16.563 16.563 0 0 0 4.49 5.612c4.112 3.554 11.406 13.838-13.094 32.362z' class='cls-34' data-name='Path 839' transform='translate(-412.518 -270.774)'/%3E%3Cg id='Group_432' data-name='Group 432' transform='translate(49.353 88.718)'%3E%3Cpath id='Path_840' d='M439.274 467.479c-.187 0-.374-33.485-.374-74.64s.187-74.64.374-74.64.374 33.485.374 74.64c0 41.342-.187 74.64-.374 74.64z' class='cls-24' data-name='Path 840' transform='translate(-438.9 -318.2)'/%3E%3C/g%3E%3Cg id='Group_433' data-name='Group 433' transform='translate(20.357 162.423)'%3E%3Cpath id='Path_841' d='M452.77 380.048a8.551 8.551 0 0 1-1.122-.748c-.748-.561-1.871-1.5-3.18-2.432-2.619-2.058-6.173-5.051-10.289-8.044-4.115-3.18-7.67-5.8-10.476-7.857a27.511 27.511 0 0 1-3.18-2.432 11.456 11.456 0 0 1-1.122-.935 5.178 5.178 0 0 1 1.31.748q1.122.842 3.367 2.245c2.806 1.871 6.547 4.49 10.663 7.67s7.67 5.986 10.1 8.231c1.31 1.122 2.245 2.058 2.993 2.619.566.374.936.748.936.935z' class='cls-24' data-name='Path 841' transform='translate(-423.4 -357.6)'/%3E%3C/g%3E%3Cg id='Group_434' data-name='Group 434' transform='translate(47.856 106.303)'%3E%3Cpath id='Path_842' d='M460.174 327.6a50.407 50.407 0 0 1-3.18 4.116c-2.058 2.432-4.677 5.8-7.857 9.54-2.993 3.741-5.8 7.108-7.67 9.54a44.222 44.222 0 0 1-3.367 3.928 8.556 8.556 0 0 1 .748-1.122c.561-.748 1.31-1.684 2.245-2.993 1.871-2.619 4.49-5.986 7.483-9.727a123.043 123.043 0 0 1 8.044-9.353 25.268 25.268 0 0 0 2.432-2.806z' class='cls-24' data-name='Path 842' transform='translate(-438.1 -327.6)'/%3E%3C/g%3E%3C/g%3E%3Cg id='Group_436' data-name='Group 436' transform='translate(75.934 441.206)'%3E%3Ccircle id='Ellipse_25' cx='33.485' cy='33.485' r='33.485' class='cls-37' data-name='Ellipse 25'/%3E%3Cpath id='Path_843' d='M65.9 274.485l16.275 5.051-1.31-16.836z' class='cls-37' data-name='Path 843' transform='translate(-18.572 -212.566)'/%3E%3Ctext id='_' fill='%23f5f1eb' data-name='¡' font-family='Helvetica' font-size='37' transform='rotate(180 19.67 14.307)'%3E%3Ctspan x='0' y='0'%3E¡%3C/tspan%3E%3C/text%3E%3C/g%3E%3Cg id='Group_439' data-name='Group 439' transform='translate(767.146 150.141)'%3E%3Cg id='Group_437' data-name='Group 437' transform='translate(0 3.356)'%3E%3Cpath id='Path_844' d='M410.1 97.252s1.122-.374 3.554-1.122c2.619-.748 6.36-1.871 10.663-3.18 9.166-2.619 22.261-6.36 37.787-10.663l.748-.187.187.748c2.432 9.166 5.238 19.268 8.044 29.744.187-.187-1.122 2.058-.561 1.122h-.374l-.374.187-.935.187-1.871.561a27.351 27.351 0 0 1-3.741.935c-2.432.748-4.864 1.309-7.3 1.871-4.677 1.309-9.353 2.432-13.843 3.741-8.792 2.245-16.836 4.49-23.945 6.36l-.561.187-.187-.561c-2.245-9.166-4.115-16.649-5.612-22.074-.561-2.432-1.122-4.3-1.5-5.986-.187-1.309-.187-2.058-.187-1.871a12.065 12.065 0 0 1 .748 2.245c.561 1.5 1.122 3.554 1.871 5.986 1.5 5.425 3.554 12.721 6.173 21.513l-.748-.374c7.108-1.871 15.152-4.115 23.944-6.547 4.49-1.122 8.979-2.432 13.843-3.741 2.432-.561 4.864-1.309 7.3-1.871a27.347 27.347 0 0 1 3.741-.935l1.871-.561.935-.187.374-.187h.374c.561-.935-.748 1.309-.561 1.122-2.806-10.476-5.612-20.577-8.044-29.744l.935.561c-15.153 4.115-28.247 7.3-37.413 9.727-4.49 1.122-8.231 2.058-10.85 2.806a16.349 16.349 0 0 0-4.485.188z' class='cls-39' data-name='Path 844' transform='translate(-410.1 -82.1)'/%3E%3C/g%3E%3Cg id='Group_438' data-name='Group 438' transform='translate(.18 4.282)'%3E%3Cpath id='Path_845' d='M462.4 82.6c.187.187-2.058 2.993-5.8 7.483s-8.979 10.663-14.965 17.4c-1.871.561-.561.187-.935.187h-.935l-.748-.187-1.5-.561a51.808 51.808 0 0 1-2.993-1.122c-2.058-.748-3.928-1.309-5.8-2.058-3.554-1.309-6.734-2.432-9.727-3.367-5.612-2.058-8.979-3.367-8.792-3.554 0-.187 3.554.748 9.166 2.432 2.993.935 6.36 2.058 9.914 3.18 1.871.561 3.741 1.309 5.8 1.871a18.387 18.387 0 0 0 2.993.935l1.5.561.748.187.374.187h.374c-.374.187.935-.187-.935.187 5.986-6.734 11.411-12.721 15.34-17.21 4.11-4.115 6.729-6.734 6.921-6.551z' class='cls-39' data-name='Path 845' transform='translate(-410.196 -82.595)'/%3E%3C/g%3E%3Cpath id='Path_846' fill='%23f19e36' d='M447.006 84.6a5.808 5.808 0 1 1-7.109-4.115 5.906 5.906 0 0 1 7.109 4.115z' data-name='Path 846' transform='translate(-387.893 -80.306)'/%3E%3C/g%3E%3Cg id='Group_442' data-name='Group 442' transform='translate(51.428 316.432)'%3E%3Cg id='Group_440' data-name='Group 440'%3E%3Cpath id='Path_847' d='M35.918 169.2s1.309.187 3.554.748c2.619.748 6.173 1.5 10.476 2.619 8.979 2.245 21.887 5.612 36.852 9.54l.748.187-.187.748c-2.432 8.979-5.051 18.707-7.67 29 .187-.187-1.871 1.122-1.122.561H78.2l-.374-.187-.935-.187-1.871-.561c-1.122-.374-2.432-.561-3.554-.935-2.432-.561-4.677-1.309-6.921-1.871-4.677-1.309-8.979-2.432-13.282-3.554-8.418-2.432-16.275-4.49-23.2-6.36l-.561-.187.187-.561c2.432-8.792 4.49-15.9 6.173-21.139q1.122-3.367 1.684-5.612a12.931 12.931 0 0 1 .374-2.245 21.166 21.166 0 0 0-.374 2.245c-.374 1.5-.935 3.554-1.5 5.8-1.309 5.238-3.18 12.346-5.238 20.952l-.374-.748a2638.068 2638.068 0 0 0 23.2 6.173c4.3 1.122 8.792 2.432 13.282 3.554 2.245.561 4.677 1.309 6.921 1.871 1.122.374 2.432.561 3.554.935l1.871.561.935.187.374.187h.374c.935-.561-1.309.748-.935.561 2.806-10.289 5.425-20.016 7.857-28.808l.561.935c-14.591-4.115-27.125-7.67-36.1-10.1-4.3-1.309-7.857-2.245-10.476-2.993-2.437-.755-3.747-1.316-3.934-1.316z' class='cls-41' data-name='Path 847' transform='translate(-27.5 -169.2)'/%3E%3C/g%3E%3Cg id='Group_441' data-name='Group 441' transform='translate(8.219 .178)'%3E%3Cpath id='Path_848' d='M82.788 182.773c0 .187-3.18 1.5-8.605 3.554-5.425 1.871-12.721 4.49-21.139 7.3-1.871-.561-.561-.187-.935-.187l-.187-.187-.187-.374-.561-.561-1.122-1.122a27.985 27.985 0 0 1-2.058-2.432l-3.928-4.49c-2.432-2.806-4.49-5.425-6.547-7.67-3.741-4.3-5.8-7.109-5.612-7.3s2.619 2.432 6.547 6.547c2.058 2.245 4.3 4.677 6.734 7.483 1.309 1.5 2.619 2.806 3.928 4.49a27.987 27.987 0 0 1 2.058 2.432l1.122 1.122.561.561.187.374.187.187c-.374-.187.935.187-.935-.187 8.231-2.806 15.714-5.238 21.139-6.921 5.985-1.871 9.353-2.806 9.353-2.619z' class='cls-41' data-name='Path 848' transform='translate(-31.894 -169.295)'/%3E%3C/g%3E%3C/g%3E%3Cg id='Group_454' data-name='Group 454' transform='translate(759.476 330.635)'%3E%3Cg id='Group_443' data-name='Group 443' transform='translate(2.806 3.358)'%3E%3Cpath id='Path_849' d='M498.414 223.694a73.933 73.933 0 0 0-1.684-10.85 40.467 40.467 0 0 0-5.051-11.785 44.29 44.29 0 0 0-11.411-12.533 45 45 0 0 0-18.707-8.231 44.109 44.109 0 0 0-23.383 2.058 40.747 40.747 0 0 0-11.224 5.986 41.6 41.6 0 0 0-9.353 9.353 44.156 44.156 0 0 0 0 52.379 58.242 58.242 0 0 0 4.3 5.238 55.711 55.711 0 0 0 5.051 4.3 40.748 40.748 0 0 0 11.224 5.986 46.068 46.068 0 0 0 23.383 2.058 45 45 0 0 0 18.707-8.231 44.29 44.29 0 0 0 11.411-12.533 46.336 46.336 0 0 0 5.051-11.785 60.324 60.324 0 0 0 1.684-11.411v2.807a13.435 13.435 0 0 1-.374 3.554 25.77 25.77 0 0 1-.935 4.677 41.079 41.079 0 0 1-4.864 12.159 45.394 45.394 0 0 1-11.409 12.91 43.682 43.682 0 0 1-19.081 8.605 46.049 46.049 0 0 1-23.944-1.871 40.8 40.8 0 0 1-11.6-6.173 58.241 58.241 0 0 1-5.238-4.3 60.194 60.194 0 0 1-4.49-5.238 46.53 46.53 0 0 1-8.979-26.938 44.03 44.03 0 0 1 8.979-26.938 60.2 60.2 0 0 1 4.49-5.238 37.635 37.635 0 0 1 5.238-4.3 40.8 40.8 0 0 1 11.6-6.173 46.049 46.049 0 0 1 23.944-1.871 43.682 43.682 0 0 1 19.081 8.605 48.032 48.032 0 0 1 11.411 12.908 41.078 41.078 0 0 1 4.864 12.159 25.769 25.769 0 0 1 .935 4.677 28.819 28.819 0 0 1 .374 3.554v2.432z' class='cls-42' data-name='Path 849' transform='translate(-407.5 -178.587)'/%3E%3C/g%3E%3Cg id='Group_444' data-name='Group 444'%3E%3Cpath id='Path_850' d='M503.088 225.257a2.949 2.949 0 0 0-.187-.748c0-.561-.187-1.309-.187-2.245a35.711 35.711 0 0 0-.374-3.741 19.117 19.117 0 0 0-1.122-5.051 46.993 46.993 0 0 0-5.425-12.721 47.6 47.6 0 0 0-12.159-13.469 45.517 45.517 0 0 0-20.016-8.792 48.408 48.408 0 0 0-25.067 2.058 44.029 44.029 0 0 0-11.972 6.547 60.358 60.358 0 0 0-5.425 4.677 33.856 33.856 0 0 0-4.677 5.612 47.511 47.511 0 0 0-9.166 28.06 49.177 49.177 0 0 0 2.432 14.965 45.68 45.68 0 0 0 6.734 13.095 43.763 43.763 0 0 0 4.677 5.612 64.864 64.864 0 0 0 5.425 4.677 46.96 46.96 0 0 0 11.972 6.547 48.408 48.408 0 0 0 25.067 2.058 46.716 46.716 0 0 0 20.016-8.792 50.237 50.237 0 0 0 12.159-13.469 46.993 46.993 0 0 0 5.425-12.721c.561-1.871.748-3.554 1.122-5.051a14.034 14.034 0 0 0 .374-3.741c0-.935.187-1.684.187-2.245 0-.935 0-1.122.187-1.122v2.993a14.743 14.743 0 0 1-.374 3.741 29.283 29.283 0 0 1-.935 5.051 41.568 41.568 0 0 1-5.238 12.908 46.783 46.783 0 0 1-12.346 13.843 48.333 48.333 0 0 1-46.018 7.109 46.117 46.117 0 0 1-12.346-6.547 43.757 43.757 0 0 1-5.612-4.677 69.72 69.72 0 0 1-4.864-5.612 46 46 0 0 1-6.922-13.469 47.03 47.03 0 0 1-2.433-15.34 48.565 48.565 0 0 1 14.4-34.42 43.759 43.759 0 0 1 5.612-4.677 49.106 49.106 0 0 1 12.346-6.547 50.532 50.532 0 0 1 25.628-2.058 48.672 48.672 0 0 1 20.39 9.166 52.282 52.282 0 0 1 12.346 13.843 41.567 41.567 0 0 1 5.238 12.908 29.283 29.283 0 0 1 .935 5.051 35.712 35.712 0 0 1 .374 3.741v2.245a1.865 1.865 0 0 0-.181.748z' class='cls-42' data-name='Path 850' transform='translate(-406 -176.792)'/%3E%3C/g%3E%3Cg id='Group_445' data-name='Group 445' transform='translate(48.263 3.382)'%3E%3Cpath id='Path_851' d='M432.361 187.953c-.374 0-.561-2.058-.561-4.677s.374-4.677.561-4.677c.374 0 .561 2.058.561 4.677s-.187 4.677-.561 4.677z' class='cls-42' data-name='Path 851' transform='translate(-431.8 -178.6)'/%3E%3C/g%3E%3Cg id='Group_446' data-name='Group 446' transform='translate(17.886 15.711)'%3E%3Cpath id='Path_852' d='M421.62 192.317c-.187.187-1.871-1.122-3.554-3.18s-2.806-3.741-2.432-3.928c.187-.187 1.871 1.122 3.554 3.18 1.496 1.87 2.619 3.741 2.432 3.928z' class='cls-42' data-name='Path 852' transform='translate(-415.561 -185.191)'/%3E%3C/g%3E%3Cg id='Group_447' data-name='Group 447' transform='translate(74.381 72.392)'%3E%3Cpath id='Path_853' d='M451.82 222.617c-.187.187-1.871-1.122-3.554-3.18s-2.806-3.741-2.432-3.928c.187-.187 1.871 1.122 3.554 3.18 1.683 1.87 2.806 3.554 2.432 3.928z' class='cls-42' data-name='Path 853' transform='translate(-445.761 -215.49)'/%3E%3C/g%3E%3Cg id='Group_448' data-name='Group 448' transform='translate(84.367 47.904)'%3E%3Cpath id='Path_854' d='M451.1 202.961c0-.374 2.058-.561 4.677-.561s4.677.374 4.677.561c0 .374-2.058.561-4.677.561s-4.677-.374-4.677-.561z' class='cls-42' data-name='Path 854' transform='translate(-451.1 -202.4)'/%3E%3C/g%3E%3Cg id='Group_449' data-name='Group 449' transform='translate(3.554 47.904)'%3E%3Cpath id='Path_855' d='M407.9 202.961c0-.374 2.058-.561 4.677-.561s4.677.374 4.677.561c0 .374-2.058.561-4.677.561s-4.677-.374-4.677-.561z' class='cls-42' data-name='Path 855' transform='translate(-407.9 -202.4)'/%3E%3C/g%3E%3Cg id='Group_450' data-name='Group 450' transform='translate(48.263 84.008)'%3E%3Cpath id='Path_856' d='M432.361 231.053c-.374 0-.561-2.058-.561-4.677s.374-4.677.561-4.677c.374 0 .561 2.058.561 4.677s-.187 4.677-.561 4.677z' class='cls-42' data-name='Path 856' transform='translate(-431.8 -221.7)'/%3E%3C/g%3E%3Cg id='Group_451' data-name='Group 451' transform='translate(14.386 71.215)'%3E%3Cpath id='Path_857' d='M420.817 214.934c.187.187-1.122 1.871-3.18 3.554s-3.741 2.806-3.928 2.432c-.187-.187 1.122-1.871 3.18-3.554 1.87-1.684 3.741-2.807 3.928-2.432z' class='cls-42' data-name='Path 857' transform='translate(-413.691 -214.861)'/%3E%3C/g%3E%3Cg id='Group_452' data-name='Group 452' transform='translate(74.061 16.218)'%3E%3Cpath id='Path_858' d='M452.717 185.534c.187.187-1.122 1.871-3.18 3.554s-3.741 2.806-3.928 2.432c-.187-.187 1.122-1.871 3.18-3.554 1.87-1.684 3.554-2.807 3.928-2.432z' class='cls-42' data-name='Path 858' transform='translate(-445.59 -185.461)'/%3E%3C/g%3E%3Cg id='Group_453' data-name='Group 453' transform='translate(45.644 23.585)'%3E%3Cpath id='Path_859' d='M451.164 221.575c0 .187-2.058.374-5.8.374-3.554.187-8.605.187-14.4.187h-.564v-6.547c0-7.3 0-13.843.187-18.52s.187-7.67.374-7.67.374 2.993.374 7.67c.187 4.677.187 11.224.187 18.52v5.986l-.561-.561c5.8 0 10.85.187 14.4.187 3.559.187 5.803.374 5.803.374z' class='cls-42' data-name='Path 859' transform='translate(-430.4 -189.4)'/%3E%3C/g%3E%3C/g%3E%3Cg id='Group_455' data-name='Group 455' transform='translate(255.248 195.961)'%3E%3Cpath id='Path_860' d='M145.892 105.361c0 .187-1.122 0-2.993.748a8.834 8.834 0 0 0-5.425 5.8c-.561 1.684-.374 3.741-.374 5.8v7.109a23.85 23.85 0 0 0 .187 3.741 8.885 8.885 0 0 0 8.605 7.3h.561v7.857l-.935-.374c2.806-2.432 5.612-4.864 8.605-7.3l.187-.187h19.268a10.934 10.934 0 0 0 3.554-.374 8.545 8.545 0 0 0 5.238-4.3 8.97 8.97 0 0 0 .935-3.18v-10.48c0-2.245.187-4.49-.561-6.36a9.41 9.41 0 0 0-3.741-4.3 10.9 10.9 0 0 0-5.425-1.122h-5.425c-6.734 0-12.159-.187-16.088-.187a27.756 27.756 0 0 1-4.3-.187h-1.871a8.476 8.476 0 0 0 1.5-.187 37.7 37.7 0 0 0 4.3-.187c3.928 0 9.353-.187 16.088-.187h5.418a10.753 10.753 0 0 1 5.8 1.122 9.562 9.562 0 0 1 4.3 4.677 10.924 10.924 0 0 1 .748 3.367v13.843a8.515 8.515 0 0 1-.935 3.741 10.286 10.286 0 0 1-5.8 5.051 14.006 14.006 0 0 1-3.928.374H154.31l.374-.187c-2.993 2.432-5.8 5.051-8.605 7.3l-.935.748v-1.13c0-2.619 0-5.051.187-7.3l.561.561a8.962 8.962 0 0 1-7.857-4.3 11.316 11.316 0 0 1-1.5-3.928 27.493 27.493 0 0 1 0-3.928v-7.109c0-2.245-.187-4.3.561-5.986a9.777 9.777 0 0 1 5.986-5.986 4.167 4.167 0 0 1 2.81-.373z' class='cls-39' data-name='Path 860' transform='translate(-136.456 -104.8)'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E"
                                alt="">
                        </div>
                    </div>
                    <div class="form-holder">
                        <div class="form-content">
                            <div class="form-items">
                                <h3>{{config.page_login.formTitle}}</h3>
                                <p>{{config.sysTitle}}</p>
                                <Form ref="formCustom" :model="formCustom" class="login-container">
                                    <i-input v-model="formCustom.username" placeholder="请输入登录账号"></i-input>
                                    <i-input v-model="formCustom.password" type="password"
                                             placeholder="请输入密码"></i-input>
                                    <Row type="flex" justify="space-between" v-if="config.page_login.captcha.show">
                                        <i-col span="16">
                                            <i-input type="text" @on-enter="handleSubmit('formCustom')"
                                                     v-model="formCustom.captcha" :maxlength="config.page_login.captcha.codeCount"
                                                     placeholder="请输入验证码"></i-input>
                                        </i-col>
                                        <i-col span="8">
                                            <img :src="captchaUrl" @click="changeCaptchaUrl" width="100%" height="45px"
                                                 style="border-radius: 4px"/>
                                        </i-col>
                                    </Row>
                                    <Button type="primary" @click="handleSubmit('formCustom')" :loading="loading"
                                            size="large">登录
                                    </Button>
                                </Form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import config from '../../config/Config'
import util from 'core-util-is'

export default {
  name:'PageLogin',
  data () {
    return {
      config: {},
      formName: 'formName',
      // 提交按钮loading
      loading: false,
      // 登录form
      formCustom: {
        username: '',
        password: '',
        captcha: ''
      },
      now: new Date().getMilliseconds()
    }
  },
  methods: {
    // 刷新验证码
    changeCaptchaUrl: function () {
      this.now = new Date().getMilliseconds()
    },
    // 确认登录操作
    handleSubmit () {
      if (this.formCustom.username === '') {
        this.$Message.error({
          content: '账号不能为空',
          duration: 3
        });
        return
      }
      if (this.formCustom.password === '') {
        this.$Message.error({
          content: '密码不能为空',
          duration: 3
        });
        return
      }
      if (this.config.page_login.captcha.show && this.formCustom.captcha === '') {
        this.$Message.error({
          content: '验证码不能为空',
          duration: 3
        });
        return
      }
      this.loading = true;
      this.$axios.post(this.config.page_login.loginUrl, this.formCustom).then(response => {
        this.$Message.success('登录成功');
        if (response.body) {
          window.sessionStorage.setItem('ueboot_login_info', JSON.stringify(response.body))
        }
        this.loading = false;
        if (util.isFunction(this.config.page_login.successCallBack)) {
          this.config.page_login.successCallBack(response.body, this)
        } else {
          this.$router.push(this.config.page_login.successRouter)
        }
      }, () => {
        if(this.config.page_login.captcha.show){
          this.changeCaptchaUrl();
          this.formCustom.captcha = ''
        }
        this.loading = false
      })
    }
  },
  computed: {
    captchaUrl: function () {
      let url = '?time=' + this.now;
      if(this.config.page_login.captcha.codeCount>4){
         url+="&codeCount="+this.config.page_login.captcha.codeCount;
      }
      if(this.config.page_login.captcha.width>200){
        url+="&w="+this.config.page_login.captcha.width;
      }
      if(this.config.page_login.captcha.height>80){
        url+="&h="+this.config.page_login.captcha.height;
      }
      return this.config.axios.baseURL + '/ueboot/shiro/public/captcha'+url
    }
  },
  created () {
    this.config = config.getConfig()
  },
  mounted () {
  }
}
</script>
<style lang="less">
    *[v-cloak] {
        display: none;
    }
    .login .ivu-btn-primary {
        color: #fff;
        background-color: #2d8cf0;
        border-color: #2d8cf0;
    }

    .login .ivu-btn-primary:hover {
        color: #fff;
        background-color: rgba(45, 140, 240, 0.2);
        border-color: rgba(45, 140, 240, 0.2);
    }

    .login .ivu-btn {
        font-size: 13px;
    }

    .vm-login {
        width: 900px;
        height: 400px;

        & > div {
            padding: 30px;
        }

        .login-form {
            display: flex;
            flex-direction: column;
            justify-content: center;

            .login-header {
                text-align: center;
                font-size: 16px;
                font-weight: bold;
                margin-bottom: 20px;

                span {
                    color: #2d8cf0;
                }
            }

            .login-form {
                input {
                    margin-bottom: 20px;
                    width: 100%;
                    height: 45px;
                }

                button {
                    height: 45px;
                    width: 100%;
                }
            }

            .login-footer {
                margin-top: 10px;

                span.forget {
                    float: right;
                }

                a {
                    color: #f7f7f7;
                }
            }
        }

        .login-ad {
            height: 450px;
            font-weight: bold;
            font-size: 14px;
            border-radius: 0 4px 4px 0;
            background-size: cover;

            .photo-author {
                position: absolute;
                right: 6px;
                bottom: 45px;
            }
        }
    }

    .login {
        display: flex;
        justify-content: center;
        align-items: center;
        position: absolute;
        height: 100%;
        width: 100%;
    }

    .vm-panel {
        background-color: #f7f7f7;
        text-align: left;
        border-radius: 4px;

        .panel-heading {
            text-align: left;
            width: 100%;
            border-radius: 4px 4px 0 0;
            border-bottom: 1px solid;
            padding: 15px;
            font-weight: bold;
        }

        .panel-body {
            padding: 15px;
            font-size: 14px;
        }
    }

    /* ueboot1 风格的样式 */
    .form-body {
        height: 100%;

        .website-logo {
            position: absolute;
            top: 70px;
            left: 50%;
            margin-left: -50px;
            right: initial;
            bottom: initial;
            display: inline-block;
            z-index: 1;

            .logo {
                display: inline-block;
                background-size: contain;
                background-repeat: no-repeat;

                img {
                    width: 100px;
                }
            }
        }

        h3 {
            color: #000;
            text-align: left;
            font-size: 24px;
            font-weight: 900;
            margin-bottom: 10px;
        }

        p {
            color: #000;
            text-align: left;
            font-size: 18px;
            font-weight: 300;
            line-height: 20px;
            margin-bottom: 30px;
        }

        .img-holder {
            z-index: 0;
            width: 100%;
            overflow: hidden;
            background-color: #152733;

            .bg {
                opacity: 1;
                background-image: none;
                background-size: cover;
                background-position: center;
                z-index: -1;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                position: absolute;
            }

            .info-holder {
                position: relative;
                top: 50%;
                -webkit-transform: translateY(-50%);
                -moz-transform: translateY(-50%);
                -ms-transform: translateY(-50%);
                transform: translateY(-50%);

                img {
                    display: inline-block;
                    max-width: 534px;
                    -webkit-animation: zoom-in-img 50s linear 0s infinite;
                    -moz-animation: zoom-in-img 50s linear 0s infinite;
                    -ms-animation: zoom-in-img 50s linear 0s infinite;
                    animation: zoom-in-img 50s linear 0s infinite;
                    -webkit-transform-origin: center center;
                    -moz-transform-origin: center center;
                    -ms-transform-origin: center center;
                    transform-origin: center center;
                    -webkit-transform: scale(1);
                    -moz-transform: scale(1);
                    -ms-transform: scale(1);
                    transform: scale(1);
                    width: 100%;
                    vertical-align: middle;
                    border-style: none;
                }
            }
        }

        .form-content {
            padding: 125px 60px 60px;
            -webkit-perspective: 800px;
            -moz-perspective: 800px;
            -ms-perspective: 800px;
            perspective: 800px;
            position: relative;
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100%;

            .form-items {
                padding: 35px 30px;
                border-radius: 10px;
                background-color: #fff;
                -webkit-box-shadow: 0 6px 15px rgba(0, 0, 0, 0.16);
                box-shadow: 0 6px 15px rgba(0, 0, 0, 0.16);
                max-width: 400px;
                text-align: left;
                display: inline-block;
                width: 100%;
                -webkit-transition: all 0.4s ease;
                transition: all 0.4s ease;

                form {
                    margin-bottom: 0;
                }

                .other-links {
                    margin-top: 38px;
                    margin-bottom: 30px;
                }

                .page-links {
                    margin-bottom: 0;
                }

                input {
                    width: 100%;
                    padding: 9px 20px;
                    text-align: left;
                    border: 0;
                    outline: 0;
                    border-radius: 6px;
                    font-size: 15px;
                    font-weight: 300;
                    -webkit-transition: all 0.3s ease 0s;
                    transition: all 0.3s ease 0s;
                    margin-bottom: 14px;
                    background-color: rgb(247, 247, 247);
                    color: #8d8d8d;
                    height: 45px;
                }

                input:focus {
                    border: 0;
                    background-color: #eaeaea;
                    color: #000;
                }
            }
        }

        .row {
            position: relative;
            margin-left: 0;
            margin-right: 0;
            height: 100%;
            flex-wrap: wrap;
            display: flex;

            .img-holder {
                display: inline-block;
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                min-height: 700px;
                height: 100%;
                overflow: hidden;
                background-color: #000;
                padding: 60px;
                text-align: center;
            }
        }

        .form-holder {
            margin-left: 0;
            width: 100%;
        }
    }


    .login .ivu-btn-primary {
        color: #fff;
        background-color: #41b883;
        border-color: #41b883;
    }

    .login .ivu-btn-primary:hover {
        color: #fff;
        background-color: #5ed19e;
        border-color: #5ed19e;
    }

    .login .ivu-btn {
        font-size: 13px;
    }

    body {
        margin: 0;
        font: normal 75% Arial, Helvetica, sans-serif;
    }

</style>
