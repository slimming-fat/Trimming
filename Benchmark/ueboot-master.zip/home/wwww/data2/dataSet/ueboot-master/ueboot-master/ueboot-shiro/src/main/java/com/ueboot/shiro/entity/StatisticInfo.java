package com.ueboot.shiro.entity;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
public class StatisticInfo implements Serializable {

    /***
     * 统计字段
     */
    private  Long  num;

}
