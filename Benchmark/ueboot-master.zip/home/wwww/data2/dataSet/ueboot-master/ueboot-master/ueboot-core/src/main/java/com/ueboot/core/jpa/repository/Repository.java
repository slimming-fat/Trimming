package com.ueboot.core.jpa.repository;

import java.io.Serializable;

/**
 *
 * @author xiangli.ma
 * @since 1.0
 */
public interface Repository<T, ID extends Serializable> {

}
