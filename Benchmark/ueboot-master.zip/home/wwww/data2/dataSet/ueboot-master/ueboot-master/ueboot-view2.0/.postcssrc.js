module.exports = {
  plugins: {
    autoprefixer: {}
  }
};