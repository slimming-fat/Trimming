/**
 * Created by qinghai.peng on 2017/7/13.
 */
export default{
    dict: {
        //性别字典key
        sex: "性别",
        knowledgeType: "知识库分类"
    },
    storage: {
        user: "user"
    }

}