package com.example.kafkastreamsmultipleinputtopics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaStreamsMultipleInputTopicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
