SPRING WEB SERVICES

This directory contains a Java client for the Airline Web Service that uses JAX-WS.
The client can be run from the provided ant file, by calling "ant run".
Note that the airline sample has to be running before invoking this target.

Client Sample table of contents
---------------------------------------------------
* src - The source files for the client
* build.xml -  Ant build file with a 'build' and a 'run' target

