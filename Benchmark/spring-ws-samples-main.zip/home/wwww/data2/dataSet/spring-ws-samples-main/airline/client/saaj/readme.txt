SPRING WEB SERVICES

This directory contains two Java clients for the Airline Web Service that use SAAJ: SOAP with Attachments API for Java.
There is a client for the GetFlights operation and a client for the secure GetFrequentFlyerMileage operation. Both
clients can be run from the provided ant file, by calling "ant run".

SAJA Client Sample table of contents
---------------------------------------------------
* src - The source files for the client
* build.xml -  Ant build file with a 'build' and a 'run' target

