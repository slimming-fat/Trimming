package pers.kinson.im.common.utils;

/**
 * @author kinson
 */
public interface MemoryObject {

	/** 
	 * 释放相关引用
	 */
	void release();
}
