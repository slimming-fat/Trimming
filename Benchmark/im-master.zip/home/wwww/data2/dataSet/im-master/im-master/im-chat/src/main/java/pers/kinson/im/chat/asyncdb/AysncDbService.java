package pers.kinson.im.chat.asyncdb;

import org.springframework.stereotype.Component;

/**
 * 异步持久化服务
 * @author kinson
 */
@Component
public class AysncDbService {

}
