package pers.kinson.im.chat.http;

public class HttpResultCode {
	
	public static final byte SUCC = (byte)0;
	
	public static final byte params_error = (byte)1;
	
	public static final byte NOT_WHITE_IP = (byte)2;

}
