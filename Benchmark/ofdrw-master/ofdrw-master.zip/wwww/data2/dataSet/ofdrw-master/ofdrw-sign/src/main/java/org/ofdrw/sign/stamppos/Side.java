package org.ofdrw.sign.stamppos;

/**
 * 骑缝章所在的边
 *
 * @author 权观宇
 * @since 2020-04-18 10:14:25
 */
public enum Side {
    Left,
    Right,
    Top,
    Bottom
}
