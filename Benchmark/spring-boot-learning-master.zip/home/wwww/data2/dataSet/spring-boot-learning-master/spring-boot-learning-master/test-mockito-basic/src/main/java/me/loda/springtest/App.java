package me.loda.springtest;

public class App {
}
