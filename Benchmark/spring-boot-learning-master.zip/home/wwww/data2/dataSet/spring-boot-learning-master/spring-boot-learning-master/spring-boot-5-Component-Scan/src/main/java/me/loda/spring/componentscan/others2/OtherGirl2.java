package me.loda.spring.componentscan.others2;

import org.springframework.stereotype.Component;

@Component
public class OtherGirl2 {
    @Override
    public String toString() {
        return "OtherGirl2.java";
    }
}
