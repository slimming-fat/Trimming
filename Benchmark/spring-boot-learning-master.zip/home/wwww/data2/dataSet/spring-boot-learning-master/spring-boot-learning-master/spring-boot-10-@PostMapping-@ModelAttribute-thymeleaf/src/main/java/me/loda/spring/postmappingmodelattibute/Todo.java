package me.loda.spring.postmappingmodelattibute;

import lombok.Data;

@Data
public class Todo {
    public String title;
    public String detail;
}
