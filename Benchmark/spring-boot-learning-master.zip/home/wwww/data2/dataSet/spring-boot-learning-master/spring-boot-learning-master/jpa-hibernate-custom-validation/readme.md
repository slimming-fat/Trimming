# Source
Vào link để xem chi tiết có hình ảnh minh họa:

[Loda.me - Hướng dẫn Custom Validator][loda-link]

[loda-link]: https://loda.me/spring-boot-huong-dan-tu-tao-validator-de-kiem-tra-model-and-entity-loda1576748879560

# Content without images

### Giới thiệu