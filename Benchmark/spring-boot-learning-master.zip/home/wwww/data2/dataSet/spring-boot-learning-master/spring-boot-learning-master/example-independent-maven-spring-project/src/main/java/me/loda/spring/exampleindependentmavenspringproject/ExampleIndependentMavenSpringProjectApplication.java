package me.loda.spring.exampleindependentmavenspringproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleIndependentMavenSpringProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleIndependentMavenSpringProjectApplication.class, args);
	}

}
