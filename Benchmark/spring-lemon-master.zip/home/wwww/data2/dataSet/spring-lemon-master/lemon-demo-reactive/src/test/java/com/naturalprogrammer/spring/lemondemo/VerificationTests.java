package com.naturalprogrammer.spring.lemondemo;

import com.naturalprogrammer.spring.lemon.commons.security.GreenTokenService;
import com.naturalprogrammer.spring.lemon.commons.util.LecUtils;
import com.naturalprogrammer.spring.lemondemo.dto.TestUserDto;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.test.web.reactive.server.WebTestClient.ResponseSpec;

import static com.naturalprogrammer.spring.lemondemo.MyTestUtils.*;
import static com.naturalprogrammer.spring.lemondemo.controllers.MyController.BASE_URI;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.web.reactive.function.BodyInserters.fromFormData;

class VerificationTests extends AbstractTests {

	private String verificationCode;
	
	@Autowired
	private GreenTokenService greenTokenService;
	
	@BeforeEach
	public void setUp() {
		
		verificationCode = greenTokenService.createToken(GreenTokenService.VERIFY_AUDIENCE,
				UNVERIFIED_USER_ID.toString(), 60000L,
				LecUtils.mapOf("email", UNVERIFIED_USER_EMAIL));
	}
	
	@Test
	void testEmailVerification() {
		
		emailVerification(UNVERIFIED_USER_ID, verificationCode)
		.expectStatus().isOk()
		.expectHeader().exists(LecUtils.TOKEN_RESPONSE_HEADER_NAME)
		.expectBody(TestUserDto.class)
		.consumeWith(result -> {
			
			TestUserDto userDto = result.getResponseBody();
			assert userDto != null;
			
			assertEquals(UNVERIFIED_USER_ID, userDto.getId());
			assertEquals(0, userDto.getRoles().size());
			assertTrue(userDto.isGoodUser());
			assertFalse(userDto.isUnverified());
		});		

		// Already verified
		emailVerification(UNVERIFIED_USER_ID, verificationCode)
		.expectStatus().isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY);
	}
	
	@Test
	void testEmailVerificationNonExistingUser() throws Exception {
		
		emailVerification(ObjectId.get(), verificationCode)
		.expectStatus().isNotFound();
	}

	@Test
	void testEmailVerificationWrongToken() throws Exception {
		
		// null token
		CLIENT.post().uri(BASE_URI + "/users/{id}/verification", UNVERIFIED_USER_ID)
	        .exchange()
	        .expectStatus().isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY);

		// blank token
		emailVerification(UNVERIFIED_USER_ID, "")
		.expectStatus().isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY);

		// Wrong audience
		String token = greenTokenService.createToken("wrong-audience",
				UNVERIFIED_USER_ID.toString(), 60000L,
				LecUtils.mapOf("email", UNVERIFIED_USER_EMAIL));
		emailVerification(UNVERIFIED_USER_ID, token)
		.expectStatus().isUnauthorized();
		
		// Wrong email
		token = greenTokenService.createToken(GreenTokenService.VERIFY_AUDIENCE,
				UNVERIFIED_USER_ID.toString(), 60000L,
				LecUtils.mapOf("email", "wrong.email@example.com"));
		emailVerification(UNVERIFIED_USER_ID, token)
		.expectStatus().isForbidden();

		// expired token
		token = greenTokenService.createToken(GreenTokenService.VERIFY_AUDIENCE,
				UNVERIFIED_USER_ID.toString(), 1L,
				LecUtils.mapOf("email", UNVERIFIED_USER_EMAIL));	
		emailVerification(UNVERIFIED_USER_ID, token)
		.expectStatus().isUnauthorized();
	}

	private ResponseSpec emailVerification(ObjectId userId, String code) {
		
		return CLIENT.post().uri(BASE_URI + "/users/{id}/verification", userId)
	        .body(fromFormData("code", code))
        .exchange();
	}
}
