package com.naturalprogrammer.spring.lemondemo.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class TestEmailForm {

	private String newEmail;
	private String password;
}
