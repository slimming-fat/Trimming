package com.naturalprogrammer.spring.lemondemo.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class TestToken {
	
	private String token;
}
