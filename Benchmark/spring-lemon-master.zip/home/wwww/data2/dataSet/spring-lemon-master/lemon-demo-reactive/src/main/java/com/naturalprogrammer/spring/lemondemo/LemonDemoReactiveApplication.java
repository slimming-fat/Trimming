package com.naturalprogrammer.spring.lemondemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LemonDemoReactiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(LemonDemoReactiveApplication.class, args);
	}	
}
