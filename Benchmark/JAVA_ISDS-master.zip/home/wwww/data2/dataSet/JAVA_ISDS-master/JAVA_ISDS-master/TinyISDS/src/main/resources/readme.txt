Usage:
java -jar TinyISDS.jar environment loginName password directoryWhereToPutFiles

environment can be production or test
