package cz.abclinuxu.datoveschranky.ws;

/**
 * @author xrosecky
 */
public class BasicTest {
    
}
