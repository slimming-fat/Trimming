package com.vladmihalcea.cache;

/**
 * FibonacciService - Fibonacci Service
 *
 * @author Vlad Mihalcea
 */
public interface FibonacciService {

    int compute(int i);
}
