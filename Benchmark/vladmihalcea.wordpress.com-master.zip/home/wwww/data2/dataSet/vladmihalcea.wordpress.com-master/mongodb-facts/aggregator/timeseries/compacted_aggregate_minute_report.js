load(pwd() + "/../../util/date_util.js");
load(pwd() + "/compacted_aggregate_base_report.js");
load(pwd() + "/test_data.js");

testFromDatesAggregation(ONE_MINUTE_MILLIS, ONE_SECOND_MILLIS, 'One minute seconds');