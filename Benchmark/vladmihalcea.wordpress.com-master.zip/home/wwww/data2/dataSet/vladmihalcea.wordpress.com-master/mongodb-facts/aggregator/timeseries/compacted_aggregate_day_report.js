load(pwd() + "/../../util/date_util.js");
load(pwd() + "/compacted_aggregate_base_report.js");
load(pwd() + "/test_data.js");

testFromDatesAggregation(ONE_DAY_MILLIS, ONE_HOUR_MILLIS, 'One year days');