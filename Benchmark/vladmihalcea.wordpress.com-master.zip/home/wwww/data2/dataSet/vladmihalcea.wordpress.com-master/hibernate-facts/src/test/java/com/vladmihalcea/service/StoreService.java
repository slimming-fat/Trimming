package com.vladmihalcea.service;

/**
 * StoreService - StoreService
 *
 * @author Vlad Mihalcea
 */
public interface StoreService {

    void purchase(Long productId);
}
