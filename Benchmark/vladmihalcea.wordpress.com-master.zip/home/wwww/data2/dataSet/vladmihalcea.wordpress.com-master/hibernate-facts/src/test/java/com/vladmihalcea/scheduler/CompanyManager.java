package com.vladmihalcea.scheduler;

/**
 * UserRatingManager -
 *
 * @author Vlad Mihalcea
 */
public interface CompanyManager {
    void updateAllUsers();
}
