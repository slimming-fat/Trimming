package com.vladmihalcea.service;

import java.util.Date;

/**
 * TimeService - TimeService
 *
 * @author Vlad Mihalcea
 */
public interface TimeService {

    String formatTimestamp();
}
