# springboot2_demo
springboot2.x_demo

springboot2.X + jpa

还是比较方便的
