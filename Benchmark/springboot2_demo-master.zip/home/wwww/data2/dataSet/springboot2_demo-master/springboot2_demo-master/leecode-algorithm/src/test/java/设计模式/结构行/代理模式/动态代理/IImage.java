package 设计模式.结构行.代理模式.动态代理;

/**
 * @author albertliu
 * @className IImage
 * @description TODO
 * @date 2020/10/20 20:28
 */
public interface IImage {
    void show();
}
