package 设计模式.结构行.适配器模式.类适配器;

/**
 * @author albertliu
 * @className B
 * @description TODO
 * @date 2020/10/20 20:50
 */
public class B {
    public void hello(){
        System.out.println("我是被适配者。bbbbb");
    }


}
