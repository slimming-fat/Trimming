package 设计模式.结构行.适配器模式.对象适配器;

/**
 * @author albertliu
 * @className AC
 * @description TODO
 * @date 2020/10/20 21:01
 */
public interface AC {
    int outPutAC();
}
