package 设计模式.行为行.责任链模式;

/**
 * @author albertliu
 * @className Log
 * @description TODO
 * @date 2020/10/21 10:06
 */
public interface Log {
    void print(String msg);
}
