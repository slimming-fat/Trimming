package 设计模式.结构行.享元模式;

/**
 * @author albertliu
 * @className Shap
 * @description TODO
 * @date 2020/10/14 10:52
 */
public interface Shape {
    void draw();
}
