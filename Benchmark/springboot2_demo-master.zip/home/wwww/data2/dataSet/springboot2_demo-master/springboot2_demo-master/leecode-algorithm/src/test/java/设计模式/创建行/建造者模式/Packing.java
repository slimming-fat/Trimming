package 设计模式.创建行.建造者模式;

/**
 * @author albertliu
 * @className Packing
 * @description 包装
 * @date 2020/10/20 15:59
 */
public interface Packing {
    String pack();
}
