package 设计模式.行为行.命令模式;

/**
 * @author albertliu
 * @className Command
 * @description 命令
 * @date 2020/10/14 11:33
 */
public interface Command {
    void exe();
}
