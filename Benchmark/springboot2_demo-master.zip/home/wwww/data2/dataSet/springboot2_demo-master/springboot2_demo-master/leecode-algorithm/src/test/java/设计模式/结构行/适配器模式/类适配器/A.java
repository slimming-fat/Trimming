package 设计模式.结构行.适配器模式.类适配器;

/**
 * @author albertliu
 * @className A
 * @description TODO
 * @date 2020/10/20 20:49
 */
public interface A {
    void say();
}
