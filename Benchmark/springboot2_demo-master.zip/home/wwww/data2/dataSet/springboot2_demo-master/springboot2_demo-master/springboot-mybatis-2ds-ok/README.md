# springboot2_demo
springboot2.x_demo

springboot2.X + mybatis + 多数据源 + 事务支持

注意：这里确实支持多数据源了，支持多数据源事务！