# springboot2_demo
springboot2.x_demo

基本测试：属性注入，aop测试，json测试，mock测试等等