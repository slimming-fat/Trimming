package com.example.dubbo.provider;

public interface Demo1Service {
    String sayHello3(String name);
}