package 设计模式.结构行.外观模式;

/**
 * @author albertliu
 * @className Shape
 * @description TODO
 * @date 2020/10/14 10:40
 */
public interface Shape {
    void draw();
}
