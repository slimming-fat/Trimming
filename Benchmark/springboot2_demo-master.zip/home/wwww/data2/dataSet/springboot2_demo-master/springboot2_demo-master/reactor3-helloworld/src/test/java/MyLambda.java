//@FunctionalInterface
//public interface MyLambda {
//    int add(int a, int b);
//}
