package 设计模式.行为行.策略模式.demo2;

/**
 * @author albertliu
 * @className Strategy
 * @description TODO
 * @date 2020/10/20 21:23
 */
public interface Strategy {
    int operation(int a, int b);
}
