hbase
Phoenix
flink




hbase  环境 : https://blog.csdn.net/liubenlong007/article/details/96438392

官方参考: https://github.com/spring-projects/spring-hadoop-samples


https://www.cnblogs.com/orange911/p/9999767.html
https://www.cnblogs.com/mowei/p/7776832.html
https://www.itsvse.com/thread-6428-1-1.html
https://www.zifangsky.cn/1286.html

flink:
https://www.cnblogs.com/smartloli/p/10245105.html
https://flink.sojb.cn/dev/connectors/kafka.html
https://ci.apache.org/projects/flink/flink-docs-release-1.8/dev/connectors/kafka.html
https://www.cnblogs.com/code2one/p/10123112.html

phoenix:
http://phoenix.apache.org/explainplan.html


scala
https://www.cnblogs.com/pickless/p/10569706.html

工具
https://www.cnblogs.com/frankdeng/p/9452982.html