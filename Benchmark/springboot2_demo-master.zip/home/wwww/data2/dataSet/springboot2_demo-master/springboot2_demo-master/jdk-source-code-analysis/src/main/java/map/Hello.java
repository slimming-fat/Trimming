package map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;

public class Hello {
    public static void main(String[] args) throws InterruptedException {
        String a = "atraefbgd";
        String b = "efb";
        System.out.println(a.indexOf(b));
    }




}
