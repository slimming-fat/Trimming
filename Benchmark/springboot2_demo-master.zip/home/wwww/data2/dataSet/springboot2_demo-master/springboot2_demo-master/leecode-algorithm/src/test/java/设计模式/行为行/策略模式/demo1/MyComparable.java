package 设计模式.行为行.策略模式.demo1;
/**
 * @author albertliu
 * @className MyComperable
 * @description TODO
 * @date 2020/10/10 11:32
 */
public interface MyComparable {
    int compareTo(Object o, MyCompartor myCompartor);
}
