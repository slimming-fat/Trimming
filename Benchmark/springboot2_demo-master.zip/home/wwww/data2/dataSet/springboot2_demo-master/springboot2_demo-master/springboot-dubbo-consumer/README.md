# springboot2_demo
springboot2.x_demo

springboot2 + dubbo  消费者