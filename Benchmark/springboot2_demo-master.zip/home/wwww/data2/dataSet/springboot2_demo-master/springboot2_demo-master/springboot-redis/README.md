# springboot2_demo
springboot2.x_demo

在MySQL基础之上，在集成redis

springboot2.X + redis