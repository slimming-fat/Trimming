package com.alibaba.demo.basic.issue;

public abstract class AbstractServiceA {

    public String put(Object input) {
        return "object";
    }

}
