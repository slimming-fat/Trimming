package com.alibaba.demo.basic.model.mock

interface Color {

    val color: String

}
