Effective Scope Of Mocking
---

TO BE TRANSLATED
