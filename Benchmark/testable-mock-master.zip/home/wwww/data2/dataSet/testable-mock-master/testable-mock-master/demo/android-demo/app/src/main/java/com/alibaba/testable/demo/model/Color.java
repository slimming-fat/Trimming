package com.alibaba.testable.demo.model;

public interface Color {

    String getColor();

}
