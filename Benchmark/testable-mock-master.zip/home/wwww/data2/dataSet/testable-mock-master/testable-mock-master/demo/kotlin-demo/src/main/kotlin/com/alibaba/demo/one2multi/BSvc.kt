package com.alibaba.demo.one2multi

class BSvc {

    fun demo(name: String): String {
        return String.format("b_%s", name)
    }

}
