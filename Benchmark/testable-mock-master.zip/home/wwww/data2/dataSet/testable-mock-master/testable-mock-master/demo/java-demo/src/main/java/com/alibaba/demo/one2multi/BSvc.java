package com.alibaba.demo.one2multi;

public class BSvc {

    public String demo(String name) {
        return String.format("b_%s", name);
    }

}
