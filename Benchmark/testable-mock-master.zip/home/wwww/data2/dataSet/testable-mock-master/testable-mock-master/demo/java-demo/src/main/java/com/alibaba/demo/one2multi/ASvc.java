package com.alibaba.demo.one2multi;

public class ASvc {

    public String demo(String name) {
        return String.format("a_%s", name);
    }

}
