package com.alibaba.demo.basic.model.mock;

public interface Color extends BasicColor {

    String getColor();

}
