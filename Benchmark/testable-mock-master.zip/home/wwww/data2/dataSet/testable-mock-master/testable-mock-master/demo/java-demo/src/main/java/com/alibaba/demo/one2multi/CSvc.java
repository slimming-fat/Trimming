package com.alibaba.demo.one2multi;

public class CSvc {

    public String demo(String name) {
        return String.format("c_%s", name);
    }

}
