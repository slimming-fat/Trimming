Available Annotations
---

TO BE TRANSLATED
