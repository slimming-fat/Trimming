Reusing Mock Methods
---

TO BE TRANSLATED
