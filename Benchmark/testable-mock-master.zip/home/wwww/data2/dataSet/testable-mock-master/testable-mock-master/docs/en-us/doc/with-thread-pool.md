Mock Invocation In Thread Pool
---

TO BE TRANSLATED
