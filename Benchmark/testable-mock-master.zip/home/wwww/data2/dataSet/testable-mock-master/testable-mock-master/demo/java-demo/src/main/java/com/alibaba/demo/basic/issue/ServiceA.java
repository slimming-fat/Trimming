package com.alibaba.demo.basic.issue;

public class ServiceA extends AbstractServiceA {

    public String get(Object input) {
        return super.put(input);
    }

}
