package com.alibaba.demo.basic.model.omni

class GrandChild {

    // ---------- 内部成员字段 ----------
    var value = 0
    var content: String? = null

}
