package com.alibaba.testable.core.error;

/**
 * @author flin
 */
public class NoSuchMemberError extends Error {

    public NoSuchMemberError(String message) {
        super(message);
    }

}
