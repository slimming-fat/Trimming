package com.alibaba.testable.core.tool;

public class DemoParent {

    public DemoChild c;

    public DemoChild[] cs;

    private DemoChild.SubChild sc;

    private DemoChild.StaticSubChild ssc;

}
