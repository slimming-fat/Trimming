package com.alibaba.testable.processor.model;

/**
 * @author flin
 */
public class Parameters {

    public String sourceClassName;

    public Boolean verifyTargetExistence;

}
