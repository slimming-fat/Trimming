package kg.apc.jmeter.vizualizers;

public interface MonitoringSampleGenerator {
    public void generateSample(double d, String string);
}
