package kg.apc.emulators;

import javax.swing.JFileChooser;

public class FileChooserEmul extends JFileChooser {

}
