package kg.apc.jmeter.graphs;

public interface CompositeNotifierInterface {
    public void refresh();
}
