package kg.apc.jmeter.vizualizers;

public interface MonitoringSampler {
    public void generateSamples(MonitoringSampleGenerator collector);
}
