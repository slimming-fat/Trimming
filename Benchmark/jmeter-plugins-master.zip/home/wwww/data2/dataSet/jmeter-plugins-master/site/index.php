<?php
require __DIR__ . '/vendor/undera/pwe/index.php';