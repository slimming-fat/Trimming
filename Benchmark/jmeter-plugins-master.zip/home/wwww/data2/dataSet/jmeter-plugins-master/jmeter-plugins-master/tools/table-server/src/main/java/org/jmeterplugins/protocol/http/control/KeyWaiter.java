package org.jmeterplugins.protocol.http.control;


public interface KeyWaiter {
    public void waitForKey();
}
