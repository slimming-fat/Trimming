package eu.optique.r2rml.api.model;

/**
 * @author xiao
 */
public @interface W3C_R2RML_Recommendation {
    String value();
}
