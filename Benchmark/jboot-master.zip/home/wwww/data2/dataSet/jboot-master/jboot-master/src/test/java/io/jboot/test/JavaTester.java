package io.jboot.test;


public class JavaTester {


    public static void main(String[] args) {

    }


}
