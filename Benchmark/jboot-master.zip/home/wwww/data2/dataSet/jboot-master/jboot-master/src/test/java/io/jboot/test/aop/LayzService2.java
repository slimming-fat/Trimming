package io.jboot.test.aop;

public interface LayzService2 {


    public void doSth();
}
