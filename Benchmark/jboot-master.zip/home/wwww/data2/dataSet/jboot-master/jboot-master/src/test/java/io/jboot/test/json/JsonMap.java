package io.jboot.test.json;

import java.util.HashMap;

public class JsonMap extends HashMap {
}
