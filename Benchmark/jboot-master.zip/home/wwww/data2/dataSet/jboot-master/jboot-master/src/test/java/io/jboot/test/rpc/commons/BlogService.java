package io.jboot.test.rpc.commons;


import java.util.List;

public interface BlogService {

    public String findById();
    public List<String> findAll();
}
