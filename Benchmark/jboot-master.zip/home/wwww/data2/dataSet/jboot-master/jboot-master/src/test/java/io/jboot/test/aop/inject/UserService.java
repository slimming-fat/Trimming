package io.jboot.test.aop.inject;


public interface UserService {

    public String getName(String para);
}
