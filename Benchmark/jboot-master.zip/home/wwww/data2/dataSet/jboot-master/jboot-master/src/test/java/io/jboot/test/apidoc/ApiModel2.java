package io.jboot.test.apidoc;

public class ApiModel2 {
}
