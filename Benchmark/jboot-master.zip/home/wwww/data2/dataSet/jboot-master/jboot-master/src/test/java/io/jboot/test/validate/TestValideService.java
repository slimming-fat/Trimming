package io.jboot.test.validate;

import javax.validation.constraints.NotNull;

public class TestValideService {

    public void calc(@NotNull Integer value){
        return;
    }
}
