# Jboot Gateway 自动发现的 Demo

由于本 Demo 是通过 Nacos 进行自动发现的，因此在开始之前，请先参考 Nacos 官方文档，
把 Nacos 运行起来。

Nacos 启动文档：
https://nacos.io/zh-cn/docs/quick-start.html


## 架构图

![](./asserts/gateway-nacos.png)