package io.jboot.simples.gateway;

import io.jboot.app.JbootApplication;

public class GatewayStarter {

    public static void main(String[] args) {
        JbootApplication.run(args);
    }
}
