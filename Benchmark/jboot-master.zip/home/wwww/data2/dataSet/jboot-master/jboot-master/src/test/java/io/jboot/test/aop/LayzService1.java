package io.jboot.test.aop;

public interface LayzService1 {

    public void doSth();
}
