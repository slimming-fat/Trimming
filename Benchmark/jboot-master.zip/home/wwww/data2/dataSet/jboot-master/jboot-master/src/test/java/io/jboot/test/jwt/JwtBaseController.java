package io.jboot.test.jwt;

import io.jboot.support.jwt.EnableJwt;
import io.jboot.web.controller.JbootController;

@EnableJwt
public class JwtBaseController extends JbootController {

}
