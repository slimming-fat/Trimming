package io.jboot.test.aop.inject;


public interface OtherService {
}
