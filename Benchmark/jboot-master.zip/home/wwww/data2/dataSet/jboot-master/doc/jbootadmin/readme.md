

# 关于 JbootAdmin

![](./images/jbootadmin-demo.jpg)

JbootAdmin 是基于 Jboot 开发的快手开发脚手架。真诚的为各位开发者和企业提供一站式、保姆式、企业级的开发服务。


