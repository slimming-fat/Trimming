# CDN 配置

CDN 配置，我们只需要在 `jboot.properties` 里，添加如下代码。

```
jboot.web.cdn.enable = true
jboot.web.cdn.domain = http://your-cdn-daomain.com
```