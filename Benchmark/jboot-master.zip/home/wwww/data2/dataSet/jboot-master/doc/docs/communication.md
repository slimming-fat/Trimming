# 交流社区

- 提问：[https://www.oschina.net/question/tag/jboot](https://www.oschina.net/question/tag/jboot)
- QQ群：
    - 群1: `601440615`（已满）
    - 群2: `719614554`


- 微信群
  
  ![](./static/images/jboot-wechat-group.png)
  