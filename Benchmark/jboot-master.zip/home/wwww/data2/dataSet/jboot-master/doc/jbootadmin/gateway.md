# 门户网关 Gateway

购买后获得阅读权限。