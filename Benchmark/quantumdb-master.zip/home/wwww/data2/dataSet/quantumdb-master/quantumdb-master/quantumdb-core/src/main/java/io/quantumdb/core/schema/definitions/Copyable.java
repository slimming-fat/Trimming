package io.quantumdb.core.schema.definitions;

interface Copyable<T> {

	T copy();

}
