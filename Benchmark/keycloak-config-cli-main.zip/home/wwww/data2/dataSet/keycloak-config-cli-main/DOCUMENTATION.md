# General information

See: [README.md](README.md)

# Supported Features

See: [docs/FEATURES.md](docs/FEATURES.md)

# Declarative syntax and resource deletion

See: [docs/MANAGED.md](docs/MANAGED.md)

# Extend JSON, e.g. RealmRepresentation

See: [contrib/custom-representations/README.md](contrib/custom-representations/README.md)
