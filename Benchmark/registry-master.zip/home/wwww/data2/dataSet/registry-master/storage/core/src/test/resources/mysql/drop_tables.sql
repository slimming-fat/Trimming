
DROP TABLE IF EXISTS device_info;
