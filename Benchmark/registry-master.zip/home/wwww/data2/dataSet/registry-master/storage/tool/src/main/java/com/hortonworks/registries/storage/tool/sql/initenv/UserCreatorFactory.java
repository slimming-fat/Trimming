/*
 * Copyright 2016-2019 Cloudera, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.hortonworks.registries.storage.tool.sql.initenv;

import com.hortonworks.registries.storage.common.DatabaseType;
import com.hortonworks.registries.storage.tool.sql.initenv.mysql.MySqlUserCreator;
import com.hortonworks.registries.storage.tool.sql.initenv.postgres.PostgreSqlUserCreator;

import java.sql.Connection;

public class UserCreatorFactory {
    private UserCreatorFactory() {
    }

    public static UserCreator newInstance(DatabaseType databaseType, Connection connection) {
        switch (databaseType) {
            case MYSQL:
                return new MySqlUserCreator(connection);

            case POSTGRESQL:
                return new PostgreSqlUserCreator(connection);

            default:
                throw new IllegalArgumentException("Not supported DBMS: " + databaseType);
        }
    }
}
