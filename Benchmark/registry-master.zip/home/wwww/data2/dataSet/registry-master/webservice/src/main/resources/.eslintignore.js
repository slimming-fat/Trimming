node_modules/*
**/bower_components/*
**/vendor/*.js
