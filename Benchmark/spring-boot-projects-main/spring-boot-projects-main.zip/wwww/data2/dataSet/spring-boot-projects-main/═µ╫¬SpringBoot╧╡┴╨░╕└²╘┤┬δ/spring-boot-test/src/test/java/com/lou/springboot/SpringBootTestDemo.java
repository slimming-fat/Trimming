package com.lou.springboot;

import org.junit.Test;

public class SpringBootTestDemo {
    @Test
    public void test1(){
        System.out.println("test1");
    }
}
