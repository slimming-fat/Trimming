package org.aksw.qa.datasets;

/**
 * This class is only used to locate the resources of this package. It has no
 * additional functionality and can be ignored.
 * 
 * @author Michael R&ouml;der (roeder@informatik.uni-leipzig.de)
 *
 */
public abstract class ResourceLoadingAnchor {

}
