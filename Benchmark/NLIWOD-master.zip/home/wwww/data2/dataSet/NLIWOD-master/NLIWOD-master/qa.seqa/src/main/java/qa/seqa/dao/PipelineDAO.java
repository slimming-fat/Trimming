package qa.seqa.dao;

import java.util.List;

import qa.seqa.model.Pipeline;

public interface PipelineDAO {

	List<Pipeline> getPipelines();
}
