possible categorys/answers

categorieys:
- date
- number
- string
- procedural
- boolean (yes/no)
- list
- temporal

Difficult questions:
(question:answer/category)
- How many days until christmas: ?/temporal (tagesaktuelle Berechnung)
- Am I fat: ?/guide
- between x and y
