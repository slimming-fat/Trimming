package com.config;

/**
 * 项目中的常量定义类
 */
public class Constant {
    /**
     * 开发者后台->应用开发-企业内部应用->选择您创建的小程序->应用首页-查看详情->查看AppKey
     */
    public static final String APP_KEY = "***";
    /**
     * 开发者后台->应用开发-企业内部应用->选择您创建的小程序->应用首页-查看详情->查看AppSecret
     */
    public static final String APP_SECRET="***";
}
