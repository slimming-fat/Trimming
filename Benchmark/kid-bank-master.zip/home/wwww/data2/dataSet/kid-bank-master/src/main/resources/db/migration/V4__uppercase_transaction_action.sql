UPDATE transactions SET action = upper(action);
