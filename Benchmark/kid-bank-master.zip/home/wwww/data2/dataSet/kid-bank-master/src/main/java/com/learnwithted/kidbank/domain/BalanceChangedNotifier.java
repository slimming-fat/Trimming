  package com.learnwithted.kidbank.domain;

public interface BalanceChangedNotifier {
  void balanceChanged(int amount, int balance);
}



