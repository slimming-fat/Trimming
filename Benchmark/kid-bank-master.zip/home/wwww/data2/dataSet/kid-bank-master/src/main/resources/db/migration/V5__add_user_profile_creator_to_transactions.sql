ALTER TABLE transactions
    ADD COLUMN creator_id BIGINT;