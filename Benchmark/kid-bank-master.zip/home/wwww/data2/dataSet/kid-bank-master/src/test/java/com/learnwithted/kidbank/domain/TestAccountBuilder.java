package com.learnwithted.kidbank.domain;

import com.learnwithted.kidbank.adapter.web.FakeTransactionRepository;

import static com.learnwithted.kidbank.domain.TestClockSupport.createFixedClockOn;
import static com.learnwithted.kidbank.domain.TestClockSupport.localDateTimeAtMidnightOf;
import static java.time.LocalDateTime.now;

public class TestAccountBuilder {

  private static final UserProfile CREATOR = new UserProfile("jpdAdapterTest",
                                                             new PhoneNumber("+16505551212"),
                                                             "jpaEmail", Role.PARENT);

  private TransactionRepository transactionRepository = new FakeTransactionRepository();
  private BalanceChangedNotifier balanceChangedNotifier = new DoNothingBalanceChangeNotifier();
  private InterestStrategy interestStrategy = account -> {};
  private GoalRepository goalRepository = new FakeGoalRepository();
  private CoreAccount coreAccount;


  public static TestAccountBuilder builder() {
    return new TestAccountBuilder();
  }

  public InterestEarningAccount buildAsInterestEarning(int year, int month, int day) {
    interestStrategy = new MonthlyInterestStrategy(createFixedClockOn(year, month, day));
    return new InterestEarningAccount(buildAsCore(), interestStrategy);
  }

  public CoreAccount buildAsCore() {
    coreAccount = new CoreAccount(transactionRepository, goalRepository, balanceChangedNotifier);
    return coreAccount;
  }

  public CoreAccount coreAccount() {
    if (coreAccount == null) {
      throw new IllegalStateException("Account has not been built yet, use buildAsCore() or buildAsInterestEarning() first.");
    }
    return coreAccount;
  }

  public TestAccountBuilder notifier(BalanceChangedNotifier balanceChangedNotifier) {
    this.balanceChangedNotifier = balanceChangedNotifier;
    return this;
  }

  public TestAccountBuilder initialBalanceOf(int amount) {
    transactionRepository.save(Transaction.createDeposit(now(), amount, "initialized in test", CREATOR));
    return this;
  }

  public TestAccountBuilder initialBalanceOf(int amount, int year, int month, int day) {
    transactionRepository.save(Transaction.createDeposit(
        localDateTimeAtMidnightOf(year, month, day), amount, "initialized in test", CREATOR));
    return this;
  }

  public TransactionRepository transactionRepository() {
    return transactionRepository;
  }

  public TestAccountBuilder withGoalRepository(GoalRepository goalRepository) {
    this.goalRepository = goalRepository;
    return this;
  }

  public InterestStrategy interestStrategy() {
    return interestStrategy;
  }

  public GoalRepository goalRepository() {
    return goalRepository;
  }
}
