package com.learnwithted.kidbank.domain;

public enum Role {
  UNKNOWN, KID, PARENT
}
