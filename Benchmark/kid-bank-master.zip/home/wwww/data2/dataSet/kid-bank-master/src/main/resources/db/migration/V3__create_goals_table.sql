CREATE TABLE goals (
  id BIGINT NOT NULL PRIMARY KEY,
  target_amount INT NOT NULL,
  description VARCHAR(255) NOT NULL
);