package com.learnwithted.kidbank.adapter.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

public interface GoalJpaRepository extends JpaRepository<GoalDto, Long> {
}

