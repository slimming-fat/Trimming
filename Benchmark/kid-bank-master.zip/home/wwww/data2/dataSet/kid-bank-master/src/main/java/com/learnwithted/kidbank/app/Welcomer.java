package com.learnwithted.kidbank.app;

public interface Welcomer {
  void welcome(Long profileId);
}
