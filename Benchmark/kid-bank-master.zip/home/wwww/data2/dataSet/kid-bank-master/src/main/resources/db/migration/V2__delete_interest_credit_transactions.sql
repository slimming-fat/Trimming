DELETE FROM transactions
WHERE action = 'Interest Credit';
