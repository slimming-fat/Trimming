package com.learnwithted.kidbank.domain;

public enum Action {
  DEPOSIT,
  SPEND,
  INTEREST_CREDIT
}
