[![CircleCI](https://circleci.com/gh/tedyoung/kid-bank.svg?style=svg)](https://circleci.com/gh/tedyoung/kid-bank)

# The Kid Money Manager Project

Not a real bank, but a tool to keep track of your kid's earnings, savings, and spending.

Watch the live-coding of this project [on Twitch.tv/jitterted](https://twitch.tv/jitterted).

# Deployment

Heroku is set up for automatic deploy upon commit/push to 'master' branch.

## To Do

Have GitHub Actions run tests and package prior to deploy.
