package com.kdmeubichinho.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CredenciaisDTO {
	private String email;
	private String senha;
}