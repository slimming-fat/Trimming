package com.kdmeubichinho.entities.generics;

/**
 *
 */
public interface BaseEntity {
    Integer getId();
}
