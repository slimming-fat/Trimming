package com.kdmeubichinho.dto.generics;

import com.kdmeubichinho.entities.generics.BaseEntity;

public interface ObjectDTO {
    BaseEntity build();
}
