package com.kdmeubichinho.repositories;

import org.springframework.data.repository.CrudRepository;
import com.kdmeubichinho.entities.Foto;
public interface FotoRepository extends CrudRepository <Foto, Integer>{

}
