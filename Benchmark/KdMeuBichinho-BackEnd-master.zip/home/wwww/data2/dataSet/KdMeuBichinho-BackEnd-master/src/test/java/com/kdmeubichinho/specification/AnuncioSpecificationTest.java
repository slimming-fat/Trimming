package com.kdmeubichinho.specification;

import com.kdmeubichinho.entities.Anuncio;
import com.kdmeubichinho.enums.AnuncioStatus;
import org.junit.jupiter.api.Test;
import org.springframework.data.jpa.domain.Specification;

import static org.junit.jupiter.api.Assertions.*;

class AnuncioSpecificationTest {


}