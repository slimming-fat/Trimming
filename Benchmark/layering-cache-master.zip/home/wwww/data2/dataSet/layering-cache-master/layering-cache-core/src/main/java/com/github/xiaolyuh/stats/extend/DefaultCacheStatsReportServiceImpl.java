package com.github.xiaolyuh.stats.extend;

import com.github.xiaolyuh.stats.CacheStatsInfo;

import java.util.List;

/**
 * 缓存统计信息上报扩展类
 *
 * @author olafwang
 */
public class DefaultCacheStatsReportServiceImpl implements CacheStatsReportService {

    @Override
    public void reportCacheStats(List<CacheStatsInfo> cacheStatsInfos) {

    }
}