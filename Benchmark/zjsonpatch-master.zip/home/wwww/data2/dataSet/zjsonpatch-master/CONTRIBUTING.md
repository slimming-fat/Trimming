The source code is available under the Apache 2.0 license. I am actively looking for contributors so if you have ideas, code, bug reports, or fixes you would like to contribute please do so.
