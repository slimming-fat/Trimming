package com.example.ws;

import jakarta.xml.ws.Service;

public class WSExample {
    public void service() {
        Service calculatorService = Service.create(null);
    }
}
