package com.example;

public class LombokService {
    public void hello() {
        LombokStudent lombokExample = new LombokStudent("James");
        System.out.println(lombokExample.getName());
    }
}
