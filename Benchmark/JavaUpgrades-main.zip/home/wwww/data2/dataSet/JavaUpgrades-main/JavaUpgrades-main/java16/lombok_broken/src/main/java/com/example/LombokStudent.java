package com.example;

import lombok.Value;

@Value
public class LombokStudent {
    private String name;
}
