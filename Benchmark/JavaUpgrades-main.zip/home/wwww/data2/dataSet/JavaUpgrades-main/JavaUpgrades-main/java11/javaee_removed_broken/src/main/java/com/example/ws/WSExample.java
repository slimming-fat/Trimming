package com.example.ws;

import javax.xml.ws.Service;

public class WSExample {
    public void service() {
        Service calculatorService = Service.create(null);
    }
}
