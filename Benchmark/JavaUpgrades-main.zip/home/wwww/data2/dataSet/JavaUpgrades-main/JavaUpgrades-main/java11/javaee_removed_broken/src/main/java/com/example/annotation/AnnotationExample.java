package com.example.annotation;

import javax.annotation.PostConstruct;

public class AnnotationExample {
    @PostConstruct
    private void postConstruct() {
        // Executed after construction
    }
}
