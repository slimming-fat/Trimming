package com.hust.hui.alarm.core.exception;

/**
 * Created by yihui on 2018/2/5.
 */
public class NoAlarmLoaderSpecifyException extends RuntimeException {
    private static final long serialVersionUID = -7354521488541766839L;

    public NoAlarmLoaderSpecifyException(String message) {
        super(message);
    }
}
