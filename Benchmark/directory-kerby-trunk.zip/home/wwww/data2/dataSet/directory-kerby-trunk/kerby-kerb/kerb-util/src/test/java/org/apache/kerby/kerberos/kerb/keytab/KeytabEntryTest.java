/**
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 *
 */
package org.apache.kerby.kerberos.kerb.keytab;

import org.apache.kerby.kerberos.kerb.type.KerberosTime;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

@RunWith(MockitoJUnitRunner.class)
public class KeytabEntryTest {
    @Test(expected = IOException.class)
    public void exceptionThrownWhenLoadingInvalidKeytabEntry() throws Exception {
        KeytabInputStream mockKeytabInputStream = spy(
                new KeytabInputStream(
                        new ByteArrayInputStream(new String("randomtestarray").getBytes())));

        doAnswer(new Answer<Integer>() {
                     private boolean isFirstCall = true;

                     @Override
                     public Integer answer(InvocationOnMock invocationOnMock) throws Throwable {
                         if (isFirstCall) {
                             isFirstCall = false;
                             return 200;
                         }
                         return 20;
                     }
                 }).when(mockKeytabInputStream).available();
        //doReturn(120).when(mockKeytabInputStream).readOctetsCount();
        doReturn(new byte[]{}).when(mockKeytabInputStream).readCountedOctets();
        doReturn(null).when(mockKeytabInputStream).readPrincipal(ArgumentMatchers.any(Integer.class));
        doReturn(new KerberosTime()).when(mockKeytabInputStream).readTime();

        KeytabEntry keytabEntry = new KeytabEntry();
        keytabEntry.load(mockKeytabInputStream, 0x502, 100);
    }


}
