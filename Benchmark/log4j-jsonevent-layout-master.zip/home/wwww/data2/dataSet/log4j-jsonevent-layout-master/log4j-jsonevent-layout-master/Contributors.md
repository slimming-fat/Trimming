# Contributors

- @pyr (Pierre-Yves Ritschard)
- @StFS (Stefán Freyr Stefánsson)
- @looztra (Christophe Furmaniak)
- @astrochoupe
- @bfritz (Brad Fritz)
- @vrivellino (Vincent R.)
