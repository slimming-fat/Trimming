package com.github.onblog.core.exception;

public class SnowJeanException extends RuntimeException {

    public SnowJeanException(String message) {
        super(message);
    }
}
