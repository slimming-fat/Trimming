package com.github.onblog.monitor.client;

import org.junit.Test;

public class MonitorServiceImplTest {

    @Test
    public void getAndDelete() throws InterruptedException {

    }
}