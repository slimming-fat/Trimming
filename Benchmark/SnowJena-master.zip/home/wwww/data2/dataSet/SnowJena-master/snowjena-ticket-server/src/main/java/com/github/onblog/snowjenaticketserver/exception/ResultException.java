package com.github.onblog.snowjenaticketserver.exception;

public @interface ResultException {
}
