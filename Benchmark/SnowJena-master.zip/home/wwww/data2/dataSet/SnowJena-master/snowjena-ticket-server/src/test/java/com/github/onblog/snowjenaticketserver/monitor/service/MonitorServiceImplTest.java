package com.github.onblog.snowjenaticketserver.monitor.service;

import org.junit.Test;

public class MonitorServiceImplTest {

    @Test
    public void getAll() {
        String s1 = "sa$aaa$PRE$aa$a";
        System.out.println(s1.replace("$PRE$","$AFTER$"));
    }
}