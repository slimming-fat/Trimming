package com.github.onblog.commoon.enums;

public enum Algorithm {
    TOKENBUCKET, LEAKBUCKET
}
