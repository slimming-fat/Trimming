package com.github.onblog.commoon.enums;

public enum AcquireModel {
    FAILFAST,BLOCKING
}
