package com.github.onblog.commoon.enums;

public enum LimiterModel {
    POINT,CLOUD
}
