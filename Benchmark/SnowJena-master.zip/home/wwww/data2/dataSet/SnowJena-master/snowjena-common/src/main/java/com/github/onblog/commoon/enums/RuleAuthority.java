package com.github.onblog.commoon.enums;

public enum RuleAuthority {
    AUTHORITY_WHITE, AUTHORITY_BLACK, NULL
}
