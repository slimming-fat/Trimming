#!/bin/sh

cat /tmp/some.html

