#!/bin/sh
echo stdout && echo stderr >&2
