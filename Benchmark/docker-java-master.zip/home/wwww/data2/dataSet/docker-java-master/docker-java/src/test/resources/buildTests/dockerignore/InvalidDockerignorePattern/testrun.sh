#!/bin/sh

echo "Successfully executed testrun.sh"
