#!/bin/sh

echo "Successfully executed testAddFolder.sh"
