#!/bin/sh

echo "Hello Word" > hello.txt
echo "hello.txt Created"
