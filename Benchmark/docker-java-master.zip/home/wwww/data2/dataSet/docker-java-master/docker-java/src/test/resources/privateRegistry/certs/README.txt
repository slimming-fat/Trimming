This directory contains self signed certificate for docker registry with CN: "localhost". For testing purposes only.
See https://github.com/docker/distribution/blob/master/docs/insecure.md#using-self-signed-certificates
