package com.github.dockerjava.junit.category;

public interface AuthIntegration {
}
