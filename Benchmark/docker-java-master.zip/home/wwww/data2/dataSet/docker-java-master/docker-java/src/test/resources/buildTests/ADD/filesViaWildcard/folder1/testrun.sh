#!/bin/sh

/usr/local/bin/testinclude1.sh
/usr/local/bin/testinclude2.sh

