#!/bin/sh

echo /tmp/a/* 
