package com.github.dockerjava.api.model;

/**
 * @since {@link RemoteApiVersion#VERSION_1_24}
 */
public enum ServiceMode {

    REPLICATED,

    GLOBAL

}
