package com.github.dockerjava.api.model;

public enum PruneType {
    BUILD,
    CONTAINERS,
    IMAGES,
    NETWORKS,
    VOLUMES
}
