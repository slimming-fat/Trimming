package com.github.dockerjava.api.model;

/**
 * Represents a push response stream item
 */
public class PushResponseItem extends ResponseItem {

    private static final long serialVersionUID = 8256977108011295857L;

}
