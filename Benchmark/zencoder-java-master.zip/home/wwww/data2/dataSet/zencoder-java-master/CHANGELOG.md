# Changelog
All notable changes to this project will be documented in this file.

## NEXT

### Added

* Support for [notification headers](https://app.zencoder.com/docs/api/encoding/notifications/notification-headers)

## 0.0.1 - 2014-XX-XX
### Added
- Initial version

### Deprecated
- 

### Removed
- 

### Fixed
- 

