/* eslint-disable import/prefer-default-export */
export const SET_ALL_DOMAINS = 'setAllDomains';

export const SET_DOMAIN_INFO = 'setDomainInfo';

export const SET_JOB_INFO = 'setJobInfo';

export const SET_JOB_LIST_INFO = 'setJobListInfo';

export const SET_USER_AUTHORITY = 'setUserAuthority';

export const SET_IS_USE_AUTH = 'setIsUseAuth';
