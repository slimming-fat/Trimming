#!/bin/bash

# Set npm registered address
npm config set registry https://registry.npm.taobao.org
# Set sass_binary_site address
npm config set sass_binary_site https://npm.taobao.org/mirrors/node-sass/