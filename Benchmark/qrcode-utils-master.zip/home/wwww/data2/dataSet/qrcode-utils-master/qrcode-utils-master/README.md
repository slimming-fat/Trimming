# qrcode-utils
二维码生成工具
---------------------------------
[![Maven Central](https://maven-badges.herokuapp.com/maven-central/com.github.binarywang/qrcode-utils/badge.svg)](https://maven-badges.herokuapp.com/maven-central/com.github.binarywang/qrcode-utils)
[![Build Status](https://travis-ci.org/binarywang/qrcode-utils.svg?branch=develop)](https://travis-ci.org/binarywang/qrcode-utils)

#### Maven：


    <dependency>
      <groupId>com.github.binarywang</groupId>
      <artifactId>qrcode-utils</artifactId>
      <version>1.1</version>
    </dependency>
