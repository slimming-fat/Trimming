#!/usr/bin/env bash

echo "Killing all apps"
pkill -f spring-boot-sample-flyway