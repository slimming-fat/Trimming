/**
 * Package for extensions that must be able use package-private classes of {@code feign}.
 *
 * @author Alexei KLENIN
 */
package feign;