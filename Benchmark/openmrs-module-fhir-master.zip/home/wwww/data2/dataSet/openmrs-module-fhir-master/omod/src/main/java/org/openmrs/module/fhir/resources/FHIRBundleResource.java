package org.openmrs.module.fhir.resources;

public class FHIRBundleResource {

}
