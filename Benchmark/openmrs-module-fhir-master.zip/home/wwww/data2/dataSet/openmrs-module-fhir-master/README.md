[![Build Status](https://travis-ci.org/openmrs/openmrs-module-fhir.svg?branch=master)](https://travis-ci.org/openmrs/openmrs-module-fhir)

openmrs-module-fhir
===================

Implements REST and Java APIs to access OpenMRS via FHIR Specification.

## Requirements:
- Java 8 - required to build the module correctly. 
