package cn.nukkit.level.generator.populator.impl;

import cn.nukkit.level.ChunkManager;
import cn.nukkit.level.format.FullChunk;
import cn.nukkit.level.generator.populator.type.Populator;
import cn.nukkit.math.NukkitRandom;

public class PopulatorMineshaft extends Populator {

    /**
     * @author Niall Lindsay (Niall7459)
     * <p>
     * Nukkit Project
     * </p>
     *
     * WIP
     */

    @Override
    public void populate(ChunkManager level, int chunkX, int chunkZ, NukkitRandom random, FullChunk chunk) {
        // TODO Auto-generated method stub

    }

}
