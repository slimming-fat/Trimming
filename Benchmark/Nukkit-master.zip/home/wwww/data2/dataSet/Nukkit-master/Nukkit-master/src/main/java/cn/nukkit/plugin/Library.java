package cn.nukkit.plugin;

/**
 * Created on 15-12-13.
 */
public interface Library {

    String getGroupId();

    String getArtifactId();

    String getVersion();

}
