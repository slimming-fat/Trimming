package cn.nukkit.plugin.service;

/**
 * Created on 16-11-20.
 */
public enum ServicePriority {

    LOWEST, LOWER, NORMAL, HIGHER, HIGHEST,

}
