/**
 * This package has lots of helper interfaces for frequently repeated methods
 */
package cn.nukkit.level.generator.populator.helper;
