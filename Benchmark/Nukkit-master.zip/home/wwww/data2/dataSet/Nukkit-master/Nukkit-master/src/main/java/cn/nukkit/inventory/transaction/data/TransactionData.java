package cn.nukkit.inventory.transaction.data;

/**
 * @author CreeperFace
 */
public interface TransactionData {
}
