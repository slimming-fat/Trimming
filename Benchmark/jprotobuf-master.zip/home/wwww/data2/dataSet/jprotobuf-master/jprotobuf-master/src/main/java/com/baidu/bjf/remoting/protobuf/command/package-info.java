/**
 * Command supports
 * @author xiemalin
 * @since 1.8.0
 */
package com.baidu.bjf.remoting.protobuf.command;