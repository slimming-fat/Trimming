package com.baidu.jprotobuf.plugin;

import java.io.File;

import org.gradle.testkit.runner.BuildResult;
import org.gradle.testkit.runner.GradleRunner;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PluginTest {
    
    BuildResult gradleRunner;

    @Before
    public void setUp() throws Exception {
        

    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test() {
        

        
    }

    public static void main(String[] args) {
        BuildResult gradleRunner;
        gradleRunner = GradleRunner.create()
        .withProjectDir(new File("D:\\develop\\projects\\oxygen-workspaces\\SimpleGradleBuild"))
        .withArguments("compileJava", "jprotobuf_precompile").withDebug(true)
        .build();
        
        System.out.println(gradleRunner);
        
        String output = gradleRunner.getOutput();
        System.out.println(output);
    }
}
